# SplitNow — ohje tekoälylle (Base44)

Tämä dokumentti on tarkoitettu **ensisijaiseksi ohjeeksi tekoälylle**, joka tekee muutoksia SplitNow-sovellukseen Base44-alustalla. Lue tämä ennen koodin muokkaamista. Ohje kuvaa sovelluksen rakenteen, tietomallit, oikeudet, sarjaluokittelun säännöt ja kehityskäytännöt.

---

## 1. Mikä sovellus on

SplitNow on ammattimaiseen käyttöön tarkoitettu **väliaikojen kirjaus- ja tulospalvelusovellus** hiihto- ja juoksukilpailuihin.

- Kilpailun järjestäjä luo kilpailun (nimi, päivä, aloitusaika, sarjojen/väliaikojen määrä, lähtöväli).
- Kilpailuun liitytään 6-merkkisellä liittymiskoodilla, QR-koodilla tai syvälinkillä.
- Väliajat kirjataan rinnakkain usealla laitteella, myös ilman verkkoyhteyttä.
- Tulokset, erot kärkeen, sarjasuodatus, PDF/CSV/kuva-vienti ja julkinen kilpailusivu.
- Käyttöliittymä on **mobile-first**, tumma/vaalea teema, kolme kieltä (fi/en/sv).

Sovellus on julkaistu osoitteessa `https://split-now-go.base44.app`.

---

## 2. Teknologia ja rakenne

- React + Vite + JavaScript, Tailwind CSS, shadcn/ui (`@/components/ui`), lucide-react-ikonit.
- Tietokanta ja autentikointi: Base44-entiteetit ja `@/api/base44Client` (SDK on valmiiksi alustettu).
- Palvelinlogiikka: `base44/functions/<nimi>/entry.ts`.
- Tilakyselyt: `@tanstack/react-query`. Entiteettien reaaliaikapäivitykset `subscribe`-kutsulla.
- Ei uusia npm-paketteja ilman erillistä pyyntöä. Ei `require`-kutsuja (ESM).
- Polut `@/`-aliaksella, ei suhteellisia `../`-polkuja.

Keskeiset hakemistot:

| Polku | Sisältö |
| --- | --- |
| `src/pages/` | Sivut (reitit `src/App.jsx`:ssä) |
| `src/components/competition/` | Kilpailunäkymät: lähtölista, väliaika, tulokset, QuickTouch |
| `src/components/startlist/` | Lähtölistan kuvatunnistus ja tarkistus |
| `src/components/route/` | Ratakartta ja reittikuvien rajaus |
| `src/lib/` | Apufunktiot: `seriesUtils`, `startListRecognition`, `syncQueue`, `permissions`, `timeUtils` |
| `src/i18n/` | `fi.json`, `en.json`, `sv.json` |
| `base44/entities/` | Tietomallit |
| `base44/functions/` | Palvelinfunktiot |

---

## 3. Tietomallit

### Competition
`name`, `date`, `start_time` (HH:MM:SS, sekunnit säilytetään), `start_interval` (s), `split_count`, `add_finish`, `format` (`interval` \| `mass_start`), `status`, `first_number`, `last_number`, `join_code`, `default_join_role`, `is_public`, `description`, `sport`, `location`, `images`, `route_data`, `route_preview_url`, `gender_categorization`, `age_categorization`.

### Competitor
`competition_id`, `bib_number`, `name`, `start_time`, `status` (`active`/`DNS`/`DNF`/`DSQ`), `split_times[]` (`split_index`, `timestamp`, `elapsed`, `status`, `source`), `sort_order`, `gender` (`female`/`male`/`unspecified`), `age`, `series` (**aina sovelluksen oma sarjatunnus**, ks. luku 5).

### CompetitionMember
`competition_id`, `user_id`, `user_email`, `user_name`, `role` (`viewer` \| `timer` \| `editor` \| `owner`).

### PublicProfile
`user_id`, `display_name`, `avatar_url`, `bio`, `is_profile_public`, `email`.

**RLS:** älä avaa kirjoituksia tai henkilötietoja ilman pyyntöä. Uusi entiteetti kirjoitetaan aina täydellisenä JSON-skeemana ja sen `rls` samassa tiedostossa.

---

## 4. Palvelinfunktiot (älä ohita)

- `saveSplitTime` — väliajan tallennus, muokkaus ja poisto (undo). Tarkistaa roolin palvelimella: `timer` saa lisätä ja korjata omia väliaikoja, `editor`/`owner` laajemmin.
- `manageCompetitionMember` — jäsenten lisäys, roolimuutos ja poisto. Roolirajatukset tarkistetaan aina palvelimella.

UI ei saa ohittaa näitä funktioita suoralla entiteettikirjoituksella silloin, kun toiminto liittyy väliaikoihin tai jäseniin.

---

## 5. Sarjat ja luokittelu (TÄRKEÄ)

Sovelluksessa on **yksi ainoa sarjakieli**, ja se rakennetaan aina mies/nainen + ikä -tiedoista:

| Sukupuoli | Ikä | Sarjatunnus |
| --- | --- | --- |
| nainen | 16 | `N16` |
| mies | 16 | `M16` |
| nainen | – | `N` |
| mies | – | `M` |
| ei tiedossa | 40 | `40` |

Tunnukset tulevat käännösavaimista `results.seriesFemale` / `results.seriesMale` (fi: N/M, en: W/M, sv: F/M). Sarjan oikea lähde on siis **`gender` + `age`**, ei vapaa teksti.

### Lähtölistan tunnistuksen sarjasäännöt

Kun lähtölista luetaan kuvasta (`src/lib/startListRecognition.js`), painettu sarjanimi **muunnetaan aina sovelluksen omaksi sarjaksi** ennen kuin mitään vertaillaan:

| Painettu sarja | Tulkinta |
| --- | --- |
| `Tytöt`, `Tytöt 15`, `T` | nainen → `N`, `N15` |
| `Pojat`, `Pojat 15`, `P` | mies → `M`, `M15` |
| `Naiset`, `Naiset 40` | nainen → `N`, `N40` |
| `Miehet`, `M40` | mies → `M`, `M40` |
| `MYL` (miehet yleinen) | mies, **ei ikää** → `M` |
| `NYL` (naiset yleinen) | nainen, **ei ikää** → `N` |
| `N16`, `M16` | suoraan `N16`, `M16` |

Säännöt:

1. **Vapaa sarjateksti ei koskaan tallennu sellaisenaan.** Sarake `series` sisältää vain sovelluksen omia tunnuksia, jotta sarjan muokkaus (sukupuoli/ikä -valinnat) toimii ja suodatus täsmää.
2. Jos sarjasta ei saada selville sukupuolta eikä ikää (esim. `Kunto`, `Yleinen`), rivi jätetään **ilman sarjaa** ja käyttäjä korjaa sen tarkistusvaiheessa. Uutta sarjaa ei keksitä.
3. Sarjan periytyminen sivulta toiselle ja ristiriitojen tunnistus tehdään **normalisoinnin jälkeen**, joten `Tytöt` ja `N` samassa listassa ovat sama sarja.
4. Sukupuoli- ja ikäluokittelu kytkeytyvät automaattisesti päälle, jos tunnistettu aineisto sisältää niitä (`inferCategorization`).
5. Sarjanäkymät noudattavat kilpailun asetuksia: jos `gender_categorization` ja `age_categorization` ovat pois päältä, sarjaa ei näytetä, vaikka tieto säilyy tallessa.

---

## 6. Aika ja sekunnit

- Kaikki ajat muodossa `HH:MM:SS`; sekunnit ovat aina mukana.
- Aloitusajan valinta käyttää laitteen omaa valitsinta: `src/components/competition/StartTimeInput.jsx` (input `type="time"`, `step="1"`).
- Älä korvaa natiivia valitsinta omalla komponentilla.
- Väliajan muokkauksessa (`TimeInput`) on erillinen alasekuntien tila vain, jos sitä tarvitaan.
- Aika-apurit: `src/lib/timeUtils.js`, `src/lib/startTimeUtils.js`.

---

## 7. Roolit ja oikeudet

| Toiminto | viewer | timer | editor | owner |
| --- | --- | --- | --- | --- |
| Katsele lähtölistaa ja tuloksia | ✓ | ✓ | ✓ | ✓ |
| Kirjaa väliaikoja (QuickTouch / Split) | – | ✓ | ✓ | ✓ |
| Korjaa ja poistaa väliaikoja | – | ✓ | ✓ | ✓ |
| Muokkaa kilpailijoita ja lähtölistaa | – | – | ✓ | ✓ |
| Muokkaa kilpailua ja jäseniä | – | – | – | ✓ |

Oikeudet luetaan `src/lib/permissions.js` (`useUserRole`) ja tarkistetaan aina myös palvelimella. Älä koskaan luota pelkkään UI-piilotukseen.

---

## 8. Offline-toiminta

- Väliajat kirjataan `syncQueue`-jonoon (`src/lib/syncQueue.js`), joka tallentaa paikalliseen välimuistiin ja synkronoi verkkoon palatessa.
- `SyncStatusIcon` näyttää tilan. Älä riko jonoa nopeilla peräkkäisillä kirjoituksilla; käytä `execOrQueue`-apuria.
- Reaaliaikapäivitys: `base44.entities.Competitor.subscribe(...)`.

---

## 9. Käyttöliittymä ja tyylit

- Värit ja typografia tulevat `src/index.css`:n tokeneista (`bg-primary`, `text-muted-foreground`, `font-inter`). Älä käytä kovakoodattuja värejä (`bg-white`, `text-[#...]`).
- Tumma ja vaalea teema ovat molemmat tuettuja — testaa molemmat.
- Ensisijainen kohdeviewport **373 px** mobiili; asettelu ei saa aiheuttaa vaakavieritystä.
- Noudata olemassa olevaa tiheyttä: kompaktit rivit, 3.5rem painikkeet QuickTouch-gridissä, nimien ellipsi-trunkaus.
- Aikojen esitys: `src/lib/resultStyles.js` (väliajat harmaana, erot normaaleina, ei lihavointia ellei kyse ole tilamerkinnästä).
- Sarjamerkki: `SeriesBadge` + `seriesColorClass` (deterministinen väri sarja-avaimesta).

---

## 10. Monikielisyys

- Kaikki käyttöliittymätekstit kolmesta tiedostosta: `src/i18n/fi.json`, `en.json`, `sv.json`. **Lisää avain aina kaikkiin kolmeen.**
- Ei emojeita käyttöliittymässä eikä käännöstiedostoissa.
- Kielenvaihto: `changeLanguage` (`src/i18n/index.js`).
- Sarjatunnukset tulevat käännösavaimista, joten älä kovakoodaa `N`/`M`-kirjaimia komponentteihin.

---

## 11. Navigaatio

- Reitit: `/`, `/competitions`, `/create`, `/join`, `/profile`, `/competition/:id/startlist`, `/competition/:id/split/:n`, `/competition/:id/results`, `/competition/:id/quicktouch`, `/competition/:id/edit`, `/competition/:id/import`, `/competition/:id/public`, `/competition/:id/edit-form`.
- Paluu taaksepäin: `goBack` (`src/lib/navHistory.js`), ei kovakoodattuja polkuja.
- Kilpailunäkymien yhteinen yläpalkki: `CompetitionNav`. Pyyhkäisynavigaatio: `src/lib/swipeNav.js` (kytketään pois täysiruutuisissa muokkaimissa).

---

## 12. Kehityssäännöt tekoälylle

1. Tee **vain pyydetty muutos** — älä muuta laskentasääntöjä, oikeuksia tai ulkoasua sivutuotteena.
2. Suosi `find_replace`-työkalua; luo uusi tiedosto vain kun se on selkeästi oma kokonaisuutensa. Pilko pitkät sivut pieniksi komponenteiksi.
3. Älä koskaan luo uusia sarjoja, rooleja tai tiloja — käytä olemassa olevia.
4. Älä ohita palvelinfunktioiden tarkistuksia.
5. Säilytä suorituskyky: listat haetaan palvelimelta (`filter`, `count`, `aggregate`), ei ladattuja taulukoita suodattaen.
6. Varmista muutos esikatselussa ennen valmista vastausta: avaa muuttunut näkymä, aja muutettu toiminto ja tarkista lopputulos.
7. Testidata luodaan ja poistetaan saman istunnon aikana.
8. Kirjoita käyttäjälle lyhyt, tuotetermein tehty yhteenveto — ei tiedostonimiä eikä koodia.

---

## 13. Tunnetut rajoitteet

- iOS ei tue selaimen värinä-API:a → haptinen palaute on äänimerkki (`haptics.js`).
- iOS:n oma ajanvalitsin ei näytä sekunteja kaikissa versioissa; valittu aika säilyttää aiemmat sekunnit tai saa `00`.
- Julkisella sivulla näytetään vain julkaistut tiedot; henkilötietoja ei koskaan avata julkisesti.