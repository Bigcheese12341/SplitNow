import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Upload, X, Loader2, Camera, ImagePlus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ImportInfoButton from '@/components/import/ImportInfoButton';
import ImageViewerOverlay from '@/components/import/ImageViewerOverlay';

export default function ImageUploadStep({ images, setImages, onAnalyze, analyzing, estimatedSeconds }) {
  const { t } = useTranslation();
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [viewerIndex, setViewerIndex] = useState(null);

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    setUploading(true);
    try {
      const uploaded = await Promise.all(
        files.map(async (file) => {
          const result = await base44.integrations.Core.UploadPublicFile({ file });
          return { url: result.file_url, name: file.name };
        })
      );
      setImages(prev => [...prev, ...uploaded]);
    } catch (err) {
      console.error('Upload failed', err);
    }
    setUploading(false);
    e.target.value = '';
  };

  const removeImage = (idx) => {
    setImages(prev => prev.filter((_, i) => i !== idx));
  };

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h2 className="font-black text-lg text-foreground mb-1">{t('importResults.addImages')}</h2>
          <p className="text-sm text-muted-foreground">{t('importResults.addImagesDesc')}</p>
        </div>
        <ImportInfoButton
          title={t('importResults.introTitle')}
          description={t('importResults.introDesc')}
        />
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handleFileSelect}
      />

      {images.length > 0 && (
        <div className="grid grid-cols-2 gap-3">
          {images.map((img, i) => (
            <div key={i} className="relative aspect-square rounded-2xl overflow-hidden border border-border bg-muted">
              <img
                src={img.url}
                alt={img.name}
                onClick={() => setViewerIndex(i)}
                className="w-full h-full object-cover active:scale-95 transition-transform"
              />
              <button
                onClick={() => removeImage(i)}
                className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full bg-black/60 flex items-center justify-center active:scale-90 transition-transform"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          ))}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading || analyzing}
            className="aspect-square rounded-2xl border-2 border-dashed border-border flex flex-col items-center justify-center gap-2 text-muted-foreground active:scale-95 transition-transform disabled:opacity-50"
          >
            {uploading ? <Loader2 className="w-6 h-6 animate-spin" /> : <ImagePlus className="w-6 h-6" />}
            <span className="text-xs font-bold">{t('importResults.addMore')}</span>
          </button>
        </div>
      )}

      {images.length === 0 && (
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="w-full py-12 rounded-2xl border-2 border-dashed border-border flex flex-col items-center justify-center gap-3 text-muted-foreground active:scale-[0.98] transition-transform disabled:opacity-50"
        >
          {uploading ? (
            <Loader2 className="w-10 h-10 animate-spin" />
          ) : (
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
              <Camera className="w-7 h-7 text-primary" />
            </div>
          )}
          <span className="font-bold text-sm">{t('importResults.addImages')}</span>
          <span className="text-xs">{t('importResults.addImagesDesc')}</span>
        </button>
      )}

      {analyzing && (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <Loader2 className="w-8 h-8 text-primary animate-spin mb-3" />
          <p className="font-bold text-sm text-foreground">{t('importResults.analyzing')}</p>
          <p className="text-xs text-muted-foreground mt-1">{t('importResults.analyzingDesc')}</p>
          {estimatedSeconds > 0 ? (
            <p className="text-xs font-bold text-primary mt-3 tabular-nums">
              {t('importResults.estimatedTime')}: ~{estimatedSeconds}s
            </p>
          ) : (
            <p className="text-xs font-bold text-primary mt-3">{t('importResults.almostDone')}</p>
          )}
        </div>
      )}

      {!analyzing && images.length > 0 && (
        <button
          onClick={onAnalyze}
          disabled={images.length === 0}
          className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-black text-base flex items-center justify-center gap-2 shadow-lg shadow-primary/25 active:scale-[0.98] transition-all disabled:opacity-50"
        >
          <Upload className="w-5 h-5" />
          {t('importResults.analyze')}
        </button>
      )}

      {viewerIndex !== null && (
        <ImageViewerOverlay
          images={images}
          index={viewerIndex}
          onIndexChange={setViewerIndex}
          onClose={() => setViewerIndex(null)}
        />
      )}
    </div>
  );
}