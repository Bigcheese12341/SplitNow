import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, ZoomIn, ZoomOut, ChevronLeft, ChevronRight } from 'lucide-react';

// Full screen look at one uploaded image: nothing is analysed, the image is only
// opened so the user can read what it actually says.
export default function ImageViewerOverlay({ images, index, onClose, onIndexChange }) {
  const [zoomed, setZoomed] = useState(false);
  const image = images[index];

  useEffect(() => { setZoomed(false); }, [index]);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight' && index < images.length - 1) onIndexChange(index + 1);
      if (e.key === 'ArrowLeft' && index > 0) onIndexChange(index - 1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [index, images.length, onClose, onIndexChange]);

  if (!image) return null;

  return createPortal(
    <div className="fixed inset-0 z-[70] bg-black/95 flex flex-col">
      <div className="flex-shrink-0 flex items-center justify-between px-3 h-14">
        <span className="text-sm font-bold text-white/80 tabular-nums">
          {index + 1} / {images.length}
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setZoomed(v => !v)}
            className="w-9 h-9 rounded-full flex items-center justify-center text-white/80 active:scale-90 transition-transform"
          >
            {zoomed ? <ZoomOut className="w-5 h-5" /> : <ZoomIn className="w-5 h-5" />}
          </button>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center text-white/80 active:scale-90 transition-transform"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div
        className="flex-1 min-h-0 overflow-auto flex items-center justify-center p-2"
        onClick={onClose}
      >
        <img
          src={image.url}
          alt={image.name || ''}
          onClick={(e) => e.stopPropagation()}
          className={zoomed
            ? 'w-[220%] max-w-none h-auto'
            : 'max-h-full max-w-full object-contain'}
        />
      </div>

      {images.length > 1 && (
        <div className="flex-shrink-0 flex items-center justify-between px-3 pb-6 pt-2">
          <button
            onClick={() => onIndexChange(index - 1)}
            disabled={index === 0}
            className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-white disabled:opacity-30 active:scale-90 transition-transform"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => onIndexChange(index + 1)}
            disabled={index >= images.length - 1}
            className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-white disabled:opacity-30 active:scale-90 transition-transform"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      )}
    </div>,
    document.body
  );
}