import React from 'react';
import { useTranslation } from 'react-i18next';
import { Check, Loader2, Trophy, Clock, Hand, Plus, Flag, AlertTriangle } from 'lucide-react';

export default function ImportSummaryStep({
  competitors,
  detectedPoints,
  mappings,
  manualSplits,
  splitCount,
  addFinish,
  finalStructure,
  importing,
  importResult,
  onBack,
  onImport,
  onShowResults
}) {
  const { t } = useTranslation();

  if (importResult) {
    return (
      <div className="space-y-5">
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-500/20 flex items-center justify-center mb-4">
            <Check className="w-8 h-8 text-green-600 dark:text-green-400" />
          </div>
          <h2 className="font-black text-lg text-foreground mb-1">{t('importResults.importSuccess')}</h2>
          <p className="text-sm text-muted-foreground">
            {t('importResults.importSuccessDesc', {
              added: importResult.added,
              splits: importResult.newSplits
            })}
          </p>
        </div>

        <div className="space-y-2">
          {importResult.added > 0 && (
            <SummaryRow icon={Trophy} label={t('importResults.resultsAdded')} value={importResult.added} />
          )}
          {importResult.newSplits > 0 && (
            <SummaryRow icon={Plus} label={t('importResults.newSplitsCreated')} value={importResult.newSplits} />
          )}
          {importResult.finishAdded > 0 && (
            <SummaryRow icon={Flag} label={t('importResults.finishAdded')} value={importResult.finishAdded} />
          )}
          {importResult.duplicates > 0 && (
            <SummaryRow icon={Check} label={t('importResults.duplicatesSkipped')} value={importResult.duplicates} />
          )}
          {importResult.uncertain > 0 && (
            <SummaryRow icon={AlertTriangle} label={t('importResults.uncertainResults')} value={importResult.uncertain} />
          )}
        </div>

        <button
          onClick={onShowResults}
          className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-black text-base flex items-center justify-center gap-2 shadow-lg shadow-primary/25 active:scale-[0.98] transition-all"
        >
          <Trophy className="w-5 h-5" />
          {t('importResults.showResults')}
        </button>
      </div>
    );
  }

  const mappedPoints = detectedPoints.filter(p => mappings[p.index] !== -1 && mappings[p.index] !== undefined);
  const skippedPoints = detectedPoints.filter(p => mappings[p.index] === -1);
  const uncertainCount = competitors.reduce((sum, c) => sum + (c.times || []).filter(t => t.uncertain).length, 0);
  const newSplits = Math.max(0, finalStructure.finalSplitCount - splitCount);
  const finishAdded = finalStructure.finalAddFinish && !addFinish ? 1 : 0;

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-black text-lg text-foreground mb-1">{t('importResults.summary')}</h2>
        <p className="text-sm text-muted-foreground">{t('importResults.summaryDesc')}</p>
      </div>

      <div className="space-y-2">
        <SummaryRow icon={Trophy} label={t('importResults.competitorsToImport')} value={competitors.length} />
        <SummaryRow icon={Clock} label={t('importResults.importedPoints')} value={mappedPoints.length} />
        {manualSplits.length > 0 && (
          <SummaryRow icon={Hand} label={t('importResults.manualPoints')} value={manualSplits.length} />
        )}
        {newSplits > 0 && (
          <SummaryRow icon={Plus} label={t('importResults.newSplits')} value={newSplits} />
        )}
        {finishAdded > 0 && (
          <SummaryRow icon={Flag} label={t('importResults.newFinish')} value={finishAdded} />
        )}
        {skippedPoints.length > 0 && (
          <SummaryRow icon={Check} label={t('importResults.notImported')} value={skippedPoints.length} />
        )}
        {uncertainCount > 0 && (
          <SummaryRow icon={AlertTriangle} label={t('importResults.uncertainResults')} value={uncertainCount} />
        )}
      </div>

      <div className="flex gap-2 pt-2">
        <button
          onClick={onBack}
          disabled={importing}
          className="flex-1 h-12 rounded-2xl bg-muted text-foreground font-bold text-sm active:scale-95 transition-transform disabled:opacity-50"
        >
          {t('importResults.edit')}
        </button>
        <button
          onClick={onImport}
          disabled={importing}
          className="flex-1 h-12 rounded-2xl bg-primary text-primary-foreground font-black text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform disabled:opacity-50"
        >
          {importing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              {t('importResults.importing')}
            </>
          ) : (
            <>
              <Check className="w-4 h-4" />
              {t('importResults.import')}
            </>
          )}
        </button>
      </div>
    </div>
  );
}

function SummaryRow({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center justify-between p-3 rounded-2xl bg-card border border-border">
      <div className="flex items-center gap-2">
        <Icon className="w-4 h-4 text-primary" />
        <span className="text-sm font-medium text-foreground">{label}</span>
      </div>
      <span className="font-black text-base text-foreground tabular-nums">{value}</span>
    </div>
  );
}