import React, { useEffect, useRef, useState } from 'react';
import { Info } from 'lucide-react';

// The instructions of the import process live behind this icon instead of a
// permanent block of text on the page.
export default function ImportInfoButton({ title, description }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onOutside = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('pointerdown', onOutside);
    return () => document.removeEventListener('pointerdown', onOutside);
  }, [open]);

  return (
    <div className="relative flex-shrink-0" ref={ref}>
      <button
        onClick={() => setOpen(v => !v)}
        aria-label={title}
        className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${
          open ? 'bg-primary/15 text-primary' : 'text-muted-foreground active:scale-95'
        }`}
      >
        <Info className="w-[18px] h-[18px]" />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1 z-50 w-64 rounded-2xl bg-card border border-border shadow-lg shadow-black/10 p-3 animate-in fade-in slide-in-from-top-1 duration-150">
          <p className="text-sm font-bold text-foreground">{title}</p>
          <p className="text-xs text-muted-foreground leading-relaxed mt-1">{description}</p>
        </div>
      )}
    </div>
  );
}