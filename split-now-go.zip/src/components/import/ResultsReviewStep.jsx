import React from 'react';
import { useTranslation } from 'react-i18next';
import { AlertTriangle, Bot, Hand } from 'lucide-react';
import { formatResultTime, parseResultTimeToSeconds } from '@/lib/resultImportAnalysis';
import { getSplitName } from '@/lib/splitLabels';

export default function ResultsReviewStep({
  competitors,
  setCompetitors,
  detectedPoints,
  mappings,
  competition,
  onBack,
  onNext
}) {
  const { t } = useTranslation();

  // Get mapped points (not skipped)
  const mappedPoints = detectedPoints
    .filter(p => mappings[p.index] !== -1 && mappings[p.index] !== undefined)
    .sort((a, b) => {
      const aVal = mappings[a.index];
      const bVal = mappings[b.index];
      if (aVal === 'finish') return 1;
      if (bVal === 'finish') return -1;
      return aVal - bVal;
    });

  const updateCompetitor = (idx, field, value) => {
    setCompetitors(prev => prev.map((c, i) => i === idx ? { ...c, [field]: value } : c));
  };

  const updateTime = (compIdx, timePointIndex, value) => {
    setCompetitors(prev => prev.map((c, i) => {
      if (i !== compIdx) return c;
      const times = [...(c.times || [])];
      const tIdx = times.findIndex(t => t.time_point_index === timePointIndex);
      if (tIdx >= 0) {
        times[tIdx] = { ...times[tIdx], time: value, uncertain: false };
      } else {
        times.push({ time_point_index: timePointIndex, time: value, uncertain: false });
      }
      return { ...c, times };
    }));
  };

  const uncertainCount = competitors.reduce((sum, c) => {
    return sum + (c.times || []).filter(t => t.uncertain).length;
  }, 0);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-black text-lg text-foreground mb-1">{t('importResults.reviewResults')}</h2>
        <p className="text-sm text-muted-foreground">
          {t('importResults.competitorsFound', { count: competitors.length })} · {t('importResults.timePointsFound', { count: mappedPoints.length })}
        </p>
      </div>

      {uncertainCount > 0 && (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20">
          <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0" />
          <p className="text-sm text-amber-700 dark:text-amber-400">
            {t('importResults.uncertainCount', { count: uncertainCount })}
          </p>
        </div>
      )}

      {/* Editable results table */}
      <div className="overflow-x-auto -mx-4 px-4">
        <div className="min-w-max">
          {/* Header */}
          <div className="grid gap-1 px-2 py-2 text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1"
            style={{ gridTemplateColumns: `3rem 3rem 1fr ${mappedPoints.map(() => '5rem').join(' ')} 3.5rem` }}
          >
            <span>{t('importResults.bibNumber')}</span>
            <span></span>
            <span>{t('importResults.name')}</span>
            {mappedPoints.map(p => (
              <span key={p.index} className="text-right">
                {mappings[p.index] === 'finish'
                  ? t('importResults.finish')
                  : (getSplitName(competition, mappings[p.index]) || t('importResults.splitN', { n: mappings[p.index] + 1 }))}
              </span>
            ))}
            <span className="text-right">{t('importResults.status')}</span>
          </div>

          {/* Rows */}
          <div className="space-y-1.5">
            {competitors.map((comp, compIdx) => {
              const hasUncertain = (comp.times || []).some(t => t.uncertain);
              return (
                <div
                  key={compIdx}
                  className={`grid gap-1 items-center px-2 py-2 rounded-xl border transition-all ${
                    hasUncertain
                      ? 'bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/20'
                      : 'bg-card border-border'
                  }`}
                  style={{ gridTemplateColumns: `3rem 3rem 1fr ${mappedPoints.map(() => '5rem').join(' ')} 3.5rem` }}
                >
                  <input
                    type="number"
                    value={comp.bib_number || ''}
                    onChange={(e) => updateCompetitor(compIdx, 'bib_number', parseInt(e.target.value) || 0)}
                    className="w-full px-1 py-1 rounded-lg bg-muted border border-border text-sm font-bold tabular-nums text-center focus:outline-none focus:border-primary"
                  />
                  <div className="flex items-center justify-center">
                    <Bot className="w-3.5 h-3.5 text-primary/60" />
                  </div>
                  <input
                    type="text"
                    value={comp.name || ''}
                    onChange={(e) => updateCompetitor(compIdx, 'name', e.target.value)}
                    className="w-full px-2 py-1 rounded-lg bg-muted border border-border text-sm font-medium focus:outline-none focus:border-primary"
                  />
                  {mappedPoints.map(p => {
                    const timeEntry = (comp.times || []).find(t => t.time_point_index === p.index);
                    const timeStr = timeEntry?.time || '';
                    const isUncertain = timeEntry?.uncertain;
                    return (
                      <div key={p.index} className="relative">
                        <input
                          type="text"
                          value={timeStr}
                          onChange={(e) => updateTime(compIdx, p.index, e.target.value)}
                          className={`w-full px-1.5 py-1 rounded-lg border text-sm font-mono tabular-nums text-right focus:outline-none focus:border-primary ${
                            isUncertain
                              ? 'bg-amber-100 dark:bg-amber-500/20 border-amber-300 dark:border-amber-500/40'
                              : 'bg-muted border-border'
                          }`}
                        />
                        {isUncertain && (
                          <AlertTriangle className="absolute -top-1 -right-1 w-3 h-3 text-amber-500" />
                        )}
                      </div>
                    );
                  })}
                  <select
                    value={comp.status || 'active'}
                    onChange={(e) => updateCompetitor(compIdx, 'status', e.target.value)}
                    className="h-7 px-1 rounded-lg bg-muted border border-border text-xs font-bold focus:outline-none focus:border-primary"
                  >
                    <option value="active">OK</option>
                    <option value="DNF">DNF</option>
                    <option value="DNS">DNS</option>
                    <option value="DSQ">DSQ</option>
                  </select>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex gap-2 pt-2">
        <button
          onClick={onBack}
          className="flex-1 h-12 rounded-2xl bg-muted text-foreground font-bold text-sm active:scale-95 transition-transform"
        >
          {t('importResults.back')}
        </button>
        <button
          onClick={onNext}
          className="flex-1 h-12 rounded-2xl bg-primary text-primary-foreground font-black text-sm active:scale-95 transition-transform"
        >
          {t('importResults.next')}
        </button>
      </div>
    </div>
  );
}