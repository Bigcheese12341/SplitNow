import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Hand, Bot, AlertTriangle, Check, ChevronDown, Trash2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction
} from '@/components/ui/alert-dialog';
import {
  formatResultTime,
  sortCheckpointsByTime,
  findDuplicateTargets
} from '@/lib/resultImportAnalysis';
import { getSplitName } from '@/lib/splitLabels';

export default function TimePointMappingStep({
  checkpoints, setCheckpoints, splitCount, competition, onBack, onNext
}) {
  const { t } = useTranslation();
  const [pickerId, setPickerId] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const rows = sortCheckpointsByTime(checkpoints);
  const duplicateTargets = findDuplicateTargets(checkpoints);
  const hasDuplicates = duplicateTargets.size > 0;

  // Enough split alternatives for every point in the list, so the user can always
  // give each row its own timing point.
  const assignedMax = checkpoints.reduce(
    (max, row) => (typeof row.target === 'number' ? Math.max(max, row.target + 1) : max),
    0
  );
  // Room for the existing split points plus one extra point per imported row, so a
  // genuinely new timing point can always be pushed after the current last one.
  const importedRows = checkpoints.filter(row => row.source === 'imported').length;
  const splitOptions = Math.max((splitCount || 1) + importedRows, assignedMax, 1);

  const targetLabel = (value) => {
    if (value === 'finish') return t('importResults.finish');
    if (typeof value !== 'number') return t('importResults.selectTarget');
    return getSplitName(competition, value) || t('importResults.splitN', { n: value + 1 });
  };

  const options = [
    ...Array.from({ length: splitOptions }, (_, i) => ({
      value: i,
      label: getSplitName(competition, i) || t('importResults.splitN', { n: i + 1 }),
    })),
    { value: 'finish', label: t('importResults.finish') },
  ];

  const updateTarget = (id, value) => {
    setCheckpoints(prev => prev.map(row => (row.id === id ? { ...row, target: value } : row)));
  };

  const confirmDelete = () => {
    if (!deleting) return;
    setCheckpoints(prev => prev.filter(row => row.id !== deleting.id));
    setDeleting(null);
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-black text-lg text-foreground mb-1">{t('importResults.detectedPoints')}</h2>
        <p className="text-sm text-muted-foreground">{t('importResults.detectedPointsDesc')}</p>
      </div>

      {hasDuplicates && (
        <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20">
          <AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-red-700 dark:text-red-300">{t('importResults.duplicateBlockTitle')}</p>
            <p className="text-xs text-red-600/90 dark:text-red-400/90 mt-0.5 leading-relaxed">
              {t('importResults.duplicateBlockDesc')}
            </p>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {rows.map((row) => {
          const isOpen = pickerId === row.id;
          const isDuplicate = duplicateTargets.has(String(row.target));
          const isManual = row.source === 'manual';

          return (
            <div
              key={row.id}
              className={`rounded-2xl border p-3 transition-colors ${
                isDuplicate
                  ? 'bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/30'
                  : 'bg-card border-border'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground leading-none mb-1">
                    {t('importResults.leaderTime')}
                  </p>
                  <p className="font-black text-lg text-foreground tabular-nums leading-tight">
                    {typeof row.leader_time === 'number'
                      ? formatResultTime(row.leader_time)
                      : (row.original_label || '—')}
                  </p>
                  <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                    <span
                      className={`inline-flex items-center gap-1 text-[11px] font-bold px-1.5 py-0.5 rounded-md ${
                        isManual
                          ? 'bg-primary/10 text-primary'
                          : 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300'
                      }`}
                    >
                      {isManual ? <Hand className="w-3 h-3" /> : <Bot className="w-3 h-3" />}
                      {isManual ? t('importResults.sourceManual') : t('importResults.sourceImported')}
                    </span>
                    {!isManual && row.original_label && (
                      <span className="text-[11px] text-muted-foreground font-medium truncate">
                        {row.original_label}
                      </span>
                    )}
                  </div>
                </div>

                <div className="relative flex-shrink-0">
                  <button
                    onClick={() => setPickerId(isOpen ? null : row.id)}
                    className="flex items-center gap-1.5 h-10 px-3 rounded-xl bg-muted border border-border text-sm font-bold text-foreground active:scale-95 transition-transform"
                  >
                    <span className="max-w-[6.5rem] truncate">{targetLabel(row.target)}</span>
                    <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {isOpen && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setPickerId(null)} />
                      <div className="absolute right-0 top-full mt-1 z-50 w-48 max-h-72 overflow-y-auto rounded-2xl bg-card border border-border shadow-lg shadow-black/10 animate-in fade-in slide-in-from-top-1 duration-150">
                        {options.map(opt => {
                          const isSelected = String(row.target) === String(opt.value);
                          return (
                            <button
                              key={String(opt.value)}
                              onClick={() => { updateTarget(row.id, opt.value); setPickerId(null); }}
                              className={`w-full flex items-center justify-between gap-2 px-3 py-3 text-sm font-bold transition-colors text-left border-b border-border last:border-b-0 ${
                                isSelected ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-muted'
                              }`}
                            >
                              <span className="truncate">{opt.label}</span>
                              {isSelected && <Check className="w-4 h-4 text-primary flex-shrink-0" />}
                            </button>
                          );
                        })}
                      </div>
                    </>
                  )}
                </div>

                <button
                  onClick={() => setDeleting(row)}
                  aria-label={t('common.delete')}
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-muted-foreground active:scale-95 transition-transform flex-shrink-0"
                >
                  <Trash2 className="w-[18px] h-[18px]" />
                </button>
              </div>

              {isDuplicate && (
                <div className="flex items-center gap-1.5 mt-2 text-xs font-bold text-red-600 dark:text-red-400">
                  <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                  {t('importResults.duplicateWarning')}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="flex gap-2 pt-2">
        <button
          onClick={onBack}
          className="flex-1 h-12 rounded-2xl bg-muted text-foreground font-bold text-sm active:scale-95 transition-transform"
        >
          {t('importResults.back')}
        </button>
        <button
          onClick={onNext}
          disabled={hasDuplicates}
          className="flex-1 h-12 rounded-2xl bg-primary text-primary-foreground font-black text-sm active:scale-95 transition-transform disabled:opacity-50"
        >
          {t('importResults.next')}
        </button>
      </div>

      <AlertDialog open={!!deleting} onOpenChange={(open) => { if (!open) setDeleting(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {deleting?.source === 'manual'
                ? t('importResults.deleteManualTitle')
                : t('importResults.deleteImportedTitle')}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {deleting?.source === 'manual'
                ? t('importResults.deleteManualDesc')
                : t('importResults.deleteImportedDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {t('common.delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}