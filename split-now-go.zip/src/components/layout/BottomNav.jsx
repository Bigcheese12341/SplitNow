import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Home as HomeIcon, Trophy, Plus, QrCode, User as UserIcon } from 'lucide-react';

export default function BottomNav() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();

  const items = [
    { id: 'home', icon: HomeIcon, label: t('navTab.home'), path: '/' },
    { id: 'competitions', icon: Trophy, label: t('navTab.competitions'), path: '/competitions' },
    { id: 'create', icon: Plus, label: t('navTab.create'), path: '/create', center: true },
    { id: 'join', icon: QrCode, label: t('navTab.join'), path: '/join' },
    { id: 'profile', icon: UserIcon, label: t('navTab.profile'), path: '/profile' },
  ];

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-card/95 backdrop-blur-md border-t border-border">
      <div className="max-w-lg mx-auto flex items-center justify-around h-16 px-2">
        {items.map((item) => {
          const active = isActive(item.path);
          const Icon = item.icon;

          if (item.center) {
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className="flex flex-col items-center justify-center -mt-6"
              >
                <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center shadow-xl shadow-primary/40 active:scale-95 transition-transform border-4 border-card">
                  <Icon className="w-7 h-7 text-primary-foreground" strokeWidth={2.5} />
                </div>
                <span className="text-[10px] font-bold text-primary mt-0.5">{item.label}</span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center justify-center gap-1 flex-1 py-1"
            >
              <Icon
                className={`w-5 h-5 transition-colors ${active ? 'text-primary' : 'text-muted-foreground'}`}
                strokeWidth={active ? 2.5 : 2}
              />
              <span className={`text-[10px] font-bold transition-colors ${active ? 'text-primary' : 'text-muted-foreground'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}