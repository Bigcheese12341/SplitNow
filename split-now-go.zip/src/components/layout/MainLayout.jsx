import React, { useRef } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import BottomNav from './BottomNav';
import { isSwipeNavigationLocked } from '@/lib/swipeNav';

const TAB_PATHS = ['/', '/competitions', '/create', '/join', '/profile'];

export default function MainLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const prevPath = useRef(location.pathname);
  const direction = useRef(0);
  const touchStart = useRef({ x: 0, y: 0 });

  if (prevPath.current !== location.pathname) {
    const prevIdx = TAB_PATHS.indexOf(prevPath.current);
    const newIdx = TAB_PATHS.indexOf(location.pathname);
    direction.current = (newIdx >= 0 && prevIdx >= 0) ? newIdx - prevIdx : 0;
    prevPath.current = location.pathname;
  }

  const currentIndex = TAB_PATHS.indexOf(location.pathname);

  const goToTab = (idx) => {
    if (idx >= 0 && idx < TAB_PATHS.length && idx !== currentIndex) {
      navigate(TAB_PATHS[idx]);
    }
  };

  const handleTouchStart = (e) => {
    if (isSwipeNavigationLocked()) return;
    touchStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };

  const handleTouchEnd = (e) => {
    if (isSwipeNavigationLocked()) return;
    const dx = e.changedTouches[0].clientX - touchStart.current.x;
    const dy = e.changedTouches[0].clientY - touchStart.current.y;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) {
      if (dx < 0) goToTab(currentIndex + 1);
      else goToTab(currentIndex - 1);
    }
  };

  return (
    <div className="relative w-full overflow-hidden" onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
      <AnimatePresence mode="popLayout" initial={false} custom={direction.current}>
        <motion.div
          key={location.pathname}
          custom={direction.current}
          initial={(dir) => ({ x: dir >= 0 ? '100%' : '-100%' })}
          animate={{ x: 0 }}
          exit={(dir) => ({ x: dir >= 0 ? '-100%' : '100%' })}
          transition={{ duration: 0.32, ease: [0.32, 0.72, 0, 1] }}
          className="w-full"
        >
          <Outlet />
        </motion.div>
      </AnimatePresence>
      <BottomNav />
    </div>
  );
}