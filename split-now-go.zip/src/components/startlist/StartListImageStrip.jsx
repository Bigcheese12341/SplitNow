import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, ChevronRight, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';

// Uploaded start list images: tap one to view it full size, remove it here.
export default function StartListImageStrip({ images, onRemove }) {
  const { t } = useTranslation();
  const [openIndex, setOpenIndex] = useState(null);
  if (!images.length) return null;

  const current = openIndex === null ? null : images[openIndex];
  const move = (delta) => setOpenIndex((i) => Math.min(images.length - 1, Math.max(0, (i ?? 0) + delta)));

  return (
    <>
      <div className="flex gap-2 flex-wrap">
        {images.map((url, i) => (
          <button
            key={`${url}-${i}`}
            type="button"
            onClick={() => setOpenIndex(i)}
            className="w-16 h-16 rounded-lg overflow-hidden border border-border active:scale-95 transition-transform"
          >
            <img src={url} alt="" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>

      <Dialog open={openIndex !== null} onOpenChange={(open) => !open && setOpenIndex(null)}>
        <DialogContent className="max-w-lg p-3 gap-3">
          <DialogTitle className="text-sm font-bold text-center">
            {t('create.imagePreview')} {images.length > 1 ? `${(openIndex ?? 0) + 1}/${images.length}` : ''}
          </DialogTitle>
          {current && <img src={current} alt="" className="w-full max-h-[65vh] object-contain rounded-lg bg-muted" />}
          <div className="flex items-center gap-2">
            {images.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={() => move(-1)}
                  disabled={openIndex === 0}
                  className="h-11 w-11 rounded-xl bg-muted flex items-center justify-center disabled:opacity-40"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={() => move(1)}
                  disabled={openIndex === images.length - 1}
                  className="h-11 w-11 rounded-xl bg-muted flex items-center justify-center disabled:opacity-40"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}
            <button
              type="button"
              onClick={() => {
                onRemove(current);
                setOpenIndex(null);
              }}
              className="ml-auto h-11 px-4 rounded-xl bg-destructive/10 text-destructive font-bold text-sm flex items-center gap-2 active:scale-95 transition-transform"
            >
              <Trash2 className="w-4 h-4" />
              {t('create.removeImage')}
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}