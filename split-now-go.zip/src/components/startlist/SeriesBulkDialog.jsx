import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

// Sets one series for a whole selected range of competitors at once, so a block
// read from an image that carried no heading can be fixed in one go.
export default function SeriesBulkDialog({ open, count, onOpenChange, onApply }) {
  const { t } = useTranslation();
  const [gender, setGender] = useState(null);
  const [age, setAge] = useState('');

  useEffect(() => {
    if (open) {
      setGender(null);
      setAge('');
    }
  }, [open]);

  const genderOptions = [
    { value: 'female', label: t('results.seriesFemale') },
    { value: 'male', label: t('results.seriesMale') },
  ];

  const apply = () => {
    const value = age.trim() === '' ? null : Number(age);
    onApply({ gender, age: Number.isFinite(value) ? value : null });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm p-4 gap-3">
        <DialogTitle className="text-base font-black">{t('create.bulkSeriesTitle')}</DialogTitle>
        <p className="text-xs text-muted-foreground">{t('create.bulkSeriesHint', { count })}</p>

        <div>
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">
            {t('startList.gender')}
          </p>
          <div className="grid grid-cols-3 gap-1.5">
            <button
              type="button"
              onClick={() => setGender(null)}
              className={`h-10 rounded-xl text-sm font-bold transition-colors ${
                gender === null ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'
              }`}
            >
              —
            </button>
            {genderOptions.map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => setGender(option.value)}
                className={`h-10 rounded-xl text-sm font-bold transition-colors ${
                  gender === option.value ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">
            {t('startList.age')}
          </p>
          <Input
            type="number"
            inputMode="numeric"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            placeholder="—"
            className="h-10 rounded-xl"
          />
        </div>

        <Button type="button" onClick={apply} className="h-11 rounded-xl font-bold">
          {t('create.applySeries')}
        </Button>
      </DialogContent>
    </Dialog>
  );
}