import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { AlertTriangle, Check } from 'lucide-react';
import StartListSheet from '@/components/competition/StartListSheet';
import SeriesBulkDialog from '@/components/startlist/SeriesBulkDialog';
import ReviewSummary from '@/components/startlist/ReviewSummary';
import { seriesKey, seriesLabel, seriesColorClass } from '@/lib/seriesUtils';
import { groupBySeries, summarizeRecognition, rowKeyOf } from '@/lib/startListRecognition';

// While reviewing a recognised start list both classifications are always
// available, so the series can be corrected even when the images were unclear.
const REVIEW_COMPETITION = { gender_categorization: true, age_categorization: true };

// Review step: the recognised competitors grouped by series, so the whole list
// can be checked at a glance. Tapping a row opens the app's normal competitor
// view, and one series can be set for a whole selected range at once.
//
// A row whose bib number could not be read is kept as well: it shows "?" and the
// number can be completed in the competitor view, so a partly read competitor is
// never silently dropped from the import.
export default function RecognizedCompetitors({ competitors, duplicates = 0, onSave, onRemove, onSetSeries }) {
  const { t } = useTranslation();
  const [openKey, setOpenKey] = useState(null);
  const [selecting, setSelecting] = useState(false);
  const [selected, setSelected] = useState([]);
  const [bulkOpen, setBulkOpen] = useState(false);

  if (competitors.length === 0) return null;

  const active = competitors.find((c) => rowKeyOf(c) === openKey) || null;
  const summary = summarizeRecognition(competitors, duplicates);
  const groups = groupBySeries(competitors);

  const rangeText = (group) => (
    group.minBib === null
      ? ''
      : group.minBib === group.maxBib ? String(group.minBib) : `${group.minBib}–${group.maxBib}`
  );

  const toggleSelected = (key) => setSelected((prev) => (
    prev.includes(key) ? prev.filter((value) => value !== key) : [...prev, key]
  ));

  const isGroupSelected = (group) => group.rows.every((row) => selected.includes(rowKeyOf(row)));

  const toggleGroup = (group) => {
    const keys = group.rows.map(rowKeyOf);
    setSelected((prev) => (
      keys.every((key) => prev.includes(key))
        ? prev.filter((key) => !keys.includes(key))
        : Array.from(new Set([...prev, ...keys]))
    ));
  };

  const endSelection = () => {
    setSelecting(false);
    setSelected([]);
  };

  const applySeries = (patch) => {
    onSetSeries(selected, patch);
    setBulkOpen(false);
    endSelection();
  };

  // The badge reflects the stored classification (gender + age), so a correction
  // is visible immediately; the printed series text is only a fallback.
  const seriesText = (competitor) => seriesLabel(competitor, t) || competitor.series;

  const renderRow = (competitor) => {
    const key = rowKeyOf(competitor);
    const series = seriesText(competitor);
    const isSelected = selected.includes(key);
    const noBib = competitor.bib_number === null || competitor.bib_number === undefined;
    return (
      <button
        key={key}
        type="button"
        onClick={() => (selecting ? toggleSelected(key) : setOpenKey(key))}
        className={`w-full grid items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-colors ${
          isSelected ? 'bg-primary/10' : 'bg-muted/70'
        } ${selecting ? 'grid-cols-[1.1rem_2.1rem_minmax(0,1fr)_auto]' : 'grid-cols-[2.1rem_minmax(0,1fr)_auto]'}`}
      >
        {selecting && (
          <span
            className={`w-4 h-4 rounded border flex items-center justify-center ${
              isSelected ? 'bg-primary border-primary' : 'border-border'
            }`}
          >
            {isSelected && <Check className="w-3 h-3 text-primary-foreground" />}
          </span>
        )}
        <span
          className={`text-sm font-bold tabular-nums leading-none ${
            noBib ? 'text-amber-600 dark:text-amber-400' : 'text-primary'
          }`}
        >
          {noBib ? '?' : competitor.bib_number}
        </span>
        <span className="min-w-0 text-sm leading-tight truncate">{competitor.name || '—'}</span>
        <span className="flex items-center gap-1 flex-shrink-0">
          {competitor.conflict && <AlertTriangle className="w-3 h-3 text-amber-500" />}
          {series ? (
            <span
              className={`px-1.5 rounded text-[10px] font-bold leading-[1.35] ${seriesColorClass(seriesKey(competitor))} ${
                competitor.inferred ? 'border border-dashed border-amber-500/70' : ''
              }`}
            >
              {series}
            </span>
          ) : (
            <span
              className={`px-1.5 rounded text-[10px] font-bold leading-[1.35] text-amber-600 dark:text-amber-400 bg-amber-500/10 ${
                competitor.series_uncertain ? 'border border-dashed border-amber-500/70' : ''
              }`}
            >
              ?
            </span>
          )}
          <span className="font-mono text-[11px] text-muted-foreground tabular-nums text-right w-[3.5rem]">
            {competitor.start_time || '—'}
          </span>
        </span>
      </button>
    );
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between gap-2">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
          {t('create.reviewTitle')} ({competitors.length})
        </div>
        <button
          type="button"
          onClick={() => (selecting ? endSelection() : setSelecting(true))}
          className="text-[11px] font-bold text-primary px-2 py-1 rounded-lg bg-primary/10"
        >
          {selecting ? t('create.selectDone') : t('create.selectRows')}
        </button>
      </div>

      <ReviewSummary summary={summary} />
      <p className="text-[11px] text-muted-foreground leading-snug">{t('create.reviewHint')}</p>

      {selecting && selected.length > 0 && (
        <button
          type="button"
          onClick={() => setBulkOpen(true)}
          className="w-full h-10 rounded-xl bg-primary text-primary-foreground text-sm font-bold active:scale-[0.99] transition-transform"
        >
          {t('create.setSeriesForSelected')} ({selected.length})
        </button>
      )}

      {summary.missingBib > 0 && (
        <div className="flex items-start gap-2 px-3 py-2 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs font-semibold">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          <span>{t('create.missingBibHint', { count: summary.missingBib })}</span>
        </div>
      )}

      {summary.conflicts > 0 && (
        <div className="flex items-start gap-2 px-3 py-2 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs font-semibold">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          <span>{t('create.seriesConflict', { count: summary.conflicts })}</span>
        </div>
      )}

      <div className="max-h-80 overflow-y-auto -mx-1 px-1 space-y-1.5">
        {groups.map((group) => (
          <div key={group.series || '__unknown'} className="space-y-0.5">
            <button
              type="button"
              onClick={() => selecting && toggleGroup(group)}
              className={`w-full flex items-center gap-1.5 px-1.5 py-1 rounded-lg ${
                selecting ? 'bg-muted' : 'bg-transparent'
              } ${isGroupSelected(group) && selecting ? 'ring-1 ring-primary/40' : ''}`}
            >
              <span
                className={`px-1.5 rounded text-[10px] font-bold leading-[1.35] flex-shrink-0 ${
                  group.series
                    ? seriesColorClass(seriesKey(group.rows[0]) || `s:${group.series}`)
                    : 'text-amber-600 dark:text-amber-400 bg-amber-500/10'
                }`}
              >
                {group.series || '?'}
              </span>
              <span className="text-[10px] font-semibold text-muted-foreground flex-1 text-left truncate">
                {!group.series
                  ? t('create.seriesUnknownGroup', { count: group.count })
                  : group.minBib === null
                    ? t('create.seriesGroupCount', { count: group.count })
                    : t('create.seriesGroupSummary', { count: group.count, range: rangeText(group) })}
              </span>
              {group.inferredCount > 0 && (
                <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 flex-shrink-0">
                  {group.inferredCount}
                </span>
              )}
              {selecting && isGroupSelected(group) && <Check className="w-3.5 h-3.5 text-primary flex-shrink-0" />}
            </button>
            {group.rows.map(renderRow)}
          </div>
        ))}
      </div>

      <StartListSheet
        competitor={active ? { ...active, id: rowKeyOf(active), status: 'active' } : null}
        competition={REVIEW_COMPETITION}
        competitors={competitors.map((c) => ({ ...c, id: rowKeyOf(c) }))}
        open={!!active}
        onOpenChange={(open) => !open && setOpenKey(null)}
        draft
        onDraftChange={(patch) => {
          if (!active) return;
          // A row that only now got its bib number moves to a new key, so the
          // open competitor view follows it instead of closing.
          if (patch.bib_number != null) setOpenKey(`b${patch.bib_number}`);
          onSave(rowKeyOf(active), patch);
        }}
        onDraftRemove={() => {
          if (active) {
            onRemove(rowKeyOf(active));
            setOpenKey(null);
          }
        }}
      />

      <SeriesBulkDialog
        open={bulkOpen}
        count={selected.length}
        onOpenChange={setBulkOpen}
        onApply={applySeries}
      />
    </div>
  );
}