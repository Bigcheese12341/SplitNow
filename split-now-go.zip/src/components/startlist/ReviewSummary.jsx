import React from 'react';
import { useTranslation } from 'react-i18next';

// The figures shown above the review list. Every number comes from the real
// recognition result; nothing here is estimated.
export default function ReviewSummary({ summary }) {
  const { t } = useTranslation();

  const items = [
    { key: 'total', label: t('create.statsCompetitors'), value: summary.total },
    { key: 'series', label: t('create.statsSeries'), value: summary.seriesCount },
    { key: 'inferred', label: t('create.statsInferred'), value: summary.inferred, tone: 'muted' },
    { key: 'uncertain', label: t('create.statsUncertain'), value: summary.uncertain, tone: 'warn' },
    { key: 'missingBib', label: t('create.statsMissingBib'), value: summary.missingBib, tone: 'warn' },
    { key: 'duplicates', label: t('create.statsDuplicates'), value: summary.duplicates, tone: 'muted' },
  ].filter((item) => item.value > 0 || item.key === 'total' || item.key === 'series');

  return (
    <div className="flex flex-wrap gap-1">
      {items.map((item) => (
        <span
          key={item.key}
          className={`px-1.5 py-0.5 rounded text-[10px] font-semibold leading-tight ${
            item.tone === 'warn' && item.value > 0
              ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
              : 'bg-muted text-muted-foreground'
          }`}
        >
          {item.label} {item.value}
        </span>
      ))}
    </div>
  );
}