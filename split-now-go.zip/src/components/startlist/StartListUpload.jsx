import React from 'react';
import { useTranslation } from 'react-i18next';
import { ImagePlus, Loader2 } from 'lucide-react';
import StartListImageStrip from '@/components/startlist/StartListImageStrip';
import RecognizedCompetitors from '@/components/startlist/RecognizedCompetitors';

// Start list upload panel: hint text, uploaded images (view / remove), the file
// picker itself and the review step for the recognised competitors.
export default function StartListUpload({
  images,
  competitors,
  duplicates,
  uploading,
  onFilesSelected,
  onRemoveImage,
  onSaveCompetitor,
  onRemoveCompetitor,
  onSetSeries,
}) {
  const { t } = useTranslation();

  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">{t('create.uploadHint')}</p>

      <StartListImageStrip images={images} onRemove={onRemoveImage} />

      <label className="flex flex-col items-center justify-center gap-2 h-24 rounded-xl border-2 border-dashed border-border cursor-pointer hover:bg-muted/50 transition-colors">
        {uploading ? (
          <>
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
            <span className="text-sm font-semibold text-muted-foreground">{t('create.recognizing')}</span>
          </>
        ) : (
          <>
            <ImagePlus className="w-6 h-6 text-muted-foreground" />
            <span className="text-sm font-semibold text-muted-foreground">{t('create.addImages')}</span>
          </>
        )}
        <input
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => {
            const files = Array.from(e.target.files || []);
            e.target.value = '';
            onFilesSelected(files);
          }}
          disabled={uploading}
        />
      </label>

      <div className="flex items-center justify-center py-2 bg-primary/5 rounded-xl">
        <span className="text-sm font-semibold text-primary">
          {t('create.competitorCount', { count: competitors.length })}
        </span>
      </div>

      <RecognizedCompetitors
        competitors={competitors}
        duplicates={duplicates}
        onSave={onSaveCompetitor}
        onRemove={onRemoveCompetitor}
        onSetSeries={onSetSeries}
      />
    </div>
  );
}