import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { formatElapsed, formatGap } from '@/lib/timeUtils';
import { RESULT_TIME_CLASS, RESULT_GAP_CLASS } from '@/lib/resultStyles';
import SeriesBadge from '@/components/competition/SeriesBadge';

// The scrolling result rows. Each recently recorded competitor carries its own
// highlight, and only the latest recording moves the list.
export default function LiveResultsList({ rows, competition, highlights, focusToken, active, onCompetitorTap }) {
  const { t } = useTranslation();
  const listRef = useRef(null);
  const appliedRef = useRef(0);

  useEffect(() => {
    if (!active || !focusToken) return;
    if (appliedRef.current === focusToken) return;
    const container = listRef.current;
    if (!container || container.clientHeight === 0) return;
    // The competitor is found by its own stable id, never by its position.
    const row = container.querySelector(`[data-cid="${focusToken.cid}"]`);
    if (!row) return;

    const next = row.nextElementSibling;
    const containerRect = container.getBoundingClientRect();
    const rowRect = row.getBoundingClientRect();

    // At least the next competitor stays visible under the recorded one, and
    // whatever room is left shows the competitors above it.
    const bottomLimit = containerRect.bottom - (next ? next.getBoundingClientRect().height + 2 : 0);

    let delta = 0;
    if (rowRect.bottom > bottomLimit) delta = rowRect.bottom - bottomLimit;
    else if (rowRect.top < containerRect.top) delta = rowRect.top - containerRect.top;

    appliedRef.current = focusToken.ts;
    if (delta === 0) return;

    const maxScroll = container.scrollHeight - container.clientHeight;
    container.scrollTo({
      top: Math.min(Math.max(container.scrollTop + delta, 0), Math.max(maxScroll, 0)),
      behavior: 'smooth',
    });
  }, [focusToken, rows, active]);

  return (
    <div ref={listRef} className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-2 pb-1.5">
      {rows.length === 0 ? (
        <p className="text-center py-8 text-muted-foreground text-sm">{t('results.noResults')}</p>
      ) : (
        <div className="space-y-px">
          {rows.map(c => {
            const highlight = highlights?.[c.id];
            const highlightClass = highlight
              ? highlight.kind === 'leader'
                ? 'bg-green-500/20 border-green-500 ring-2 ring-green-500'
                : 'bg-red-500/20 border-red-500 ring-2 ring-red-500'
              : 'bg-card border-border';

            return (
              <button
                key={c.id}
                data-cid={c.id}
                onClick={() => onCompetitorTap(c)}
                className={`w-full min-h-[33px] flex items-center gap-1.5 px-2 py-0 rounded-lg border active:scale-[0.98] transition-colors duration-200 text-left ${highlightClass}`}
              >
                <span className={`w-6 font-black text-sm tabular-nums text-center flex-shrink-0 ${
                  c.rank === 1 ? 'text-amber-500' : c.rank ? 'text-foreground' : 'text-muted-foreground'
                }`}>
                  {c.rank || '—'}
                </span>
                <span className="w-7 font-semibold tabular-nums text-xs text-muted-foreground/60 flex-shrink-0">{c.bib_number}</span>
                <span className="flex-1 text-sm font-medium truncate leading-tight">{c.name || ''}</span>
                <SeriesBadge competitor={c} competition={competition} />
                {c.isDNS ? (
                  <span className="text-sm font-bold text-slate-500">DNS</span>
                ) : c.isDNF ? (
                  <span className="text-sm font-bold text-red-500">DNF</span>
                ) : c.isDSQ ? (
                  <span className="text-sm font-bold text-blue-500">DSQ</span>
                ) : (
                  <>
                    <span className={`text-right font-mono text-sm tabular-nums ${RESULT_TIME_CLASS}`}>
                      {formatElapsed(c.elapsed)}
                    </span>
                    <span className={`text-right text-sm tabular-nums w-11 ${RESULT_GAP_CLASS}`}>
                      {c.rank === 1 ? '+0' : (c.gap === null ? '—' : formatGap(c.gap))}
                    </span>
                  </>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}