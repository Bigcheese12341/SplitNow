import React from 'react';
import { useTranslation } from 'react-i18next';
import { X, Check } from 'lucide-react';
import { ROLE_STYLES, ROLES } from '@/lib/roleStyles';

export default function PermissionInfoSheet({ onClose }) {
  const { t } = useTranslation();

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        className="relative bg-card rounded-t-3xl shadow-2xl max-h-[85vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 pt-5 pb-4 flex-shrink-0">
          <h2 className="font-black text-xl text-foreground">{t('permissionsInfo.title')}</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full bg-muted">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 px-5 pb-8 space-y-3">
          {ROLES.map(role => {
            const style = ROLE_STYLES[role];
            const labelKey = `members.role${role.charAt(0).toUpperCase() + role.slice(1)}`;
            const items = t(`permissionsInfo.${role}.items`, { returnObjects: true });
            return (
              <div key={role} className={`rounded-2xl p-4 border ${style.border} ${style.bg}`}>
                <p className={`font-black text-base mb-3 ${style.accent}`}>{t(labelKey)}</p>
                <ul className="space-y-2">
                  {items.map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                      <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${style.accent}`} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}