import React from 'react';
import { useTranslation } from 'react-i18next';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { getDefaultSplitLabel } from '@/lib/splitLabels';

// Naming the split points of a competition: one switch and, when it is on, one
// text field per split point, filled with the default names to start from.
export default function SplitNamesEditor({ enabled, names = [], splitCount, disabled, onChange }) {
  const { t } = useTranslation();
  const count = Math.max(1, Number(splitCount) || 1);

  const handleToggle = (checked) => {
    if (!checked) {
      onChange(false, names);
      return;
    }
    const filled = Array.from({ length: count }, (_, i) => {
      const existing = names?.[i];
      return existing && existing.trim() ? existing : getDefaultSplitLabel(i, t);
    });
    onChange(true, filled);
  };

  const handleNameChange = (index, value) => {
    const next = Array.from({ length: count }, (_, i) =>
      i === index ? value : (names?.[i] || '')
    );
    onChange(true, next);
  };

  return (
    <div className="pt-3 mt-3 border-t border-border space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="font-bold text-sm">{t('splitNames.toggle')}</div>
          <div className="text-xs text-muted-foreground">{t('splitNames.toggleSub')}</div>
        </div>
        <Switch checked={!!enabled} onCheckedChange={handleToggle} disabled={disabled} />
      </div>

      {enabled && (
        <div className="space-y-2">
          {Array.from({ length: count }, (_, i) => (
            <div key={i} className="space-y-1">
              <Label
                htmlFor={`split-name-${i}`}
                className="text-xs font-semibold text-muted-foreground"
              >
                {t('splitNames.point', { n: i + 1 })}
              </Label>
              <Input
                id={`split-name-${i}`}
                value={names?.[i] || ''}
                onChange={(e) => handleNameChange(i, e.target.value)}
                placeholder={getDefaultSplitLabel(i, t)}
                disabled={disabled}
                maxLength={40}
                className="h-11 rounded-xl text-base"
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}