import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { RotateCcw, Loader2 } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

export default function QuickTouchStatusBar({ liveTime, totalRecorded, totalRequired, progressPct, lastEntry, onUndo }) {
  const { t } = useTranslation();
  const [undoing, setUndoing] = useState(false);

  const handleUndo = async () => {
    setUndoing(true);
    try { await onUndo(); } finally { setUndoing(false); }
  };

  return (
    <div className="bg-card border-b border-border">
      <div className="max-w-3xl mx-auto px-4 py-2.5 flex items-center gap-3">
        <div className="text-center flex-shrink-0">
          <div className="text-xs text-muted-foreground font-medium">{t('splitTime.clock')}</div>
          <div className="font-mono font-bold text-sm tabular-nums">{liveTime}</div>
        </div>
        <div className="flex-1 px-2">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-muted-foreground">{totalRecorded} / {totalRequired}</span>
            <span className="text-xs font-bold text-primary">{progressPct}%</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${progressPct}%` }} />
          </div>
        </div>
        <AnimatePresence>
          {lastEntry && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={handleUndo}
              disabled={undoing}
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400 text-xs font-bold border border-amber-300 dark:border-amber-500/30 active:scale-95 transition-transform disabled:opacity-60 flex-shrink-0"
            >
              {undoing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
              {t('splitTime.undo')}
            </motion.button>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}