import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import LiveResultsPanelHeader from '@/components/competition/LiveResultsPanelHeader';
import LiveResultsCompactBar from '@/components/competition/LiveResultsCompactBar';
import LiveResultsList from '@/components/competition/LiveResultsList';
import { buildResultList } from '@/lib/comparisonUtils';
import { SERIES_ALL, buildSeriesOptions } from '@/lib/seriesUtils';
import { useSeriesPalette } from '@/lib/seriesPalette';
import { getSplitLabel, getTotalPoints } from '@/lib/quickTouchPrefs';

// Height of the closed panel: the drag handle with its title plus the feedback row.
const CLOSED_HEIGHT = 72;
const SNAPS = ['closed', 'half', 'full'];
const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

export default function LiveResultsPanel({
  competitors,
  competition,
  snap,
  onSnapChange,
  onHeightChange,
  feedback,
  onFeedbackTap,
  focusEvent,
  highlights,
  onCompetitorTap,
}) {
  const { t } = useTranslation();
  const [viewportHeight, setViewportHeight] = useState(() => (typeof window === 'undefined' ? 800 : window.innerHeight));
  const [dragHeight, setDragHeight] = useState(null);
  const [selectedSplit, setSelectedSplit] = useState(0);
  const [seriesValue, setSeriesValue] = useState(SERIES_ALL);
  const dragRef = useRef(null);
  const lastFocusRef = useRef(0);

  const heights = useMemo(() => ({
    closed: CLOSED_HEIGHT,
    half: Math.max(220, Math.round(viewportHeight * 0.36)),
    full: Math.max(320, viewportHeight - 8),
  }), [viewportHeight]);

  useEffect(() => {
    const onResize = () => setViewportHeight(window.innerHeight);
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('orientationchange', onResize);
    };
  }, []);

  const closed = snap === 'closed';
  const height = dragHeight ?? heights[snap] ?? heights.closed;

  // The recording view keeps its room above the panel so every button can be
  // scrolled into reach.
  useEffect(() => { onHeightChange?.(height); }, [height, onHeightChange]);

  const totalPoints = getTotalPoints(competition);
  const seriesOptions = useMemo(
    () => buildSeriesOptions(competitors, competition, t),
    [competitors, competition, t]
  );
  const activeSeries = seriesOptions.items.some(option => option.value === seriesValue)
    ? seriesValue
    : SERIES_ALL;
  const activeSplit = selectedSplit < totalPoints ? selectedSplit : 0;

  const timingPoints = useMemo(
    () => Array.from({ length: totalPoints }, (_, i) => ({ index: i, label: getSplitLabel(i, competition, t) })),
    [totalPoints, competition, t]
  );

  useSeriesPalette(competitors, competition);

  const rows = useMemo(
    () => buildResultList(competitors, competition, activeSplit, activeSeries),
    [competitors, competition, activeSplit, activeSeries]
  );

  // A new recording switches the list to that split and the competitor's series.
  useEffect(() => {
    if (!focusEvent || snap === 'closed') return;
    if (lastFocusRef.current === focusEvent.ts) return;
    lastFocusRef.current = focusEvent.ts;
    if (focusEvent.splitIndex !== undefined && focusEvent.splitIndex < totalPoints) {
      setSelectedSplit(focusEvent.splitIndex);
    }
    const hasSeries = !!focusEvent.seriesKey
      && seriesOptions.items.some(option => option.value === focusEvent.seriesKey);
    setSeriesValue(hasSeries ? focusEvent.seriesKey : SERIES_ALL);
  }, [focusEvent, snap, totalPoints, seriesOptions]);

  const handleToggle = () => onSnapChange(closed ? 'half' : 'closed');

  // The list may only scroll once the split and the series it shows are the ones
  // the recording asked for, so a quick series or split change can never park
  // the list at a competitor that belongs to another view.
  const expectedSeries = focusEvent?.seriesKey
    && seriesOptions.items.some(option => option.value === focusEvent.seriesKey)
    ? focusEvent.seriesKey
    : SERIES_ALL;
  const focusToken = focusEvent
    && focusEvent.splitIndex === activeSplit
    && activeSeries === expectedSeries
    ? { ts: focusEvent.ts, cid: focusEvent.competitorId }
    : null;

  const handlePointerDown = (e) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if (e.target.closest('button')) return;
    const startHeight = heights[snap] ?? heights.closed;
    dragRef.current = { startY: e.clientY, startHeight, currentHeight: startHeight };
    setDragHeight(startHeight);
    try { e.currentTarget.setPointerCapture?.(e.pointerId); } catch { /* capture is optional */ }
  };

  const handlePointerMove = (e) => {
    const drag = dragRef.current;
    if (!drag) return;
    const next = clamp(drag.startHeight + (drag.startY - e.clientY), heights.closed, heights.full);
    drag.currentHeight = next;
    setDragHeight(next);
  };

  const handlePointerEnd = () => {
    const drag = dragRef.current;
    if (!drag) return;
    dragRef.current = null;
    setDragHeight(null);
    const nearest = SNAPS
      .map(key => ({ key, distance: Math.abs(heights[key] - drag.currentHeight) }))
      .sort((a, b) => a.distance - b.distance)[0];
    if (nearest && nearest.key !== snap) onSnapChange(nearest.key);
  };

  if (!competition) return null;

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border rounded-t-2xl shadow-[0_-6px_24px_rgba(0,0,0,0.18)] flex flex-col"
      style={{
        height,
        transition: dragHeight === null ? 'height 220ms cubic-bezier(0.22, 1, 0.36, 1)' : 'none',
      }}
    >
      <div
        className="flex-shrink-0 touch-none select-none cursor-grab active:cursor-grabbing"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerEnd}
        onPointerCancel={handlePointerEnd}
      >
        {closed ? (
          <LiveResultsPanelHeader
            closed
            feedback={feedback}
            onFeedbackTap={onFeedbackTap}
            onToggle={handleToggle}
          />
        ) : (
          <>
            {/* An empty grab strip above the pickers: the top edge of the panel
                stays draggable instead of the swipe landing on a button. The title
                sits in this strip so no existing control has to move for it. */}
            <div className="relative flex items-center justify-center pt-3 pb-2">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-foreground">
                {t('quickTouch.liveResults')}
              </span>
              <div className="w-10 h-1.5 rounded-full bg-border" />
            </div>
            <LiveResultsCompactBar
              timingPoints={timingPoints}
              selectedSplit={activeSplit}
              onSplitChange={setSelectedSplit}
              seriesOptions={seriesOptions}
              seriesValue={activeSeries}
              onSeriesChange={setSeriesValue}
              onToggle={handleToggle}
            />
          </>
        )}
      </div>

      <div className={`flex-1 min-h-0 flex flex-col ${closed ? 'invisible' : ''}`}>
        <LiveResultsList
          rows={rows}
          competition={competition}
          highlights={highlights}
          focusToken={focusToken}
          active={!closed}
          onCompetitorTap={onCompetitorTap}
        />
      </div>
    </div>
  );
}