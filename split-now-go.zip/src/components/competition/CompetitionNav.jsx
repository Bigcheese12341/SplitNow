import React, { useState, useEffect } from 'react';
import { Link, useParams, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { List, Timer, Trophy, Flag, ArrowLeft, ChevronDown, ChevronRight, X, Settings, Zap } from 'lucide-react';
import { useUserRole } from '@/lib/permissions';
import SyncStatusIcon from '@/components/competition/SyncStatusIcon';
import { goBack } from '@/lib/navHistory';
import { useViewMode } from '@/lib/quickTouchPrefs';
import { getSplitLabel } from '@/lib/splitLabels';

export default function CompetitionNav({ competition }) {
  const { t } = useTranslation();
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (competition?.id) {
      localStorage.setItem('lastVisitedCompetition', competition.id);
    }
  }, [competition?.id]);

  const splitCount = competition?.split_count || 1;
  const addFinish = competition?.add_finish;
  const { permissions, user } = useUserRole(id);
  const [viewMode] = useViewMode(user?.id, id);

  const isEditPage = location.pathname.includes('/edit');
  const isPublicPage = location.pathname.includes('/public');
  const isSyncPage = location.pathname.includes('/startlist') ||
    location.pathname.includes('/split/') ||
    location.pathname.includes('/results') ||
    location.pathname.includes('/quicktouch');
  const shouldShowSync = !isEditPage && !isPublicPage && isSyncPage &&
    (permissions.canRecordTimes || permissions.canEditCompetitors);

  const today = new Date().toISOString().split('T')[0];
  const isFinished = competition?.status === 'finished';
  const isUpcoming = competition?.date > today;
  const statusKey = isFinished ? 'statusFinished' : isUpcoming ? 'statusUpcoming' : 'statusActive';
  const statusColor = isFinished
    ? 'bg-red-100 text-red-600 dark:bg-red-500/20 dark:text-red-400'
    : isUpcoming
      ? 'bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400'
      : 'bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400';

  const getCurrentTitle = () => {
    if (isEditPage) return t('nav.competitionSettings');
    if (location.pathname.includes('/startlist')) return t('nav.startList');
    if (location.pathname.includes('/quicktouch')) return t('quickTouch.title');
    if (location.pathname.includes('/results')) return t('nav.results');
    if (location.pathname.includes('/split/')) {
      const splitNum = location.pathname.split('/split/')[1];
      if (addFinish && Number(splitNum) === splitCount + 1) return t('nav.finish');
      return getSplitLabel(Number(splitNum) - 1, competition, t, 'nav.splitTime');
    }
    return t('nav.competition');
  };

  const navItems = viewMode === 'quicktouch'
    ? [
        { label: t('nav.startList'), icon: List, path: `/competition/${id}/startlist` },
        ...(permissions.canViewSplits ? [
          { label: t('quickTouch.title'), icon: Zap, path: `/competition/${id}/quicktouch` },
        ] : []),
        { label: t('nav.results'), icon: Trophy, path: `/competition/${id}/results` },
      ]
    : [
        { label: t('nav.startList'), icon: List, path: `/competition/${id}/startlist` },
        ...(permissions.canViewSplits ? [
          ...Array.from({ length: splitCount }, (_, i) => ({
            label: getSplitLabel(i, competition, t, 'nav.splitTime'),
            icon: Timer,
            path: `/competition/${id}/split/${i + 1}`,
          })),
          ...(addFinish ? [{ label: t('nav.finish'), icon: Flag, path: `/competition/${id}/split/${splitCount + 1}` }] : []),
        ] : []),
        { label: t('nav.results'), icon: Trophy, path: `/competition/${id}/results` },
      ];

  const handleNav = (path) => {
    setOpen(false);
    navigate(path);
  };

  return (
    <>
      <div className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-lg mx-auto px-3 h-14 flex items-center gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <button onClick={() => goBack(navigate)} className="flex items-center justify-center w-9 h-9 rounded-full hover:bg-muted transition-colors flex-shrink-0">
              <ArrowLeft className="w-5 h-5 text-muted-foreground" />
            </button>
            <p className="font-black text-base leading-tight text-foreground truncate min-w-0">{competition?.name || '…'}</p>
          </div>
          {!isEditPage && !isPublicPage && (
            <button
              onClick={() => setOpen(true)}
              className="flex items-center gap-1 bg-primary text-primary-foreground font-bold text-sm px-3 h-8 rounded-full shadow-sm shadow-primary/30 active:scale-95 transition-transform flex-shrink-0"
            >
              {getCurrentTitle()}
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          )}
          <div className={`flex items-center gap-2 justify-end min-w-0 ${!isEditPage && !isPublicPage ? 'flex-1' : 'flex-shrink-0'}`}>
            {isPublicPage && (
              <span className={`text-xs font-bold px-3 h-8 rounded-full flex items-center flex-shrink-0 ${statusColor}`}>
                {t(`home.${statusKey}`)}
              </span>
            )}
            {shouldShowSync && <SyncStatusIcon />}
            {!isEditPage && !isPublicPage && (
              <Link
                to={`/competition/${id}/edit`}
                className="flex items-center justify-center w-9 h-9 rounded-full hover:bg-muted transition-colors"
              >
                <Settings className="w-5 h-5 text-muted-foreground" />
              </Link>
            )}
          </div>
        </div>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div
            className="relative bg-card rounded-t-3xl shadow-2xl pb-safe max-h-[85vh] flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 pt-4 pb-2">
              <div className="w-10 h-1 bg-muted rounded-full mx-auto absolute left-1/2 -translate-x-1/2 top-3" />
              <p className="font-black text-lg text-foreground">{competition?.name}</p>
              <button onClick={() => setOpen(false)} className="w-8 h-8 flex items-center justify-center rounded-full bg-muted">
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            <div className="px-4 pb-8 pt-2 space-y-2 overflow-y-auto flex-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <button
                    key={item.path}
                    onClick={() => handleNav(item.path)}
                    className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all active:scale-[0.98] ${
                      isActive
                        ? 'bg-primary text-primary-foreground shadow-md shadow-primary/25'
                        : 'bg-muted text-foreground hover:bg-muted/80'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      isActive ? 'bg-white/20' : 'bg-card shadow-sm'
                    }`}>
                      <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-primary'}`} />
                    </div>
                    <span className="font-bold text-base flex-1 text-left">{item.label}</span>
                    {!isActive && <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                    {isActive && <span className="text-white/80 text-xs font-semibold">{t('nav.onThisPage')}</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
}