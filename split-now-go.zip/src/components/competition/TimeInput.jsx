import React, { useState, useRef, useEffect } from 'react';

function parseValueToDigits(v) {
  if (!v) return ['0', '0', '0', '0', '0', '0'];
  const clean = String(v).replace(/:/g, '').replace(/\D/g, '').padStart(6, '0');
  return clean.slice(-6).split('');
}

export default function TimeInput({ value, onChange, disabled, className, fluid = false }) {
  const [digits, setDigits] = useState(() => parseValueToDigits(value));
  const refs = useRef([]);

  useEffect(() => {
    setDigits(parseValueToDigits(value));
  }, [value]);

  const commit = (d) => {
    onChange(`${d[0]}${d[1]}:${d[2]}${d[3]}:${d[4]}${d[5]}`);
  };

  const focusBox = (i) => {
    const el = refs.current[i];
    if (el) {
      el.focus();
      el.select();
    }
  };

  const handleChange = (i, e) => {
    const raw = e.target.value.replace(/\D/g, '');
    if (raw.length > 1) {
      // Multi-digit input (fast typing or paste fallback): distribute from current box
      const next = [...digits];
      let idx = i;
      for (const ch of raw) {
        if (idx >= 6) break;
        next[idx] = ch;
        idx++;
      }
      setDigits(next);
      commit(next);
      focusBox(Math.min(idx, 5));
      return;
    }
    const digit = raw.slice(-1);
    if (!digit) return;
    const next = [...digits];
    next[i] = digit;
    setDigits(next);
    commit(next);
    if (i < 5) focusBox(i + 1);
  };

  const handleKeyDown = (i, e) => {
    if (e.key === 'Backspace') {
      e.preventDefault();
      const next = [...digits];
      if (next[i] !== '0') {
        next[i] = '0';
        setDigits(next);
        commit(next);
      } else if (i > 0) {
        next[i - 1] = '0';
        setDigits(next);
        commit(next);
        focusBox(i - 1);
      }
    } else if (e.key === 'ArrowLeft' && i > 0) {
      e.preventDefault();
      focusBox(i - 1);
    } else if (e.key === 'ArrowRight' && i < 5) {
      e.preventDefault();
      focusBox(i + 1);
    }
  };

  const handlePaste = (i, e) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '');
    if (!pasted) return;
    const next = [...digits];
    let idx = i;
    for (const ch of pasted) {
      if (idx >= 6) break;
      next[idx] = ch;
      idx++;
    }
    setDigits(next);
    commit(next);
    focusBox(Math.min(idx, 5));
  };

  // `fluid` lets the boxes share the available width instead of using a fixed
  // width, so the six digits and both colons always fit a narrow phone screen
  // (or a form field that sits next to another one) without overflowing.
  const inputClass = fluid
    ? 'flex-1 basis-0 min-w-0 max-w-12 h-11 text-center bg-muted rounded-lg text-base font-bold font-mono tabular-nums border border-input focus:ring-2 focus:ring-ring focus:border-primary outline-none disabled:opacity-50 transition-colors'
    : 'w-9 h-12 text-center bg-muted rounded-lg text-lg font-bold font-mono tabular-nums border border-input focus:ring-2 focus:ring-ring focus:border-primary outline-none disabled:opacity-50 transition-colors';

  return (
    <div className={`flex items-center justify-center gap-1 ${fluid ? 'w-full' : ''} ${className || ''}`}>
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <React.Fragment key={i}>
          <input
            ref={(el) => { refs.current[i] = el; }}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={digits[i]}
            disabled={disabled}
            onChange={(e) => handleChange(i, e)}
            onKeyDown={(e) => handleKeyDown(i, e)}
            onPaste={(e) => handlePaste(i, e)}
            onFocus={(e) => e.target.select()}
            className={inputClass}
          />
          {(i === 1 || i === 3) && (
            <span className="font-bold text-muted-foreground text-lg select-none">:</span>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}