import React, { memo } from 'react';
import { useTranslation } from 'react-i18next';
import { Check } from 'lucide-react';
import { getTotalPoints, getCompetitorProgress, getButtonColor, isFullyRecorded } from '@/lib/quickTouchPrefs';
import { competitorSeriesLabel, seriesIdentity } from '@/lib/seriesUtils';
import { seriesColorFor } from '@/lib/seriesPalette';

function QuickTouchGrid({ competitors, competition, onPress }) {
  const { t } = useTranslation();
  const totalPoints = getTotalPoints(competition);

  if (competitors.length === 0) {
    return <div className="text-center py-12 text-muted-foreground">{t('quickTouch.noCompetitors')}</div>;
  }

  const count = competitors.length;
  let cols;
  let showName = false;
  if (count <= 20) {
    cols = 2;
    showName = true;
  } else if (count <= 50) {
    cols = 5;
  } else {
    cols = 6;
  }

  return (
    <div
      className="grid gap-1.5"
      style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
    >
      {competitors.map(c => {
        const progress = getCompetitorProgress(c);
        const color = getButtonColor(progress);
        const allDone = isFullyRecorded(c, competition);
        const status = c.status || 'active';
        const isInactive = status === 'DNS' || status === 'DNF' || status === 'DSQ';
        const seriesText = showName && !isInactive ? competitorSeriesLabel(c, competition, t) : null;

        const style = isInactive
          ? { backgroundColor: '#6b7280', color: '#FFFFFF', opacity: 0.5 }
          : { backgroundColor: color.bg, color: color.text, opacity: allDone ? 0.65 : 1 };

        return (
          <button
            key={c.id}
            onClick={() => onPress(c)}
            disabled={isInactive}
            style={style}
            className="relative rounded-xl p-2 min-h-[3.5rem] active:scale-95 transition-transform select-none overflow-hidden"
          >
            {showName ? (
              <div className="flex items-center gap-2 h-full">
                <span className="text-lg font-black tabular-nums leading-none flex-shrink-0">{c.bib_number}</span>
                <span className="text-xs font-medium truncate min-w-0 opacity-90 leading-tight flex-1 text-left">
                  {c.name || ''}
                </span>
                {totalPoints > 0 && (
                  <span className="text-[10px] font-bold tabular-nums flex-shrink-0 leading-none">
                    {allDone ? (
                      <span className="flex items-center gap-0.5"><Check className="w-2.5 h-2.5" />{progress}/{totalPoints}</span>
                    ) : (
                      `${progress}/${totalPoints}`
                    )}
                  </span>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full gap-0.5">
                <span className="text-lg font-black tabular-nums leading-none">{c.bib_number}</span>
                {totalPoints > 0 && (
                  <span className="text-[10px] font-bold tabular-nums leading-none">
                    {allDone ? (
                      <span className="flex items-center gap-0.5"><Check className="w-2.5 h-2.5" />{progress}/{totalPoints}</span>
                    ) : (
                      `${progress}/${totalPoints}`
                    )}
                  </span>
                )}
                {isInactive && (
                  <span className="text-[9px] font-black leading-none">{status}</span>
                )}
              </div>
            )}
            {isInactive && showName && (
              <span className="text-[9px] font-black absolute top-1 right-1.5">{status}</span>
            )}
            {seriesText && (
              <span className={`text-[9px] font-bold leading-none px-1 py-0.5 rounded absolute top-0.5 right-1 ${seriesColorFor(seriesIdentity(c), competition?.id)}`}>
                {seriesText}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

export default memo(QuickTouchGrid);