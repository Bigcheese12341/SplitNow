import React from 'react';
import { useTranslation } from 'react-i18next';
import { Switch } from '@/components/ui/switch';

// Switches the competition start time field between the device's own time
// picker and the app's second-precision input. Changing it never touches the
// start time that is already set.
export default function SecondsPrecisionToggle({ checked, onChange, disabled }) {
  const { t } = useTranslation();

  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <div className="font-bold text-sm">{t('create.secondPrecision')}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{t('create.secondPrecisionSub')}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} disabled={disabled} />
    </div>
  );
}