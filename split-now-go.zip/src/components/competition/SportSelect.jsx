import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem, SelectSeparator } from '@/components/ui/select';
import { Input } from '@/components/ui/input';

const SPORTS = [
  'Alppihiihto',
  'Ampumahiihto',
  'Hiihtosuunnistus',
  'Juoksu',
  'Kävely',
  'Luistelu',
  'Maastohiihto',
  'Maastopyöräily',
  'Maantiepyöräily',
  'Rullahiihto',
  'Suunnistus',
  'Triathlon',
  'Uinti',
];

const OTHER = '__other__';

export default function SportSelect({ value, onChange, disabled }) {
  const { t } = useTranslation();
  const isPreset = SPORTS.includes(value);
  const [selectValue, setSelectValue] = useState(isPreset ? value : (value ? OTHER : ''));
  const [customText, setCustomText] = useState(isPreset ? '' : (value || ''));

  useEffect(() => {
    if (SPORTS.includes(value)) {
      setSelectValue(value);
      setCustomText('');
    } else if (value) {
      setSelectValue(OTHER);
      setCustomText(value);
    } else {
      setSelectValue('');
      setCustomText('');
    }
  }, [value]);

  const handleSelectChange = (val) => {
    setSelectValue(val);
    if (val === OTHER) {
      onChange(customText || '');
    } else {
      setCustomText('');
      onChange(val);
    }
  };

  const handleCustomChange = (e) => {
    const text = e.target.value;
    setCustomText(text);
    onChange(text);
  };

  return (
    <div className="space-y-2">
      <Select value={selectValue} onValueChange={handleSelectChange} disabled={disabled}>
        <SelectTrigger className="h-12 rounded-xl text-base font-medium border-input bg-transparent">
          <SelectValue placeholder={t('sport.selectPlaceholder')} />
        </SelectTrigger>
        <SelectContent className="rounded-xl max-h-[300px]">
          {SPORTS.map((sport) => (
            <SelectItem key={sport} value={sport} className="text-base py-2.5 rounded-lg">
              {t(`sport.${sport}`)}
            </SelectItem>
          ))}
          <SelectSeparator />
          <SelectItem value={OTHER} className="text-base py-2.5 rounded-lg font-semibold">
            {t('sport.other')}
          </SelectItem>
        </SelectContent>
      </Select>

      {selectValue === OTHER && (
        <Input
          value={customText}
          onChange={handleCustomChange}
          disabled={disabled}
          placeholder={t('sport.otherPlaceholder')}
          className="h-12 rounded-xl text-base"
        />
      )}
    </div>
  );
}