import React from 'react';
import { useTranslation } from 'react-i18next';
import { Search, X } from 'lucide-react';

export default function CompetitorSearch({ value, onChange }) {
  const { t } = useTranslation();
  return (
    <div className="relative mb-3">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full h-10 pl-10 pr-9 rounded-xl bg-muted border border-border outline-none text-sm focus-visible:ring-1 focus-visible:ring-ring"
        placeholder={t('common.searchCompetitor')}
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="absolute right-2.5 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center rounded-full hover:bg-muted-foreground/10"
        >
          <X className="w-3.5 h-3.5 text-muted-foreground" />
        </button>
      )}
    </div>
  );
}

export const matchCompetitor = (competitor, query) => {
  const q = query.toLowerCase().trim();
  if (!q) return true;
  return String(competitor.bib_number).includes(q) || (competitor.name || '').toLowerCase().includes(q);
};