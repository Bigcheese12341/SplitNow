import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { Copy, Share2, QrCode, Users, Check, Eye, Timer, Pencil, Crown, Globe, Lock } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

const ROLES = [
  { value: 'viewer', label: 'Katselija', icon: Eye, desc: 'Näkee lähtölistan, väliajat ja tulokset' },
  { value: 'recorder', label: 'Kirjaaja', icon: Timer, desc: 'Voi kirjata väliaikoja' },
  { value: 'editor', label: 'Muokkaaja', icon: Pencil, desc: 'Voi muokata asetuksia ja kilpailijoita' },
];

function generateCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export default function ShareCompetition({ competition, id }) {
  const queryClient = useQueryClient();
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);

  const joinCode = competition?.join_code;
  const joinRole = competition?.join_role || 'viewer';
  const isPublic = competition?.is_public || false;
  const joinUrl = `${window.location.origin}/?join=${joinCode}`;

  const ensureCode = async () => {
    if (joinCode) return joinCode;
    const code = generateCode();
    setSaving(true);
    await base44.entities.Competition.update(id, { join_code: code });
    queryClient.invalidateQueries({ queryKey: ['competition', id] });
    setSaving(false);
    return code;
  };

  const handleCopy = async () => {
    const code = await ensureCode();
    const url = `${window.location.origin}/?join=${code}`;
    await navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    const code = await ensureCode();
    const url = `${window.location.origin}/?join=${code}`;
    if (navigator.share) {
      navigator.share({ title: competition?.name, text: `Liity kilpailuun: ${competition?.name}`, url });
    } else {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const updateJoinRole = async (role) => {
    await base44.entities.Competition.update(id, { join_role: role });
    queryClient.invalidateQueries({ queryKey: ['competition', id] });
  };

  const togglePublic = async () => {
    const code = !isPublic && !joinCode ? generateCode() : joinCode;
    await base44.entities.Competition.update(id, {
      is_public: !isPublic,
      ...(code && !joinCode ? { join_code: code } : {}),
    });
    queryClient.invalidateQueries({ queryKey: ['competition', id] });
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-4 space-y-4">
      <div className="flex items-center gap-2 text-sm font-bold text-foreground">
        <Users className="w-4 h-4 text-primary" />
        Jakaminen
      </div>

      {/* Public toggle */}
      <div className="flex items-center justify-between p-3 bg-muted rounded-xl">
        <div className="flex items-center gap-2">
          {isPublic ? <Globe className="w-4 h-4 text-primary" /> : <Lock className="w-4 h-4 text-muted-foreground" />}
          <div>
            <p className="text-sm font-bold">{isPublic ? 'Julkinen kilpailu' : 'Yksityinen kilpailu'}</p>
            <p className="text-xs text-muted-foreground">{isPublic ? 'Koodilla liittyminen käytössä' : 'Vain kutsulla'}</p>
          </div>
        </div>
        <button
          onClick={togglePublic}
          className={`w-12 h-6 rounded-full transition-colors relative ${isPublic ? 'bg-primary' : 'bg-muted-foreground/30'}`}
        >
          <div className={`w-5 h-5 rounded-full bg-white shadow absolute top-0.5 transition-transform ${isPublic ? 'translate-x-6' : 'translate-x-0.5'}`} />
        </button>
      </div>

      {isPublic && (
        <>
          {/* Join code display */}
          <div className="text-center py-4 bg-primary/5 rounded-2xl border border-primary/20">
            {joinCode ? (
              <>
                <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1">Tunnusluku</p>
                <p className="text-5xl font-black tracking-[0.3em] text-primary">{joinCode}</p>
              </>
            ) : (
              <button
                onClick={ensureCode}
                disabled={saving}
                className="text-primary font-bold text-sm"
              >
                {saving ? 'Luodaan...' : '+ Luo tunnusluku'}
              </button>
            )}
          </div>

          {/* QR code */}
          {joinCode && (
            <div className="flex flex-col items-center gap-2">
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">QR-koodi</p>
              <div className="bg-white p-2 rounded-xl border border-border">
                <QRCodeSVG value={joinUrl} size={144} level="M" />
              </div>
            </div>
          )}

          {/* Action buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center justify-center gap-2 h-11 rounded-xl bg-muted font-bold text-sm active:scale-[0.98] transition-all"
            >
              {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Kopioitu!' : 'Kopioi linkki'}
            </button>
            <button
              onClick={handleShare}
              className="flex items-center justify-center gap-2 h-11 rounded-xl bg-primary text-white font-bold text-sm active:scale-[0.98] transition-all shadow-md shadow-primary/25"
            >
              <Share2 className="w-4 h-4" />
              Jaa
            </button>
          </div>

          {/* Role picker */}
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">Liittyvien oletusrooli</p>
            <div className="space-y-2">
              {ROLES.map(role => {
                const Icon = role.icon;
                const isActive = joinRole === role.value;
                return (
                  <button
                    key={role.value}
                    onClick={() => updateJoinRole(role.value)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border-2 text-left transition-all ${
                      isActive ? 'border-primary bg-primary/5' : 'border-border bg-card'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      isActive ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-bold">{role.label}</p>
                      <p className="text-xs text-muted-foreground">{role.desc}</p>
                    </div>
                    {isActive && <Check className="w-4 h-4 text-primary ml-auto" />}
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}