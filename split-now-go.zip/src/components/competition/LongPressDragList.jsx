import React, { useState, useRef, useEffect, useCallback } from 'react';

const LONG_PRESS_MS = 500;
const MOVE_CANCEL_PX = 10;
const EDGE_PX = 80;
const EDGE_SCROLL_SPEED = 15;

export default function LongPressDragList({
  items,
  onReorder,
  onTap,
  canReorder,
  isItemDisabled,
  renderItem,
  keyField = 'id',
}) {
  const [draggingId, setDraggingId] = useState(null);
  const [localItems, setLocalItems] = useState(items);
  const [pointerY, setPointerY] = useState(0);
  const [didDrag, setDidDrag] = useState(false);

  const timerRef = useRef(null);
  const startYRef = useRef(0);
  const rowRefs = useRef({});
  const edgeScrollRef = useRef(null);
  const dragIdRef = useRef(null);
  const localItemsRef = useRef(items);
  const originalItemsRef = useRef(items);
  const dragInfoRef = useRef({ height: 0, left: 0, width: 0 });
  const pointerYRef = useRef(0);
  const onReorderRef = useRef(onReorder);
  const onTapRef = useRef(onTap);
  const canReorderRef = useRef(canReorder);
  const keyFieldRef = useRef(keyField);
  const isItemDisabledRef = useRef(isItemDisabled);

  useEffect(() => { localItemsRef.current = localItems; }, [localItems]);
  useEffect(() => { dragIdRef.current = draggingId; }, [draggingId]);
  useEffect(() => { onReorderRef.current = onReorder; }, [onReorder]);
  useEffect(() => { onTapRef.current = onTap; }, [onTap]);
  useEffect(() => { canReorderRef.current = canReorder; }, [canReorder]);
  useEffect(() => { keyFieldRef.current = keyField; }, [keyField]);
  useEffect(() => { isItemDisabledRef.current = isItemDisabled; }, [isItemDisabled]);

  useEffect(() => {
    if (!draggingId) {
      setLocalItems(items);
      localItemsRef.current = items;
      originalItemsRef.current = items;
    }
  }, [items, draggingId]);

  useEffect(() => () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    stopEdgeScroll();
  }, []);

  const stopEdgeScroll = useCallback(() => {
    if (edgeScrollRef.current) {
      cancelAnimationFrame(edgeScrollRef.current);
      edgeScrollRef.current = null;
    }
  }, []);

  const startEdgeScroll = useCallback((dir) => {
    if (edgeScrollRef.current) return;
    const scroll = () => {
      window.scrollBy(0, dir * EDGE_SCROLL_SPEED);
      edgeScrollRef.current = requestAnimationFrame(scroll);
    };
    edgeScrollRef.current = requestAnimationFrame(scroll);
  }, []);

  const handlePointerDown = useCallback((e, item) => {
    if (!canReorderRef.current) return;
    if (isItemDisabledRef.current?.(item)) return;
    if (e.target.closest('button, input, a, [contenteditable]')) return;

    setDidDrag(false);
    startYRef.current = e.clientY;

    // Cancel long-press if user moves before timer fires (allows scrolling)
    const cancelMove = (ev) => {
      if (Math.abs(ev.clientY - startYRef.current) > MOVE_CANCEL_PX) {
        if (timerRef.current) {
          clearTimeout(timerRef.current);
          timerRef.current = null;
        }
        window.removeEventListener('pointermove', cancelMove);
      }
    };
    window.addEventListener('pointermove', cancelMove);

    timerRef.current = setTimeout(() => {
      window.removeEventListener('pointermove', cancelMove);
      const kf = keyFieldRef.current;
      const row = rowRefs.current[item[kf]];
      if (row) {
        const rect = row.getBoundingClientRect();
        dragInfoRef.current = { height: rect.height, left: rect.left, width: rect.width };
      }
      setDraggingId(item[kf]);
      setDidDrag(true);
      setPointerY(e.clientY);
      pointerYRef.current = e.clientY;
      if (navigator.vibrate) navigator.vibrate(50);
    }, LONG_PRESS_MS);
  }, []);

  useEffect(() => {
    if (!draggingId) return;

    const handleMove = (e) => {
      const y = e.clientY;
      pointerYRef.current = y;
      setPointerY(y);

      const items = localItemsRef.current;
      const dId = dragIdRef.current;
      const kf = keyFieldRef.current;

      const currentIdx = items.findIndex(i => i[kf] === dId);
      if (currentIdx === -1) return;

      let hoverIdx = currentIdx;
      for (let i = 0; i < items.length; i++) {
        if (items[i][kf] === dId) continue;
        const row = rowRefs.current[items[i][kf]];
        if (!row) continue;
        const rect = row.getBoundingClientRect();
        const middle = rect.top + rect.height / 2;
        if (y < middle) {
          hoverIdx = i;
          break;
        }
        if (i === items.length - 1) {
          hoverIdx = items.length;
        }
      }

      if (hoverIdx !== currentIdx && hoverIdx >= 0 && hoverIdx <= items.length) {
        const arr = [...items];
        const [moved] = arr.splice(currentIdx, 1);
        const insertAt = hoverIdx > currentIdx ? hoverIdx - 1 : hoverIdx;
        arr.splice(insertAt, 0, moved);
        localItemsRef.current = arr;
        setLocalItems(arr);
      }

      const vh = window.innerHeight;
      if (y < EDGE_PX) startEdgeScroll(-1);
      else if (y > vh - EDGE_PX) startEdgeScroll(1);
      else stopEdgeScroll();
    };

    const handleUp = () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
      stopEdgeScroll();

      const items = localItemsRef.current;
      const original = originalItemsRef.current;
      const kf = keyFieldRef.current;
      const changed = items.length !== original.length ||
        items.some((item, i) => item[kf] !== original[i]?.[kf]);

      if (changed) {
        onReorderRef.current(items);
      }

      setDraggingId(null);
      setPointerY(0);
      setTimeout(() => setDidDrag(false), 50);
    };

    window.addEventListener('pointermove', handleMove);
    window.addEventListener('pointerup', handleUp);
    window.addEventListener('pointercancel', handleUp);

    return () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
      window.removeEventListener('pointercancel', handleUp);
    };
  }, [draggingId, startEdgeScroll, stopEdgeScroll]);

  const handleRowClick = (e, item) => {
    if (didDrag) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    onTapRef.current?.(item);
  };

  const draggedItem = localItems.find(i => i[keyField] === draggingId);

  return (
    <>
      {localItems.map((item) => {
        const isDragging = item[keyField] === draggingId;
        const disabled = isItemDisabled?.(item);

        if (isDragging) {
          return (
            <div
              key={item[keyField]}
              ref={el => { rowRefs.current[item[keyField]] = el; }}
              style={{ height: dragInfoRef.current.height }}
              className="rounded-xl border-2 border-dashed border-primary/30 bg-primary/5"
            />
          );
        }

        return (
          <div
            key={item[keyField]}
            ref={el => { rowRefs.current[item[keyField]] = el; }}
            onPointerDown={canReorder && !disabled ? (e) => handlePointerDown(e, item) : undefined}
            onClick={!disabled ? (e) => handleRowClick(e, item) : undefined}
            style={{
              touchAction: canReorder && !disabled ? 'pan-y' : 'auto',
              transition: 'transform 200ms ease',
            }}
          >
            {renderItem(item, false)}
          </div>
        );
      })}
      {draggingId && draggedItem && (
        <div
          style={{
            position: 'fixed',
            top: pointerY - dragInfoRef.current.height / 2,
            left: dragInfoRef.current.left,
            width: dragInfoRef.current.width,
            zIndex: 50,
            pointerEvents: 'none',
            transform: 'scale(1.03)',
            boxShadow: '0 12px 32px rgba(0,0,0,0.2)',
            opacity: 0.95,
          }}
        >
          {renderItem(draggedItem, true)}
        </div>
      )}
    </>
  );
}