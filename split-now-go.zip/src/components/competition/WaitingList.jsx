import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { formatElapsed, formatGap, formatLead } from '@/lib/timeUtils';
import SeriesBadge from '@/components/competition/SeriesBadge';

export default function WaitingList({ unrecorded, nextExpectedId, flashResults, competition, onNow, onCompetitorTap }) {
  const { t } = useTranslation();

  return (
    <div>
      <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 px-1">
        {t('splitTime.waiting')} ({unrecorded.length})
      </h2>
      <div className="space-y-2">
        <AnimatePresence>
        {unrecorded.map(c => {
          const isNext = c.id === nextExpectedId;
          const flash = flashResults[c.id];

          return (
            <motion.div
              key={c.id}
              layout
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -120, scale: 0.9, transition: { duration: 0.3 } }}
              className={`relative rounded-2xl border-2 px-4 py-3 transition-all ${
                flash ? (flash.isNewLeader ? 'border-green-500/30 bg-green-500/5' : 'border-red-500/30 bg-red-500/5') :
                isNext ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10' :
                'border-border bg-card'
              }`}
            >
              {flash && (
                <div className={`absolute inset-0 rounded-2xl border-2 pointer-events-none animate-pulse ${
                  flash.isNewLeader ? 'border-green-500' : 'border-red-500'
                }`} />
              )}
              {flash ? (
                <div className="flex items-center gap-2">
                  <span className={`w-8 font-black text-2xl tabular-nums text-center leading-none ${flash.isNewLeader ? 'text-green-600' : 'text-red-500'}`}>
                    {flash.rank}
                  </span>
                  <span className="w-7 font-semibold tabular-nums text-sm text-muted-foreground/40 ml-1">{c.bib_number}</span>
                  <button
                    onClick={() => onCompetitorTap(c)}
                    className="flex-1 min-w-0 text-left"
                  >
                    <p className="text-sm font-semibold truncate">{c.name || <span className="text-muted-foreground/40 italic">—</span>}</p>
                    <p className="text-xs text-muted-foreground tabular-nums">{formatElapsed(flash.elapsed)}</p>
                  </button>
                  <SeriesBadge competitor={c} competition={competition} />
                  <span className={`min-w-[4.5rem] text-right font-black text-base tabular-nums ${flash.isNewLeader ? 'text-green-600' : 'text-red-500'}`}>
                    {flash.isNewLeader
                      ? (flash.prevLeaderTime !== null ? formatLead(flash.prevLeaderTime - flash.elapsed) : t('splitTime.newLeader'))
                      : formatGap(flash.gap)
                    }
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => onCompetitorTap(c)}
                    className="flex items-center gap-3 flex-1 min-w-0 text-left"
                  >
                    <span className={`w-8 font-bold tabular-nums text-xl leading-none ${isNext ? 'text-primary font-black' : 'text-muted-foreground/50'}`}>
                      {c.bib_number}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{c.name || <span className="text-muted-foreground/40 italic">—</span>}</p>
                      <p className="text-xs text-muted-foreground tabular-nums">{c.start_time}</p>
                    </div>
                  </button>
                  <SeriesBadge competitor={c} competition={competition} />
                  <button
                    onClick={(e) => { e.stopPropagation(); onNow(c); }}
                    className={`min-w-[4.5rem] h-12 rounded-xl font-extrabold text-base transition-all active:scale-95 select-none ${
                      isNext
                        ? 'bg-primary text-primary-foreground shadow-md shadow-primary/30 animate-pulse'
                        : 'bg-muted text-foreground hover:bg-primary/10'
                    }`}
                  >
                    {t('splitTime.now')}
                  </button>
                </div>
              )}
            </motion.div>
          );
        })}
        </AnimatePresence>
      </div>
    </div>
  );
}