import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { X, Users, Lock, Shield } from 'lucide-react';
import PermissionInfoSheet from '@/components/competition/PermissionInfoSheet';
import { ROLE_STYLES } from '@/lib/roleStyles';
import { useUserRole } from '@/lib/permissions';
import { useToast } from '@/components/ui/use-toast';

export default function MembersSheet({ competitionId, onClose }) {
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { permissions } = useUserRole(competitionId);
  // Only the owner manages members; timers and editors see a read-only list.
  const canManage = permissions.canManageMembers;
  const [showPermInfo, setShowPermInfo] = useState(false);

  const roles = [
    { value: 'viewer', label: t('members.roleViewer'), desc: t('members.roleViewerDesc') },
    { value: 'timer', label: t('members.roleTimer'), desc: t('members.roleTimerDesc') },
    { value: 'editor', label: t('members.roleEditor'), desc: t('members.roleEditorDesc') },
    { value: 'owner', label: t('members.roleOwner'), desc: t('members.roleOwnerDesc') },
  ];

  const { data: members = [], isLoading } = useQuery({
    queryKey: ['members', competitionId],
    queryFn: () => base44.entities.CompetitionMember.filter({ competition_id: competitionId }),
  });

  const memberUserIds = members.map(m => m.user_id).filter(Boolean);
  const { data: usersData = [] } = useQuery({
    queryKey: ['public-profiles', memberUserIds],
    queryFn: async () => {
      const profiles = await base44.entities.PublicProfile.filter({ user_id: { $in: memberUserIds } });
      return profiles;
    },
    enabled: memberUserIds.length > 0,
  });
  const userAvatarMap = new Map(usersData.map(u => [u.user_id, u.avatar_url]));
  const userPublicMap = new Map(usersData.map(u => [u.user_id, u.is_profile_public]));

  const { data: competition } = useQuery({
    queryKey: ['competition', competitionId],
    queryFn: () => base44.entities.Competition.filter({ id: competitionId }),
    select: data => data[0]
  });

  const { data: currentUser, isLoading: userLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me()
  });

  // Role changes and removals go through the backend, which re-checks that the
  // caller really owns this competition.
  const runMemberAction = async (action, payload, messages) => {
    if (!canManage) {
      toast({ variant: 'destructive', title: t('members.noPermission') });
      return false;
    }
    try {
      const res = await base44.functions.invoke('manageCompetitionMember', { action, ...payload });
      if (res?.data?.error) throw new Error(res.data.error);
      queryClient.invalidateQueries({ queryKey: ['members', competitionId] });
      queryClient.invalidateQueries({ queryKey: ['my-membership'] });
      return true;
    } catch (err) {
      const forbidden = /forbidden|locked/i.test(err?.response?.data?.error || err?.message || '');
      toast({
        variant: 'destructive',
        title: forbidden ? t('members.noPermission') : t('members.actionFailed'),
      });
      return false;
    }
  };

  const updateRole = (memberId, role) => runMemberAction('setRole', { memberId, role });

  const removeMember = (memberId) => runMemberAction('remove', { memberId });

  const handleMemberClick = (member) => {
    navigate(`/profile/${member.user_id}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        className="relative bg-card rounded-t-3xl shadow-2xl max-h-[85vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 pt-5 pb-4 flex-shrink-0">
          <div>
            <h2 className="font-black text-xl text-foreground">{t('members.title')}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{t('members.memberCount', { count: members.length })}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPermInfo(true)}
              className="flex flex-col items-start bg-muted px-3 py-1.5 rounded-xl active:scale-95 transition-all"
            >
              <span className="font-bold text-xs flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-primary" />
                {t('edit.permissions')}
              </span>
              <span className="text-[10px] text-muted-foreground leading-tight">{t('edit.explanations')}</span>
            </button>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full bg-muted">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto flex-1 px-5 pb-8">
          {(isLoading || userLoading || !currentUser) ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <div key={i} className="h-16 rounded-xl bg-muted animate-pulse" />)}
            </div>
          ) : members.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground font-medium">{t('members.noMembers')}</p>
              <p className="text-xs text-muted-foreground/70 mt-1">{t('members.noMembersHint')}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {members.map(member => (
                <MemberRow
                  key={member.id}
                  member={member}
                  roles={roles}
                  currentUserId={currentUser?.id}
                  originalOwnerId={competition?.created_by_id}
                  avatarUrl={userAvatarMap.get(member.user_id)}
                  isProfilePublic={userPublicMap.get(member.user_id) !== false}
                  canManage={canManage}
                  onRoleChange={role => updateRole(member.id, role)}
                  onRemove={() => removeMember(member.id)}
                  onMemberClick={handleMemberClick}
                  t={t}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {showPermInfo && <PermissionInfoSheet onClose={() => setShowPermInfo(false)} />}
    </div>
  );
}

function MemberRow({ member, roles, currentUserId, originalOwnerId, avatarUrl, isProfilePublic, canManage, onRoleChange, onRemove, onMemberClick, t }) {
  const isSelf = member.user_id === currentUserId;
  const isOwner = member.role === 'owner';
  const roleLocked = member.user_id === originalOwnerId;
  const [pendingRole, setPendingRole] = useState(null);
  const [confirmRemove, setConfirmRemove] = useState(false);
  const roleStyle = ROLE_STYLES[member.role] || ROLE_STYLES.viewer;
  const roleLabel = roles.find(r => r.value === member.role)?.label || member.role;

  return (
    <div className="bg-muted rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <button
          onClick={() => onMemberClick(member)}
          className="flex items-center gap-3 flex-1 min-w-0 text-left active:opacity-70 transition-opacity"
        >
          <div className="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0 overflow-hidden">
            {avatarUrl ? (
              <img src={avatarUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              <span className="text-primary font-black text-sm">
                {(member.user_name || '?')[0].toUpperCase()}
              </span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p className="font-bold text-sm text-foreground truncate">{member.user_name || '—'}</p>
              {!isProfilePublic && (
                <Lock className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
              )}
            </div>
          </div>
        </button>
        {canManage && !roleLocked && !confirmRemove && (
          <button
            onClick={() => setConfirmRemove(true)}
            className="text-xs text-destructive font-semibold flex-shrink-0"
          >
            {t('members.remove')}
          </button>
        )}
      </div>

      {!canManage ? (
        <div className={`mt-3 flex items-center gap-2 px-4 py-2.5 rounded-xl border ${roleStyle.bg} ${roleStyle.border} ${roleStyle.accent}`}>
          {isOwner && <Lock className="w-3.5 h-3.5 flex-shrink-0" />}
          <span className="text-sm font-bold">{roleLabel}</span>
        </div>
      ) : roleLocked ? (
        <div className={`mt-3 flex items-center gap-2 px-4 py-2.5 rounded-xl border ${ROLE_STYLES.owner.bg} ${ROLE_STYLES.owner.border} ${ROLE_STYLES.owner.accent}`}>
          <Lock className="w-3.5 h-3.5" />
          <span className="text-sm font-bold">{t('members.roleOwner')}</span>
          <span className="text-xs opacity-70">— {t('members.roleLocked')}</span>
        </div>
      ) : confirmRemove ? (
        <div className="mt-3 rounded-xl bg-destructive/10 p-3 space-y-2.5">
          <p className="text-sm font-bold text-destructive text-center">{t('members.removeConfirm')}</p>
          <p className="text-xs text-muted-foreground text-center">{t('members.removeConfirmDesc')}</p>
          <div className="flex gap-2">
            <button onClick={() => setConfirmRemove(false)} className="flex-1 h-10 rounded-lg bg-muted font-bold text-sm">{t('common.cancel')}</button>
            <button
              onClick={async () => {
                const ok = await onRemove();
                if (ok) setConfirmRemove(false);
              }}
              className="flex-1 h-10 rounded-lg bg-destructive text-destructive-foreground font-bold text-sm"
            >
              {t('common.delete')}
            </button>
          </div>
        </div>
      ) : pendingRole ? (
        <div className="mt-3 rounded-xl bg-primary/10 p-3 space-y-2.5">
          <p className="text-sm font-bold text-primary text-center">{t('members.changeRoleConfirm')}</p>
          <p className="text-xs text-muted-foreground text-center">{t('members.changeRoleDesc')}</p>
          <div className="flex gap-2">
            <button onClick={() => setPendingRole(null)} className="flex-1 h-10 rounded-lg bg-muted font-bold text-sm">{t('common.cancel')}</button>
            <button
              onClick={async () => {
                const ok = await onRoleChange(pendingRole);
                if (ok) setPendingRole(null);
              }}
              className="flex-1 h-10 rounded-lg bg-primary text-primary-foreground font-bold text-sm"
            >
              {t('common.confirm')}
            </button>
          </div>
        </div>
      ) : (
        <div className="mt-3">
          <div className="grid grid-cols-2 gap-1.5">
            {roles.map(role => {
              const style = ROLE_STYLES[role.value];
              const isActive = member.role === role.value;
              return (
                <button
                  key={role.value}
                  onClick={() => role.value !== member.role && setPendingRole(role.value)}
                  className={`px-2 py-2 rounded-xl text-xs font-bold transition-all text-center border ${
                    isActive ? `${style.activeBg} border-transparent shadow-sm` : `${style.bg} ${style.accent} ${style.border}`
                  }`}
                >
                  {role.label}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}