import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { X, Copy, Share2, Check, Link2 } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

export default function ShareSheet({ competition, onClose }) {
  const { t } = useTranslation();
  const [copied, setCopied] = useState(false);
  const joinCode = competition?.join_code || '';
  const joinUrl = `${window.location.origin}/?join=${joinCode}`;


  const handleCopy = async () => {
    await navigator.clipboard.writeText(joinUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: competition?.name,
        text: t('share.shareText', { name: competition?.name, code: joinCode }),
        url: joinUrl,
      });
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        className="relative bg-card rounded-t-3xl shadow-2xl pb-safe"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 pt-5 pb-4">
          <h2 className="font-black text-xl text-foreground">{t('share.title')}</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full bg-muted">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="px-5 pb-8 space-y-5">
          <div className="bg-muted rounded-2xl p-5 text-center">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">{t('share.joinCode')}</p>
            <div className="text-5xl font-black tracking-widest text-foreground font-mono">{joinCode}</div>
            <p className="text-xs text-muted-foreground mt-2">{t('share.shareCode')}</p>
          </div>

          <div className="flex justify-center">
            <div className="bg-white p-3 rounded-2xl shadow-md">
              <QRCodeSVG value={joinUrl} size={180} />
            </div>
          </div>

          <div className="flex items-center gap-2 bg-muted rounded-xl px-4 py-3">
            <Link2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <span className="text-xs text-muted-foreground flex-1 truncate">{joinUrl}</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={handleCopy}
              className="flex items-center justify-center gap-2 py-3.5 rounded-xl bg-muted font-bold text-foreground text-sm active:scale-95 transition-transform"
            >
              {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
              {copied ? t('share.copied') : t('share.copyLink')}
            </button>
            <button
              onClick={handleShare}
              className="flex items-center justify-center gap-2 py-3.5 rounded-xl bg-primary text-primary-foreground font-bold text-sm shadow-lg shadow-primary/30 active:scale-95 transition-transform"
            >
              <Share2 className="w-4 h-4" />
              {t('share.share')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}