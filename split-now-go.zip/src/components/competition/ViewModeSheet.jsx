import React from 'react';
import { useTranslation } from 'react-i18next';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { List, Zap, Check } from 'lucide-react';

export default function ViewModeSheet({ open, onOpenChange, currentMode, onSelect }) {
  const { t } = useTranslation();

  const options = [
    { mode: 'normal', icon: List, label: t('quickTouch.normalView'), desc: t('quickTouch.normalViewDesc') },
    { mode: 'quicktouch', icon: Zap, label: t('quickTouch.quickTouchView'), desc: t('quickTouch.quickTouchViewDesc') },
  ];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="rounded-t-3xl pb-8">
        <SheetHeader className="text-left">
          <div className="w-10 h-1 bg-muted rounded-full mx-auto absolute left-1/2 -translate-x-1/2 top-3" />
          <SheetTitle>{t('quickTouch.viewModeTitle')}</SheetTitle>
        </SheetHeader>
        <div className="space-y-3 mt-4">
          {options.map(({ mode, icon: Icon, label, desc }) => {
            const isSelected = currentMode === mode;
            return (
              <button
                key={mode}
                onClick={() => { onSelect(mode); onOpenChange(false); }}
                className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl border-2 transition-all active:scale-[0.98] ${
                  isSelected ? 'border-primary bg-primary/5' : 'border-border bg-card hover:bg-muted/50'
                }`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  isSelected ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                }`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1 text-left min-w-0">
                  <p className="font-bold text-base">{label}</p>
                  <p className="text-sm text-muted-foreground">{desc}</p>
                </div>
                {isSelected && (
                  <div className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center flex-shrink-0">
                    <Check className="w-4 h-4" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </SheetContent>
    </Sheet>
  );
}