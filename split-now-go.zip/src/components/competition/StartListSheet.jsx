import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useQueryClient } from '@tanstack/react-query';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from '@/components/ui/sheet';
import { Pencil, Clock, Trash2, Check, X, AlertTriangle } from 'lucide-react';
import TimeInput from '@/components/competition/TimeInput';
import { useToast } from '@/components/ui/use-toast';
import { capitalizeName } from '@/lib/nameUtils';
import SeriesBadge from '@/components/competition/SeriesBadge';
import { seriesLabel } from '@/lib/seriesUtils';
import { execOrQueue, updateCachedCompetitor, removeCachedCompetitor } from '@/lib/syncQueue';

export default function StartListSheet({
  competitor, competitionId, competition, competitors = [], open, onOpenChange, permissions = {},
  draft = false, onDraftChange, onDraftRemove,
}) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [name, setName] = useState('');
  const [originalName, setOriginalName] = useState('');
  const [startTime, setStartTime] = useState('00:00:00');
  const [editingName, setEditingName] = useState(false);
  const [editingTime, setEditingTime] = useState(false);
  const [editingBib, setEditingBib] = useState(false);
  const [bibValue, setBibValue] = useState('');
  const [bibError, setBibError] = useState('');
  const [bibWarning, setBibWarning] = useState('');
  const [gender, setGender] = useState(null);
  const [age, setAge] = useState('');
  const [seriesText, setSeriesText] = useState('');
  const [showDelete, setShowDelete] = useState(false);
  const [localStatus, setLocalStatus] = useState(competitor?.status || 'active');

  useEffect(() => {
    if (competitor) {
      setName(competitor.name || '');
      setStartTime(competitor.start_time || '00:00:00');
      setEditingName(false);
      setEditingTime(false);
      setEditingBib(false);
      setBibError('');
      setBibWarning('');
      setGender(competitor.gender || null);
      setAge(competitor.age != null ? String(competitor.age) : '');
      setSeriesText(competitor.series || '');
      setShowDelete(false);
      setLocalStatus(competitor.status || 'active');
    }
  }, [competitor]);

  if (!competitor) return null;

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['competitors', competitionId] });
  const canEdit = draft || permissions.canEditCompetitors;

  // Draft mode: the competitor is not stored yet (recognised start list being
  // reviewed), so every change goes back to that list instead of the database.
  const persist = async (patch) => {
    if (draft) {
      onDraftChange(patch);
      return;
    }
    updateCachedCompetitor(competitionId, competitor.id, patch);
    await execOrQueue('Competitor', 'update', competitor.id, patch);
    invalidate();
  };

  const startEditName = () => {
    setOriginalName(name || competitor.name || '');
    setEditingName(true);
  };

  const cancelEditName = () => {
    setName(originalName);
    setEditingName(false);
  };

  const saveName = async () => {
    try {
      await persist({ name });
      setEditingName(false);
    } catch (err) {
      toast({ title: t('startList.nameSaveError'), variant: 'destructive' });
    }
  };

  const saveTime = async () => {
    await persist({ start_time: startTime });
    setEditingTime(false);
  };

  const saveBib = async () => {
    const bib = Number(bibValue);
    if (!bib || bib < 1) {
      setBibError(t('startList.bibInvalid'));
      return;
    }
    setBibError('');
    const isDuplicate = competitors.some(c => c.id !== competitor.id && c.bib_number === bib);
    if (isDuplicate) {
      setBibWarning(t('startList.duplicateBibWarning', { bib }));
    } else {
      setBibWarning('');
    }
    // A recognised row may have come in without a readable bib number: giving
    // it one here completes the row in the review list instead of dropping it.
    if (draft) {
      onDraftChange({ bib_number: bib });
      setEditingBib(false);
      return;
    }
    queryClient.setQueryData(['competitors', competitionId], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, bib_number: bib } : c)
    );
    updateCachedCompetitor(competitionId, competitor.id, { bib_number: bib });
    await execOrQueue('Competitor', 'update', competitor.id, { bib_number: bib });
    invalidate();
    setEditingBib(false);
  };

  const setStatus = async (status) => {
    setLocalStatus(status);
    queryClient.setQueryData(['competitors', competitionId], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, status } : c)
    );
    updateCachedCompetitor(competitionId, competitor.id, { status });
    await execOrQueue('Competitor', 'update', competitor.id, { status });
    invalidate();
  };

  // A corrected gender or age renames the series, so the stored series text
  // never contradicts the classification the user chose. The whole series is
  // built from gender AND age, whatever classification settings happen to be
  // switched on — turning the age classification off must never shorten "N16"
  // into "N". The stored series is only replaced when the new label really
  // carries information: nothing is ever overwritten with an empty value.
  const seriesFor = (patch) => seriesLabel(
    { gender, age: age === '' ? null : Number(age), ...patch },
    t
  ) || null;

  const saveGender = async (value) => {
    setGender(value);
    const series = seriesFor({ gender: value });
    if (series) setSeriesText(series);
    if (!draft) {
      queryClient.setQueryData(['competitors', competitionId], (old) =>
        old?.map(c => c.id === competitor.id ? { ...c, gender: value, ...(series ? { series } : {}) } : c)
      );
    }
    await persist(series ? { gender: value, series } : { gender: value });
  };

  const saveAge = async (value) => {
    const numValue = value ? Math.max(0, Math.min(150, Number(value))) : null;
    setAge(numValue != null ? String(numValue) : '');
    const series = seriesFor({ age: numValue });
    if (series) setSeriesText(series);
    if (!draft) {
      queryClient.setQueryData(['competitors', competitionId], (old) =>
        old?.map(c => c.id === competitor.id ? { ...c, age: numValue, ...(series ? { series } : {}) } : c)
      );
    }
    await persist(series ? { age: numValue, series } : { age: numValue });
  };

  const handleDelete = async () => {
    if (draft) {
      onDraftRemove();
      return;
    }
    queryClient.setQueryData(['competitors', competitionId], (old) =>
      old?.filter(c => c.id !== competitor.id)
    );
    removeCachedCompetitor(competitionId, competitor.id);
    await execOrQueue('Competitor', 'delete', competitor.id);
    invalidate();
    onOpenChange(false);
  };

  const status = localStatus;
  // The badge follows the edits made in this sheet, not the stored record.
  const badgeCompetitor = { ...competitor, gender, age: age === '' ? null : Number(age), series: seriesText };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className={`rounded-t-3xl max-h-[85vh] overflow-y-auto pb-8 ${editingName ? '[&>button]:!top-1' : ''}`}>
        <SheetHeader className="text-left">
          <SheetTitle className="flex items-center gap-3">
            {editingBib ? (
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={bibValue}
                  onChange={e => { setBibValue(e.target.value); setBibError(''); }}
                  onKeyDown={e => { if (e.key === 'Enter') saveBib(); }}
                  className="w-16 h-10 px-2 rounded-lg bg-muted border border-border outline-none text-base font-bold text-center"
                  autoFocus
                />
                <button onClick={saveBib} className="w-10 h-10 rounded-lg bg-primary text-primary-foreground flex items-center justify-center active:scale-95 transition-transform">
                  <Check className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => { if (canEdit) { setBibValue(competitor.bib_number != null ? String(competitor.bib_number) : ''); setEditingBib(true); } }}
                className={`w-10 h-10 rounded-xl bg-primary/10 text-primary font-black flex items-center justify-center text-lg flex-shrink-0 ${canEdit ? 'active:scale-95 transition-transform' : 'cursor-default'}`}
              >
                {competitor.bib_number != null ? competitor.bib_number : '?'}
              </button>
            )}
            {editingName ? (
              <div className="flex items-center gap-1 flex-1 min-w-0">
                <input
                  value={name}
                  onChange={e => setName(capitalizeName(e.target.value))}
                  onKeyDown={e => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') cancelEditName(); }}
                  className="flex-1 h-10 px-3 rounded-lg bg-muted border border-border outline-none text-base min-w-0"
                  placeholder={t('startList.name')}
                  autoFocus
                />
                <button onClick={cancelEditName} className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center active:scale-95 transition-transform flex-shrink-0">
                  <X className="w-4 h-4" />
                </button>
                <button onClick={saveName} className="h-10 w-10 rounded-lg bg-primary text-primary-foreground flex items-center justify-center active:scale-95 transition-transform flex-shrink-0">
                  <Check className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => { if (canEdit) startEditName(); }}
                className={`truncate flex-1 min-w-0 text-left flex items-center gap-1.5 ${canEdit ? 'active:scale-[0.98] transition-transform' : 'cursor-default'}`}
              >
                <span className="truncate">{name || competitor.name || t('startList.addNamePlaceholder')}</span>
                {canEdit && <Pencil className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />}
              </button>
            )}
            {!editingName && <SeriesBadge competitor={badgeCompetitor} competition={competition} showUnset />}
          </SheetTitle>
          {bibError && (
            <p className="text-sm text-destructive font-semibold mt-1">{bibError}</p>
          )}
          {bibWarning && (
            <p className="text-sm text-amber-600 dark:text-amber-400 font-semibold mt-1 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
              {bibWarning}
            </p>
          )}
        </SheetHeader>

        <div className="space-y-2.5 mt-4">
          {/* Status badge */}
          {status !== 'active' && (
            <div className={`px-4 py-2 rounded-xl text-sm font-bold text-center ${
              status === 'DNS' ? 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-400' :
              status === 'DSQ' ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400' :
              'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400'
            }`}>
              {status === 'DNS' ? t('startList.statusDNS') : status === 'DSQ' ? t('startList.statusDSQ') : t('startList.statusDNF')}
            </div>
          )}

          {/* Gender selector */}
          {competition?.gender_categorization && (
          <div className="px-4 py-3 rounded-xl bg-muted">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{t('startList.gender')}</p>
            <div className="flex gap-2">
              {[
                { value: 'female', label: t('startList.genderFemale') },
                { value: 'male', label: t('startList.genderMale') },
              ].map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => canEdit && saveGender(opt.value)}
                  disabled={!canEdit}
                  className={`flex-1 h-10 rounded-lg font-bold text-xs transition-all ${
                    gender === opt.value
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'bg-card text-foreground border border-border'
                  } ${!canEdit ? 'opacity-60 cursor-default' : 'active:scale-95'}`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
          )}

          {/* Age input */}
          {competition?.age_categorization && (
          <div className="px-4 py-3 rounded-xl bg-muted">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{t('startList.age')}</p>
            <input
              type="number"
              min="0"
              max="150"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              onBlur={() => canEdit && saveAge(age)}
              disabled={!canEdit}
              className="w-full h-10 px-3 rounded-lg bg-card border border-border outline-none text-base disabled:opacity-60"
              placeholder="—"
            />
          </div>
          )}

          {canEdit && (
          <>
          {/* Edit start time */}
          {!editingTime ? (
            <button onClick={() => setEditingTime(true)} className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-muted text-left active:scale-[0.98] transition-transform">
              <Clock className="w-4 h-4 text-primary flex-shrink-0" />
              <span className="font-semibold text-sm">{t('startList.editStartTime')}</span>
              <span className="ml-auto font-mono text-sm text-muted-foreground tabular-nums">{startTime || competitor.start_time}</span>
            </button>
          ) : (
            <div className="px-3 py-3 rounded-xl bg-muted">
              <div className="flex items-center gap-2 mb-3">
                <Clock className="w-4 h-4 text-primary" />
                <span className="font-semibold text-sm">{t('startList.editStartTime')}</span>
              </div>
              <TimeInput value={startTime} onChange={setStartTime} />
              <div className="flex gap-2 mt-3">
                <button onClick={() => setEditingTime(false)} className="flex-1 h-10 rounded-lg bg-card font-bold text-sm">{t('common.cancel')}</button>
                <button onClick={saveTime} className="flex-1 h-10 rounded-lg bg-primary text-primary-foreground font-bold text-sm">{t('common.ok')}</button>
              </div>
            </div>
          )}
          </>
          )}

          {/* Status buttons row (hidden while reviewing a recognised start list) */}
          {!draft && (
          <>
          <div className="flex gap-2">
            <button
              onClick={() => setStatus('DNS')}
              className={`flex-1 h-11 rounded-xl font-bold text-sm active:scale-95 transition-transform ${
                status === 'DNS'
                  ? 'bg-slate-200 text-slate-700 dark:bg-slate-500/25 dark:text-slate-300 ring-2 ring-slate-400/50'
                  : 'bg-slate-100 text-slate-600 dark:bg-slate-500/10 dark:text-slate-400'
              }`}
            >
              DNS
            </button>
            <button
              onClick={() => setStatus('DNF')}
              className={`flex-1 h-11 rounded-xl font-bold text-sm active:scale-95 transition-transform ${
                status === 'DNF'
                  ? 'bg-red-100 text-red-700 dark:bg-red-500/25 dark:text-red-300 ring-2 ring-red-400/50'
                  : 'bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-400'
              }`}
            >
              DNF
            </button>
            <button
              onClick={() => setStatus('DSQ')}
              className={`flex-1 h-11 rounded-xl font-bold text-sm active:scale-95 transition-transform ${
                status === 'DSQ'
                  ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/25 dark:text-blue-300 ring-2 ring-blue-400/50'
                  : 'bg-blue-50 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400'
              }`}
            >
              DSQ
            </button>
          </div>

          {/* Clear status */}
          {status !== 'active' && (
            <button onClick={() => setStatus('active')} className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-muted text-foreground active:scale-[0.98] transition-transform">
              <Check className="w-4 h-4 flex-shrink-0" />
              <span className="font-semibold text-sm">{t('startList.clearStatus')}</span>
            </button>
          )}
          </>
          )}

          {/* Delete */}
          {canEdit && (
          <>
          {!showDelete ? (
            <button onClick={() => setShowDelete(true)} className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-destructive/10 text-destructive text-left active:scale-[0.98] transition-transform">
              <Trash2 className="w-4 h-4 flex-shrink-0" />
              <span className="font-semibold text-sm">{t('startList.deleteCompetitor')}</span>
            </button>
          ) : (
            <div className="rounded-xl bg-destructive/10 p-3 space-y-2.5">
              <p className="text-sm font-bold text-destructive text-center">{t('startList.deleteConfirm')}</p>
              <p className="text-xs text-muted-foreground text-center">{t('startList.deleteConfirmDesc')}</p>
              <div className="flex gap-2">
                <button onClick={() => setShowDelete(false)} className="flex-1 h-10 rounded-lg bg-muted font-bold text-sm">{t('common.cancel')}</button>
                <button onClick={handleDelete} className="flex-1 h-10 rounded-lg bg-destructive text-destructive-foreground font-bold text-sm">{t('common.delete')}</button>
              </div>
            </div>
          )}
          </>
          )}

          {draft && (
            <button
              onClick={() => onOpenChange(false)}
              className="w-full h-12 rounded-xl bg-primary text-primary-foreground font-bold text-sm active:scale-95 transition-transform"
            >
              {t('create.reviewDone')}
            </button>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}