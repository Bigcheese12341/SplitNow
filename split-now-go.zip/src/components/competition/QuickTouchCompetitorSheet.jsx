import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { RotateCcw, Trash2, Clock, Check, Pencil, X } from 'lucide-react';
import { formatElapsed } from '@/lib/timeUtils';
import TimeInput from '@/components/competition/TimeInput';
import { useToast } from '@/components/ui/use-toast';
import { capitalizeName } from '@/lib/nameUtils';
import { getTotalPoints, getSplitLabel, getCompetitorProgress } from '@/lib/quickTouchPrefs';
import SeriesBadge from '@/components/competition/SeriesBadge';

export default function QuickTouchCompetitorSheet({ competitor, competition, open, onOpenChange, onUndoSplit, onManualTime, onSetStatus, onDelete, onSaveName, permissions = {} }) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [manualTime, setManualTime] = useState('00:00:00');
  const [editingSplit, setEditingSplit] = useState(null);
  const [showDelete, setShowDelete] = useState(false);
  const [localStatus, setLocalStatus] = useState('active');
  const [editingName, setEditingName] = useState(false);
  const [name, setName] = useState('');
  const [originalName, setOriginalName] = useState('');

  useEffect(() => {
    if (competitor) {
      setManualTime('00:00:00');
      setEditingSplit(null);
      setShowDelete(false);
      setLocalStatus(competitor.status || 'active');
      setEditingName(false);
      setName(competitor.name || '');
    }
  }, [competitor]);

  if (!competitor) return null;

  const totalPoints = getTotalPoints(competition);
  const canEdit = permissions.canEditCompetitors;
  // Correcting an already stored split time belongs to everyone who may time
  // this competition (timer, editor, owner); typing a time into an empty timing
  // point stays with the competitor editors.
  const canEditTime = !!permissions.canEditSplitTimes;
  const status = localStatus;

  const startEditName = () => { setOriginalName(competitor.name || ''); setName(competitor.name || ''); setEditingName(true); };
  const cancelEditName = () => { setName(originalName); setEditingName(false); };
  const saveName = async () => {
    try { await onSaveName(competitor, name); setEditingName(false); }
    catch { toast({ title: t('startList.nameSaveError'), variant: 'destructive' }); }
  };

  const handleUndoSplit = async (splitIndex) => {
    try { await onUndoSplit(competitor, splitIndex); }
    catch { toast({ title: t('quickTouch.splitSaveError'), variant: 'destructive' }); }
  };

  const handleManualSubmit = async (splitIndex) => {
    const parts = manualTime.split(':').map(Number);
    const elapsed = parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (elapsed <= 0) return;
    try {
      await onManualTime(competitor, splitIndex, elapsed);
      setEditingSplit(null);
    } catch {
      toast({ title: t('quickTouch.splitSaveError'), variant: 'destructive' });
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className={`rounded-t-3xl max-h-[85vh] overflow-y-auto pb-8 ${editingName ? '[&>button]:!top-1' : ''}`}>
        <SheetHeader className="text-left">
          <SheetTitle className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-primary/10 text-primary font-black flex items-center justify-center text-lg flex-shrink-0">
              {competitor.bib_number}
            </span>
            {editingName ? (
              <div className="flex items-center gap-1 flex-1 min-w-0">
                <input value={name} onChange={e => setName(capitalizeName(e.target.value))}
                  onKeyDown={e => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') cancelEditName(); }}
                  className="flex-1 h-10 px-3 rounded-lg bg-muted border border-border outline-none text-base min-w-0"
                  placeholder={t('startList.name')} autoFocus />
                <button onClick={cancelEditName} className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center active:scale-95 transition-transform flex-shrink-0">
                  <X className="w-4 h-4" />
                </button>
                <button onClick={saveName} className="h-10 w-10 rounded-lg bg-primary text-primary-foreground flex items-center justify-center active:scale-95 transition-transform flex-shrink-0">
                  <Check className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button onClick={() => { if (canEdit) startEditName(); }}
                className={`truncate flex-1 min-w-0 text-left flex items-center gap-1.5 ${canEdit ? 'active:scale-[0.98] transition-transform' : 'cursor-default'}`}>
                <span className="truncate">{competitor.name || t('startList.addNamePlaceholder')}</span>
                {canEdit && <Pencil className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />}
              </button>
            )}
            <SeriesBadge competitor={competitor} competition={competition} showUnset />
          </SheetTitle>
        </SheetHeader>

        {status !== 'active' && (
          <div className={`mt-3 px-4 py-2 rounded-xl text-sm font-bold text-center ${
            status === 'DNS' ? 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-400' :
            status === 'DSQ' ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400' :
            'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400'
          }`}>
            {status === 'DNS' ? t('splitTime.statusDNS') : status === 'DSQ' ? t('splitTime.statusDSQ') : t('splitTime.statusDNF')}
          </div>
        )}

        {/* All split times */}
        <div className="mt-4 space-y-2">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest px-1">
            {t('quickTouch.splitPoints')} ({getCompetitorProgress(competitor)}/{totalPoints})
          </p>
          {Array.from({ length: totalPoints }, (_, i) => {
            const split = (competitor.split_times || []).find(s => s.split_index === i);
            const hasTime = split && split.elapsed !== null && split.elapsed !== undefined && split.status !== 'DNF';
            const isEditing = editingSplit === i;
            return (
              <div key={i} className={`rounded-xl ${isEditing ? 'bg-muted p-3' : 'bg-muted/50'}`}>
                {isEditing ? (
                  <>
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="w-4 h-4 text-primary" />
                      <span className="font-semibold text-sm">{getSplitLabel(i, competition, t)}</span>
                      <span className="ml-auto text-[10px] font-bold uppercase tracking-wide text-muted-foreground text-right">
                        {hasTime ? t('quickTouch.editSplitTitle') : t('quickTouch.newSplitTime')}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2 px-0.5">
                      #{competitor.bib_number}{competitor.name ? ` · ${competitor.name}` : ''}
                      {hasTime && (
                        <>
                          {' · '}
                          {t('quickTouch.currentTime')}{' '}
                          <span className="font-mono font-bold tabular-nums text-foreground">{formatElapsed(split.elapsed)}</span>
                        </>
                      )}
                    </p>
                    <TimeInput value={manualTime} onChange={setManualTime} />
                    <div className="flex gap-2 mt-2">
                      <button onClick={() => setEditingSplit(null)} className="flex-1 h-9 rounded-lg bg-card font-bold text-sm">{t('common.cancel')}</button>
                      <button onClick={() => handleManualSubmit(i)} className="flex-1 h-9 rounded-lg bg-primary text-primary-foreground font-bold text-sm">
                        {hasTime ? t('common.save') : t('common.ok')}
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center gap-3 px-3 py-2.5">
                    <span className="text-sm font-semibold flex-1">{getSplitLabel(i, competition, t)}</span>
                    <span className={`font-mono font-bold text-sm tabular-nums ${hasTime ? 'text-foreground' : 'text-muted-foreground/40'}`}>
                      {hasTime ? formatElapsed(split.elapsed) : '—'}
                    </span>
                    {canEditTime && hasTime && (
                      <button onClick={() => handleUndoSplit(i)}
                        title={t('splitTime.undoTime')}
                        aria-label={t('splitTime.undoTime')}
                        className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400 flex items-center justify-center active:scale-95 transition-transform">
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {(canEdit || (canEditTime && hasTime)) && (
                      <button onClick={() => { setManualTime(hasTime ? formatElapsed(split.elapsed) : '00:00:00'); setEditingSplit(i); }}
                        title={hasTime ? t('quickTouch.editSplitTitle') : t('quickTouch.newSplitTime')}
                        aria-label={hasTime ? t('quickTouch.editSplitTitle') : t('quickTouch.newSplitTime')}
                        className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center active:scale-95 transition-transform">
                        <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="space-y-2.5 mt-4">
          <div className="flex gap-2">
            <button onClick={() => { setLocalStatus('DNS'); onSetStatus(competitor, 'DNS'); }}
              className={`flex-1 h-11 rounded-xl font-bold text-sm active:scale-95 transition-transform ${
                status === 'DNS' ? 'bg-slate-200 text-slate-700 dark:bg-slate-500/25 dark:text-slate-300 ring-2 ring-slate-400/50'
                : 'bg-slate-100 text-slate-600 dark:bg-slate-500/10 dark:text-slate-400'}`}>DNS</button>
            <button onClick={() => { setLocalStatus('DNF'); onSetStatus(competitor, 'DNF'); }}
              className={`flex-1 h-11 rounded-xl font-bold text-sm active:scale-95 transition-transform ${
                status === 'DNF' ? 'bg-red-100 text-red-700 dark:bg-red-500/25 dark:text-red-300 ring-2 ring-red-400/50'
                : 'bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-400'}`}>DNF</button>
            <button onClick={() => { setLocalStatus('DSQ'); onSetStatus(competitor, 'DSQ'); }}
              className={`flex-1 h-11 rounded-xl font-bold text-sm active:scale-95 transition-transform ${
                status === 'DSQ' ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/25 dark:text-blue-300 ring-2 ring-blue-400/50'
                : 'bg-blue-50 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400'}`}>DSQ</button>
          </div>

          {status !== 'active' && (
            <button onClick={() => { setLocalStatus('active'); onSetStatus(competitor, 'active'); }}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-muted text-foreground active:scale-[0.98] transition-transform">
              <Check className="w-4 h-4 flex-shrink-0" />
              <span className="font-semibold text-sm">{t('splitTime.clearStatus')}</span>
            </button>
          )}

          {canEdit && (
            <>
              {!showDelete ? (
                <button onClick={() => setShowDelete(true)}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-destructive/10 text-destructive text-left active:scale-[0.98] transition-transform">
                  <Trash2 className="w-4 h-4 flex-shrink-0" />
                  <span className="font-semibold text-sm">{t('splitTime.deleteCompetitor')}</span>
                </button>
              ) : (
                <div className="rounded-xl bg-destructive/10 p-3 space-y-2.5">
                  <p className="text-sm font-bold text-destructive text-center">{t('splitTime.deleteConfirm')}</p>
                  <p className="text-xs text-muted-foreground text-center">{t('splitTime.deleteConfirmDesc')}</p>
                  <div className="flex gap-2">
                    <button onClick={() => setShowDelete(false)} className="flex-1 h-10 rounded-lg bg-muted font-bold text-sm">{t('common.cancel')}</button>
                    <button onClick={() => { onDelete(competitor); onOpenChange(false); }} className="flex-1 h-10 rounded-lg bg-destructive text-destructive-foreground font-bold text-sm">{t('common.delete')}</button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}