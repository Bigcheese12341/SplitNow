import React from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { formatGap, formatLead } from '@/lib/timeUtils';

// Panel header: a drag handle with the panel title, the recording feedback (only
// while the panel is closed) and the arrow that opens or closes the panel.
export default function LiveResultsPanelHeader({ closed, feedback, onFeedbackTap, onToggle }) {
  const { t } = useTranslation();
  const isLeader = feedback?.rank === 1;
  const showFeedback = closed && !!feedback;

  return (
    <div>
      <div className="relative flex items-center justify-center pt-2 pb-1.5">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-foreground">
          {t('quickTouch.liveResults')}
        </span>
        <div className="w-10 h-1.5 rounded-full bg-border" />
      </div>
      <div className="flex items-center gap-2 px-3 pb-2">
        {showFeedback ? (
          <button
            onClick={onFeedbackTap}
            className={`flex-1 min-w-0 h-11 rounded-xl flex items-center gap-2 px-3 text-left active:scale-[0.99] transition-transform ${
              isLeader
                ? 'bg-green-500 border border-green-600 dark:bg-green-600 dark:border-green-700'
                : 'bg-red-500 border border-red-600 dark:bg-red-600 dark:border-red-700'
            }`}
          >
            <span className="font-black text-lg tabular-nums leading-none flex-shrink-0 text-white">{feedback.rank || '—'}</span>
            <span className="text-sm font-semibold tabular-nums text-white/50 flex-shrink-0">{feedback.bibNumber}</span>
            <span className="text-sm font-medium truncate flex-1 min-w-0 text-white">{feedback.name || ''}</span>
            {feedback.seriesLabel && (
              <span className="text-[10px] leading-none font-bold px-1.5 py-1 rounded flex-shrink-0 bg-white/25 text-white">
                {feedback.seriesLabel}
              </span>
            )}
            <span className="text-sm font-black tabular-nums flex-shrink-0 text-white">
              {isLeader
                ? (feedback.leadSize > 0 ? formatLead(feedback.leadSize) : '—')
                : (feedback.gap === null || feedback.gap === undefined ? '—' : formatGap(feedback.gap))}
            </span>
          </button>
        ) : (
          <div className="flex-1 min-w-0 h-11" />
        )}
        <button
          onClick={onToggle}
          aria-label={t('quickTouch.liveResults')}
          className="w-11 h-11 rounded-xl bg-muted flex items-center justify-center active:scale-95 transition-transform flex-shrink-0"
        >
          {closed
            ? <ChevronUp className="w-6 h-6 text-foreground" />
            : <ChevronDown className="w-6 h-6 text-foreground" />}
        </button>
      </div>
    </div>
  );
}