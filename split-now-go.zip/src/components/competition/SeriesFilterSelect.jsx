import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectSeparator,
} from '@/components/ui/select';
import { SERIES_ALL } from '@/lib/seriesUtils';

// Series picker shared by the results view and the live results list.
export default function SeriesFilterSelect({ seriesOptions, value, onChange, triggerClassName = '' }) {
  if (!seriesOptions?.items?.length) return null;

  const active = [seriesOptions.all, ...seriesOptions.items]
    .find(option => option.value === value) || seriesOptions.all;

  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={triggerClassName}>
        <span className="truncate">{active.label}</span>
      </SelectTrigger>
      <SelectContent align="end">
        <SelectItem value={SERIES_ALL} className="py-2.5 font-semibold">
          {seriesOptions.all.label}
        </SelectItem>
        <SelectSeparator />
        {seriesOptions.items.map(option => (
          <SelectItem key={option.value} value={option.value} className="py-2.5 font-semibold">
            {option.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}