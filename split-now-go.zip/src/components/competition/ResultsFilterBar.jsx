import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
} from '@/components/ui/select';
import SeriesFilterSelect from '@/components/competition/SeriesFilterSelect';

const triggerClass = 'h-11 rounded-xl border-border bg-card px-3 text-sm font-bold shadow-sm';

export default function ResultsFilterBar({
  timingPoints,
  selectedSplit,
  onSplitChange,
  seriesOptions,
  seriesValue,
  onSeriesChange,
  alwaysShowSplits = false,
}) {
  const activePoint = timingPoints.find(point => point.index === selectedSplit);

  return (
    <div className="flex items-center gap-2">
      {(alwaysShowSplits || timingPoints.length > 1) && (
        <Select value={String(selectedSplit)} onValueChange={value => onSplitChange(Number(value))}>
          <SelectTrigger className={`${triggerClass} flex-1 min-w-0`}>
            <span className="truncate">{activePoint?.label || ''}</span>
          </SelectTrigger>
          <SelectContent align="start">
            {timingPoints.map(point => (
              <SelectItem key={point.index} value={String(point.index)} className="py-2.5 font-semibold">
                {point.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      <SeriesFilterSelect
        seriesOptions={seriesOptions}
        value={seriesValue}
        onChange={onSeriesChange}
        triggerClassName={`${triggerClass} w-auto max-w-[45%] ml-auto flex-shrink-0`}
      />
    </div>
  );
}