import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { CheckCircle2, RefreshCw, WifiOff, Clock, AlertCircle, RotateCcw } from 'lucide-react';
import { subscribeDetails, getSyncDetails, retrySync } from '@/lib/syncQueue';

export default function SyncStatusIcon() {
  const { t } = useTranslation();
  const [details, setDetails] = useState(getSyncDetails());
  const [showPanel, setShowPanel] = useState(false);

  useEffect(() => {
    return subscribeDetails(setDetails);
  }, []);

  const status = details.status;

  const getIcon = (size = 'w-5 h-5') => {
    if (status === 'offline') return <WifiOff className={`${size} text-amber-500`} />;
    if (status === 'syncing') return <RefreshCw className={`${size} text-primary animate-spin`} />;
    return <CheckCircle2 className={`${size} text-green-500`} />;
  };

  const getLabel = () => {
    if (status === 'offline') return t('sync.offline');
    if (status === 'syncing') return t('sync.syncing');
    return t('sync.synced');
  };

  const getStatusColor = () => {
    if (status === 'offline') return 'text-amber-500';
    if (status === 'syncing') return 'text-primary';
    return 'text-green-500';
  };

  const formatLastSync = (ts) => {
    if (!ts) return t('sync.lastSyncNever');
    const diff = Date.now() - ts;
    if (diff < 60000) return t('sync.lastSyncJustNow');
    if (diff < 3600000) return t('sync.lastSyncMinutes', { count: Math.floor(diff / 60000) });
    return new Date(ts).toLocaleTimeString();
  };

  return (
    <div className="relative flex-shrink-0">
      <button
        onClick={() => setShowPanel(prev => !prev)}
        className="flex items-center justify-center w-9 h-9 rounded-full hover:bg-muted transition-colors"
        aria-label={getLabel()}
      >
        {getIcon()}
      </button>
      {showPanel && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setShowPanel(false)} />
          <div className="absolute top-full right-0 mt-1 z-50 bg-popover text-popover-foreground rounded-xl shadow-lg border border-border w-72 p-4 space-y-3">
            {/* Status header */}
            <div className="flex items-center gap-2.5 pb-2 border-b border-border">
              {getIcon('w-5 h-5')}
              <span className="font-bold text-sm">{getLabel()}</span>
            </div>

            {/* Details */}
            <div className="space-y-2.5 text-sm">
              {/* Last sync */}
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{t('sync.lastSync')}</span>
                <span className="font-semibold text-foreground ml-auto">{formatLastSync(details.lastSyncTime)}</span>
              </div>

              {/* Pending changes */}
              {details.pendingCount > 0 && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <RefreshCw className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>{t('sync.pendingChanges')}</span>
                  <span className="font-semibold text-primary ml-auto">{details.pendingCount}</span>
                </div>
              )}

              {/* Error */}
              {details.lastError && (
                <div className="flex items-start gap-2 text-destructive bg-destructive/10 rounded-lg p-2">
                  <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <p className="font-semibold text-xs">{t('sync.syncError')}</p>
                    <p className="text-xs truncate">{details.lastError}</p>
                  </div>
                </div>
              )}

              {/* All synced message */}
              {!details.lastError && details.pendingCount === 0 && status === 'synced' && (
                <p className="text-xs text-muted-foreground">{t('sync.allSynced')}</p>
              )}
            </div>

            {/* Offline description */}
            {status === 'offline' && (
              <p className="text-xs text-muted-foreground pt-2 border-t border-border">
                {t('sync.offlineDesc')}
              </p>
            )}

            {/* Retry button */}
            {details.lastError && (
              <button
                onClick={() => { retrySync(); setShowPanel(false); }}
                className="w-full flex items-center justify-center gap-2 h-9 rounded-lg bg-primary text-primary-foreground font-bold text-sm active:scale-95 transition-transform"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                {t('sync.retry')}
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
}