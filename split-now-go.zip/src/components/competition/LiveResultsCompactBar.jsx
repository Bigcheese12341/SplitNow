import React from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronDown } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger } from '@/components/ui/select';
import SeriesFilterSelect from '@/components/competition/SeriesFilterSelect';

// One shared pill style for the split point and series pickers.
const triggerClass = 'h-9 rounded-lg border-border bg-muted px-2.5 text-[13px] font-bold [&>svg]:h-4 [&>svg]:w-4 [&>svg]:opacity-60 [&>svg]:flex-shrink-0';

// The whole top of the opened live results panel on one row: the split point
// picker, the series picker and the arrow that closes the panel. No title, so
// the pickers get the width and the row stays one line tall.
export default function LiveResultsCompactBar({
  timingPoints,
  selectedSplit,
  onSplitChange,
  seriesOptions,
  seriesValue,
  onSeriesChange,
  onToggle,
}) {
  const { t } = useTranslation();
  const activePoint = timingPoints.find(point => point.index === selectedSplit);

  return (
    <div className="flex items-center gap-2 px-3 pb-1.5">
      <Select value={String(selectedSplit)} onValueChange={value => onSplitChange(Number(value))}>
        <SelectTrigger className={`${triggerClass} flex-1 min-w-0 gap-1.5`}>
          <span className="truncate">{activePoint?.label || ''}</span>
        </SelectTrigger>
        <SelectContent align="start">
          {timingPoints.map(point => (
            <SelectItem key={point.index} value={String(point.index)} className="py-2.5 font-semibold">
              {point.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <SeriesFilterSelect
        seriesOptions={seriesOptions}
        value={seriesValue}
        onChange={onSeriesChange}
        triggerClassName={`${triggerClass} w-auto max-w-[36%] flex-shrink-0 gap-1`}
      />

      <button
        onClick={onToggle}
        aria-label={t('quickTouch.liveResults')}
        className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center active:scale-95 transition-transform flex-shrink-0"
      >
        <ChevronDown className="w-5 h-5 text-foreground" />
      </button>
    </div>
  );
}