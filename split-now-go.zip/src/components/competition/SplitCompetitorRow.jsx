import React from 'react';
import { formatElapsed, formatGap } from '@/lib/timeUtils';
import { motion } from 'framer-motion';

export default function SplitCompetitorRow({
  competitor,
  rank,
  gap,
  hasSplit,
  elapsed,
  isNextExpected,
  flashResult,
  onNow,
  isNewEntry,
}) {
  const isFlashing = !!flashResult;
  const isLeader = hasSplit && rank === 1;
  // isNewEntry = just recorded, shown optimistically in results
  const isNewLeader = isNewEntry && rank === 1;

  if (hasSplit) {
    const rowBg = isNewLeader
      ? 'bg-green-50 border-green-300'
      : isNewEntry
      ? 'bg-red-50 border-red-200'
      : isLeader
      ? 'bg-amber-50 border-amber-200'
      : 'bg-card border-border';

    const timeColor = isNewLeader
      ? 'text-green-600 font-bold'
      : isNewEntry
      ? 'text-red-500 font-bold'
      : isLeader
      ? 'text-amber-500 font-bold'
      : 'text-muted-foreground font-medium';

    return (
      <motion.div
        layout
        initial={isNewEntry ? { scale: 0.97, opacity: 0 } : false}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className={`grid grid-cols-[2rem_2.5rem_1fr_4.5rem_3.5rem] gap-1 items-center px-3 py-3 rounded-xl border transition-all ${rowBg}`}
      >
        {/* Sijoitus – iso ja korostettu */}
        <span className={`font-black text-lg tabular-nums leading-none text-center ${
          isLeader || isNewLeader ? 'text-amber-500' : isNewEntry ? 'text-red-400' : 'text-foreground'
        }`}>
          {(isLeader || isNewLeader) ? '🥇' : rank}
        </span>
        {/* Numero – himmeä */}
        <span className="font-semibold tabular-nums text-sm text-muted-foreground/60">{competitor.bib_number}</span>
        <span className="text-sm font-medium truncate">{competitor.name || ''}</span>
        {/* Aika – vihreä/punainen jos uusi */}
        <span className={`text-right font-mono text-sm tabular-nums ${timeColor}`}>
          {formatElapsed(elapsed)}
        </span>
        {/* Ero – vihreä jos johdossa, punainen jos ei */}
        <span className={`text-right text-sm font-black tabular-nums ${
          isNewLeader ? 'text-green-600' :
          isNewEntry && gap > 0 ? 'text-red-500' :
          gap > 0 ? 'text-foreground' : 'text-transparent'
        }`}>
          {isNewLeader ? '↑ kärki' : gap > 0 ? formatGap(gap) : '—'}
        </span>
      </motion.div>
    );
  }

  // Odottava kilpailija
  return (
    <motion.div
      layout
      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl border-2 transition-colors ${
        isFlashing
          ? 'border-primary bg-primary/10'
          : isNextExpected
          ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10'
          : 'border-border bg-card'
      }`}
    >
      {/* Numero – himmeä odottavilla */}
      <span className={`w-10 tabular-nums text-xl leading-none font-semibold ${
        isNextExpected && !isFlashing ? 'text-primary font-black' : 'text-muted-foreground/50'
      }`}>
        {competitor.bib_number}
      </span>
      <span className="flex-1 text-sm font-medium truncate">{competitor.name || ''}</span>

      {isFlashing ? (
        <motion.div
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          className="flex items-center gap-2"
        >
          {/* Sijoitus – iso */}
          <span className="font-black text-primary tabular-nums text-xl leading-none">
            {flashResult.rank}.
          </span>
          {/* Aika – himmeä */}
          <span className="font-mono text-sm tabular-nums text-muted-foreground font-medium">
            {formatElapsed(flashResult.elapsed)}
          </span>
          {/* Ero – korostettu */}
          {flashResult.gap > 0 && (
            <span className="text-sm font-black text-foreground tabular-nums bg-muted px-1.5 py-0.5 rounded-lg">
              {formatGap(flashResult.gap)}
            </span>
          )}
        </motion.div>
      ) : (
        <button
          onClick={() => onNow(competitor)}
          className={`min-w-[4.5rem] h-12 rounded-xl font-extrabold text-base transition-all active:scale-95 select-none shadow-sm ${
            isNextExpected
              ? 'bg-primary text-primary-foreground shadow-primary/30 shadow-md'
              : 'bg-muted text-foreground hover:bg-primary/10'
          }`}
        >
          NYT
        </button>
      )}
    </motion.div>
  );
}