import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { formatElapsed, formatGap, formatLead } from '@/lib/timeUtils';
import SeriesBadge from '@/components/competition/SeriesBadge';
import { RESULT_TIME_CLASS, RESULT_GAP_CLASS } from '@/lib/resultStyles';
import { RotateCcw, Loader2 } from 'lucide-react';

const ROW_GRID = 'grid-cols-[2rem_2.5rem_minmax(0,1fr)_auto_4.25rem_3.5rem]';

export default function RecordedList({ recorded, standings = {}, competition, lastEntry, onUndo, onCompetitorTap }) {
  const { t } = useTranslation();
  const [undoing, setUndoing] = useState(false);

  const handleUndoClick = async () => {
    setUndoing(true);
    try {
      await onUndo();
    } finally {
      setUndoing(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-2 px-1">
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">
          {t('splitTime.recorded')} ({recorded.length})
        </h2>
        <AnimatePresence>
          {lastEntry && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={handleUndoClick}
              disabled={undoing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400 text-xs font-bold border border-amber-300 dark:border-amber-500/30 active:scale-95 transition-transform disabled:opacity-60"
            >
              {undoing ? (
                <>
                  <Loader2 className="w-3 h-3 animate-spin" />
                  {t('splitTime.undoing')}
                </>
              ) : (
                <>
                  <RotateCcw className="w-3 h-3" />
                  {t('splitTime.undo')}
                </>
              )}
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {/* Header */}
      <div className={`grid ${ROW_GRID} gap-1 px-3 py-1 text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1`}>
        <span>{t('results.rank')}</span>
        <span>{t('results.bibNumber')}</span>
        <span>{t('results.name')}</span>
        <span />
        <span className="text-right">{t('results.time')}</span>
        <span className="text-right">{t('results.gap')}</span>
      </div>

      <div className="space-y-1.5">
        <AnimatePresence>
          {recorded.map((c) => {
            const standing = standings[c.id] || {};
            const rank = c.elapsed !== null ? standing.rank : null;
            const gap = c.elapsed !== null ? standing.gap : null;
            const isLeader = rank === 1;
            const isNew = c.isFlash;
            const isNewLeader = isNew && c.flashData?.isNewLeader;
            const prevLeaderTime = c.flashData?.prevLeaderTime;

            let rowBg = 'bg-card border-border';
            if (c.isDNS) rowBg = 'bg-slate-50 border-slate-200 dark:bg-slate-500/10 dark:border-slate-500/20';
            else if (c.isDNF) rowBg = 'bg-red-50 border-red-200 dark:bg-red-500/10 dark:border-red-500/20';
            else if (c.isDSQ) rowBg = 'bg-blue-50 border-blue-200 dark:bg-blue-500/10 dark:border-blue-500/20';
            else if (isNewLeader) rowBg = 'bg-green-50 border-green-300 dark:bg-green-500/10 dark:border-green-500/20';
            else if (isNew) rowBg = 'bg-red-50 border-red-200 dark:bg-red-500/10 dark:border-red-500/20';
            else if (isLeader) rowBg = 'bg-amber-50 border-amber-200 dark:bg-amber-500/10 dark:border-amber-500/20';

            const hasStatus = c.isDNS || c.isDNF || c.isDSQ;

            const gapDisplay = (() => {
              if (c.isDNS) return t('splitTime.statusDNS');
              if (c.isDNF) return t('splitTime.statusDNF');
              if (c.isDSQ) return t('splitTime.statusDSQ');
              if (c.elapsed === null) return '—';
              if (isLeader) {
                if (isNewLeader && prevLeaderTime !== null && prevLeaderTime !== undefined) {
                  return formatLead(prevLeaderTime - c.elapsed);
                }
                return '+0.0';
              }
              return gap === null ? '—' : formatGap(gap);
            })();

            return (
              <motion.button
                key={c.id}
                layout
                initial={isNew ? { opacity: 0, y: -8 } : false}
                animate={{ opacity: 1, y: 0 }}
                onClick={() => onCompetitorTap(c)}
                className={`w-full grid ${ROW_GRID} gap-1 items-center px-3 py-2.5 rounded-xl border transition-all text-left ${rowBg}`}
              >
                <span className={`font-black text-base tabular-nums text-center leading-none ${
                  c.isDNS ? 'text-slate-400' :
                  c.isDNF ? 'text-red-500' :
                  c.isDSQ ? 'text-blue-500' :
                  isLeader ? 'text-amber-500 dark:text-amber-400' :
                  isNew ? (isNewLeader ? 'text-green-600 dark:text-green-400' : 'text-red-400') : 'text-foreground'
                }`}>
                  {hasStatus || !rank ? '—' : rank}
                </span>
                <span className="font-semibold tabular-nums text-sm text-muted-foreground/60">{c.bib_number}</span>
                <span className="text-sm font-medium truncate">{c.name || ''}</span>
                <SeriesBadge competitor={c} competition={competition} />
                <span className={`text-right font-mono text-sm tabular-nums ${
                  hasStatus ?
                    c.isDNS ? 'text-slate-500 dark:text-slate-400 font-bold' :
                    c.isDNF ? 'text-red-600 dark:text-red-400 font-bold' :
                    'text-blue-600 dark:text-blue-400 font-bold'
                  : RESULT_TIME_CLASS
                }`}>
                  {hasStatus ? gapDisplay : (c.elapsed !== null ? formatElapsed(c.elapsed) : '—')}
                </span>
                <span className={`text-right text-sm tabular-nums ${hasStatus ? 'text-muted-foreground font-bold' : RESULT_GAP_CLASS}`}>
                  {hasStatus ? '' : gapDisplay}
                </span>
              </motion.button>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}