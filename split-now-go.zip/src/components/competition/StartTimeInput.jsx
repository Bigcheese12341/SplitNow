import React from 'react';
import { Input } from '@/components/ui/input';
import { normalizeTime } from '@/lib/timeUtils';
import TimeInput from '@/components/competition/TimeInput';

// Start time of a competition.
//
// By default the device's own time picker is used (input type="time"), which is
// the quickest way to set an hour and minute. Mobile time pickers — iOS in
// particular — cannot reliably set seconds, so second precision switches this
// field to the app's own digit-by-digit input, the same one used for split times
// and competitor start times.
//
// The value handed out is always HH:MM:SS and an existing time is never touched
// by changing the mode, so switching back and forth keeps the stored seconds.
export default function StartTimeInput({ value, onChange, disabled, className, secondsPrecision }) {
  const display = normalizeTime(value);

  if (secondsPrecision) {
    return <TimeInput value={display} onChange={onChange} disabled={disabled} fluid />;
  }

  const handleChange = (e) => {
    const raw = e.target.value;
    // Empty or malformed value: keep the previous start time instead of
    // letting an invalid value reach the competition.
    if (!raw || !/^\d{1,2}:\d{2}(:\d{2})?$/.test(raw)) {
      e.target.value = display;
      return;
    }
    const next = normalizeTime(raw);
    if (next !== display) onChange(next);
  };

  return (
    <Input
      type="time"
      step="1"
      value={display}
      onChange={handleChange}
      disabled={disabled}
      className={className}
    />
  );
}