import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  competitorSeriesLabel, seriesIdentity,
  hasGenderCategorization, hasAgeCategorization,
} from '@/lib/seriesUtils';
import { seriesColorFor } from '@/lib/seriesPalette';

// Series label of a competitor inside the competition's active classification.
// The label is rendered in the reader's own language and the colour follows the
// series identity, so the same series looks the same for every user.
// Renders nothing when there is no series information to show, unless
// `showUnset` is set — the competitor detail views then say in plain words that
// no series has been defined instead of leaving an empty gap.
export default function SeriesBadge({ competitor, competition, showUnset = false, className = '' }) {
  const { t } = useTranslation();
  const categorized = hasGenderCategorization(competition) || hasAgeCategorization(competition);
  // Series are stored on the competitor but only shown while a classification is
  // enabled, so switching both off hides them everywhere without clearing data.
  if (!categorized) return null;

  const label = competitorSeriesLabel(competitor, competition, t);

  if (!label) {
    if (!showUnset) return null;
    return (
      <span
        className={`text-[10px] leading-none font-bold px-1.5 py-1 rounded flex-shrink-0 bg-muted text-muted-foreground ${className}`}
      >
        {t('common.seriesNotSet')}
      </span>
    );
  }

  return (
    <span
      className={`text-[10px] leading-none font-bold px-1.5 py-1 rounded flex-shrink-0 ${
        seriesColorFor(seriesIdentity(competitor), competition?.id)
      } ${className}`}
    >
      {label}
    </span>
  );
}