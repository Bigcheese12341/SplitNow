import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Undo2, Redo2, Route, MapPin, Layers, X, Check, Loader2, ImageIcon, Map as MapIcon, Trash2, Search } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { defaultRouteData, getMarkerShortLabel } from '@/lib/routeUtils';
import { loadImageElement, buildRoutePreviewUrl } from '@/lib/routeImage';
import { lockSwipeNavigation } from '@/lib/swipeNav';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import RouteImageCanvas from './RouteImageCanvas';
import RouteMapCanvas from './RouteMapCanvas';
import PlaceSearch from './PlaceSearch';

const DEFAULT_MAP_CENTER = [60.1699, 24.9384];
const DEFAULT_MAP_ZOOM = 14;
// The place search opens by itself the first time the map route is used in this session
let mapSearchAutoOpened = false;

function normalizeInitialRoute(data) {
  const base = { ...defaultRouteData(), ...(data || {}) };
  const hasBase = base.mode === 'image' ? !!base.imageUrl : base.mode === 'map';
  if (hasBase) return { ...base, type: base.mode === 'image' ? 'uploaded_image' : 'drawn' };
  return {
    ...base,
    mode: 'map',
    mapLayer: 'street',
    mapCenter: base.mapCenter || DEFAULT_MAP_CENTER,
    mapZoom: base.mapZoom || DEFAULT_MAP_ZOOM,
    routePoints: base.routePoints || [],
    markers: base.markers || [],
  };
}

export default function RouteEditor({ initialRouteData, splitCount, addFinish, onDone, onAutoSave, onClose, onReject, t }) {
  const initialRef = useRef(null);
  if (!initialRef.current) initialRef.current = normalizeInitialRoute(initialRouteData);
  const [routeData, setRouteData] = useState(initialRef.current);
  const [activeTool, setActiveTool] = useState(() => (initialRef.current.mode === 'map' && initialRef.current.routePoints.length === 0 ? 'route' : null));
  const [routeActive, setRouteActive] = useState(false);
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [selectedMarker, setSelectedMarker] = useState(null);
  const [pendingMarkerType, setPendingMarkerType] = useState(null);
  const [pendingMarkerLabel, setPendingMarkerLabel] = useState(null);
  const [showBaseMenu, setShowBaseMenu] = useState(false);
  const [showMarkerMenu, setShowMarkerMenu] = useState(false);
  const [showAutoDetect, setShowAutoDetect] = useState(null);
  const [detecting, setDetecting] = useState(false);
  const [detectError, setDetectError] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [saveStatus, setSaveStatus] = useState('idle');
  const [saving, setSaving] = useState(false);
  const [hint, setHint] = useState(null);
  const [pendingBase, setPendingBase] = useState(null);
  const [confirmReject, setConfirmReject] = useState(false);
  const [notice, setNotice] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mapSearchTarget, setMapSearchTarget] = useState(null);

  const historyRef = useRef([JSON.parse(JSON.stringify(routeData))]);
  const historyIndexRef = useRef(0);
  const autoSaveTimer = useRef(null);
  const fileInputRef = useRef(null);
  const hintTimer = useRef(null);

  useEffect(() => () => { if (hintTimer.current) clearTimeout(hintTimer.current); }, []);

  const updateRouteData = useCallback((newData, recordHistory = true) => {
    setRouteData(newData);
    if (recordHistory) {
      const hist = historyRef.current.slice(0, historyIndexRef.current + 1);
      hist.push(JSON.parse(JSON.stringify(newData)));
      if (hist.length > 50) hist.shift();
      historyRef.current = hist;
      historyIndexRef.current = hist.length - 1;
    }
    setSaveStatus('saving');
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    autoSaveTimer.current = setTimeout(() => {
      setSaveStatus('saved');
      if (onAutoSave) Promise.resolve(onAutoSave(newData)).catch(() => setNotice(t('route.saveFailed')));
    }, 1500);
  }, [onAutoSave, t]);

  const undo = () => {
    if (historyIndexRef.current > 0) {
      historyIndexRef.current--;
      const prev = historyRef.current[historyIndexRef.current];
      setRouteData(JSON.parse(JSON.stringify(prev)));
      setSaveStatus('saving');
      if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
      autoSaveTimer.current = setTimeout(() => { setSaveStatus('saved'); if (onAutoSave) onAutoSave(prev); }, 1500);
    }
  };

  const redo = () => {
    if (historyIndexRef.current < historyRef.current.length - 1) {
      historyIndexRef.current++;
      const next = historyRef.current[historyIndexRef.current];
      setRouteData(JSON.parse(JSON.stringify(next)));
      setSaveStatus('saving');
      if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
      autoSaveTimer.current = setTimeout(() => { setSaveStatus('saved'); if (onAutoSave) onAutoSave(next); }, 1500);
    }
  };

  // No tab swiping while the editor is open: map panning and pinching stay map gestures
  useEffect(() => lockSwipeNavigation(), []);

  // First time the map route is opened the place search is already waiting for a name
  useEffect(() => {
    if (routeData.mode !== 'map' || mapSearchAutoOpened) return;
    mapSearchAutoOpened = true;
    setSearchOpen(true);
  }, [routeData.mode]);

  // Block browser back-swipe while the editor is open
  useEffect(() => {
    let active = true;
    const pushGuard = () => window.history.pushState({ ...(window.history.state || {}), routeEditor: true }, '');
    pushGuard();
    const onPop = () => {
      if (active) pushGuard();
    };
    window.addEventListener('popstate', onPop);
    return () => {
      active = false;
      window.removeEventListener('popstate', onPop);
      if (window.history.state?.routeEditor) window.history.back();
    };
  }, []);

  const canUndo = historyIndexRef.current > 0;
  const canRedo = historyIndexRef.current < historyRef.current.length - 1;

  const handleDeactivateTool = useCallback(() => {
    setActiveTool(null);
    setPendingMarkerType(null);
    setPendingMarkerLabel(null);
    setRouteActive(false);
    setSelectedPoint(null);
    setSelectedMarker(null);
  }, []);

  const handleActivateTool = useCallback((tool) => {
    setActiveTool(tool);
    if (tool === 'route') setRouteActive(true);
  }, []);

  const handleToolClick = (tool) => {
    if (activeTool === tool) {
      setActiveTool(null);
      setPendingMarkerType(null);
    } else {
      setActiveTool(tool);
      if (tool === 'route') setRouteActive(true);
      if (tool === 'markers') setShowMarkerMenu(true);
      else setPendingMarkerType(null);
    }
  };

  const isSupportedImage = (file) => /^image\/(jpeg|jpg|png|webp)$/i.test(file.type) || /\.(jpe?g|png|webp)$/i.test(file.name);

  const hasDrawings = () => routeData.routePoints.length > 0 || routeData.markers.length > 0;

  const applyMapBase = () => {
    updateRouteData({
      ...routeData,
      mode: 'map',
      imageUrl: null,
      imageSize: null,
      mapLayer: routeData.mapLayer === 'satellite' ? 'satellite' : 'street',
      mapCenter: routeData.mapCenter || DEFAULT_MAP_CENTER,
      mapZoom: routeData.mapZoom || DEFAULT_MAP_ZOOM,
      routePoints: [],
      markers: [],
    });
    setActiveTool('route');
    setRouteActive(true);
  };

  const applyImageBase = async (file) => {
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      const img = await loadImageElement(file_url);
      updateRouteData({
        ...defaultRouteData(),
        mode: 'image',
        imageUrl: file_url,
        imageSize: { width: img.naturalWidth, height: img.naturalHeight },
      });
      setActiveTool('route');
      setRouteActive(false);
    } catch (err) {
      setNotice(t('route.invalidImage'));
    }
    setUploading(false);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setShowBaseMenu(false);
    if (!isSupportedImage(file)) {
      setNotice(t('route.invalidImage'));
      return;
    }
    if (hasDrawings()) setPendingBase({ type: 'image', file });
    else applyImageBase(file);
  };

  const handleAddMap = () => {
    setShowBaseMenu(false);
    if (routeData.mode !== 'map' && hasDrawings()) setPendingBase({ type: 'map' });
    else applyMapBase();
  };

  const handleRouteClosed = useCallback(() => {
    setHint(t('route.routeClosed'));
    if (hintTimer.current) clearTimeout(hintTimer.current);
    hintTimer.current = setTimeout(() => setHint(null), 2500);
  }, [t]);

  const handlePickPlace = (place) => {
    setMapSearchTarget({ center: [place.lat, place.lng], bbox: place.bbox || null });
  };

  const handleAutoDetect = async (imageUrl) => {
    setShowAutoDetect(null);
    setDetecting(true);
    setDetectError(null);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: "This image shows a competition route map. Identify the route line and return it as an ordered list of points. Each point has x (0-1, left to right) and y (0-1, top to bottom). Also identify start and finish points if visible. Return JSON.",
        file_urls: [imageUrl],
        model: "gemini_3_flash",
        response_json_schema: {
          type: "object",
          properties: {
            routePoints: { type: "array", items: { type: "object", properties: { x: { type: "number" }, y: { type: "number" } } } },
            start: { type: "object", properties: { x: { type: "number" }, y: { type: "number" } } },
            finish: { type: "object", properties: { x: { type: "number" }, y: { type: "number" } } }
          }
        }
      });

      if (result.routePoints && result.routePoints.length > 1) {
        const markers = [];
        if (result.start) markers.push({ type: 'start', splitIndex: null, position: result.start });
        if (result.finish) markers.push({ type: 'finish', splitIndex: null, position: result.finish });
        updateRouteData({ ...routeData, routePoints: result.routePoints, markers });
        setActiveTool('route');
        setRouteActive(true);
      } else {
        setDetectError(t('route.routeNotFound'));
      }
    } catch (err) {
      setDetectError(t('route.routeNotFound'));
    }
    setDetecting(false);
  };

  const handleDone = async () => {
    if (saving) return;
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    setSaving(true);
    setNotice(null);
    let previewUrl = null;
    try {
      previewUrl = await buildRoutePreviewUrl(routeData);
    } catch (err) {
      console.error('Route preview failed', err);
    }
    try {
      // The route is only replaced once this save actually succeeded
      if (onDone) await onDone(routeData, previewUrl);
    } catch (err) {
      console.error('Save failed', err);
      setNotice(t('route.saveFailed'));
    }
    setSaving(false);
  };

  const isDirty = JSON.stringify(routeData) !== JSON.stringify(initialRef.current);

  const handleClose = () => {
    if (saving) return;
    if (isDirty) setConfirmReject(true);
    else onClose();
  };

  const handleRejectConfirm = async () => {
    setConfirmReject(false);
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    if (onReject) await onReject(initialRef.current);
    else onClose();
  };

  const markerOptions = [];
  markerOptions.push({ type: 'start', splitIndex: null, label: t('route.start') });
  for (let i = 1; i <= splitCount; i++) {
    markerOptions.push({ type: 'split', splitIndex: i, label: t('route.split', { n: i }) });
  }
  markerOptions.push({ type: 'finish', splitIndex: null, label: t('route.finish') });

  const hasBaseLayer = routeData.mode === 'image' ? !!routeData.imageUrl : routeData.mode === 'map';
  const menuTop = 'top-16';

  const ToolButton = ({ icon, label, active, onClick, disabled }) => (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`flex items-center justify-center p-1.5 rounded-lg transition-all ${
        active ? 'bg-primary text-primary-foreground shadow-md' : 'text-foreground hover:bg-muted'
      } disabled:opacity-30 disabled:cursor-not-allowed`}
    >
      {icon}
    </button>
  );

  return (
    <div className="fixed inset-0 z-[9999] bg-background flex flex-col" style={{ overscrollBehavior: 'none', touchAction: 'manipulation' }}>
      <div className="flex items-center justify-between px-2 py-1.5 bg-card border-b border-border gap-1">
        <div className="flex items-center gap-0.5 min-w-0 overflow-x-auto">
          <ToolButton icon={<Undo2 className="w-5 h-5" />} active={false} onClick={undo} disabled={!canUndo} />
          <ToolButton icon={<Redo2 className="w-5 h-5" />} active={false} onClick={redo} disabled={!canRedo} />
          <ToolButton icon={<Route className="w-5 h-5" />} active={activeTool === 'route'} onClick={() => handleToolClick('route')} disabled={!hasBaseLayer} />
          <ToolButton icon={<MapPin className="w-5 h-5" />} active={activeTool === 'markers'} onClick={() => handleToolClick('markers')} disabled={!hasBaseLayer} />
          <ToolButton icon={<Layers className="w-5 h-5" />} active={false} onClick={() => setShowBaseMenu(true)} />
          <ToolButton
            icon={<Search className="w-5 h-5" />}
            active={searchOpen}
            onClick={() => setSearchOpen((open) => !open)}
            disabled={!hasBaseLayer || routeData.mode !== 'map'}
          />
        </div>
        <div className="flex items-center gap-0.5 flex-shrink-0">
          <button type="button" onClick={handleDone} disabled={saving} className="p-2 rounded-lg bg-primary text-primary-foreground shadow-md disabled:opacity-50 flex items-center justify-center">
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Check className="w-5 h-5" />}
          </button>
          <button type="button" onClick={handleClose} className="p-2 rounded-lg text-foreground hover:bg-muted flex items-center justify-center">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {showBaseMenu && (
        <>
          <div className="fixed inset-0 z-[9998]" onClick={() => setShowBaseMenu(false)} />
          <div className={`absolute ${menuTop} right-2 z-[9999] bg-card rounded-xl border border-border shadow-xl py-1 w-48`}>
            <button type="button" onClick={() => fileInputRef.current?.click()} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm font-semibold hover:bg-muted text-left">
              <ImageIcon className="w-4 h-4" /> {t('route.addRouteImage')}
            </button>
            <button type="button" onClick={handleAddMap} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm font-semibold hover:bg-muted text-left">
              <MapIcon className="w-4 h-4" /> {t('route.addRouteMap')}
            </button>
          </div>
        </>
      )}

      {showMarkerMenu && (
        <>
          <div className="fixed inset-0 z-[9998]" onClick={() => setShowMarkerMenu(false)} />
          <div className={`absolute ${menuTop} left-1/2 -translate-x-1/2 z-[9999] bg-card rounded-xl border border-border shadow-xl py-1 w-56`}>
            {markerOptions.map((opt) => (
              <button
                key={`${opt.type}-${opt.splitIndex || ''}`}
                type="button"
                onClick={() => {
                  setPendingMarkerType(opt);
                  setPendingMarkerLabel(opt.label);
                  setShowMarkerMenu(false);
                }}
                className="w-full flex items-center gap-2 px-4 py-2.5 text-sm font-semibold hover:bg-muted text-left"
              >
                <span className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                      style={{ background: opt.type === 'start' ? '#22c55e' : opt.type === 'finish' ? '#ef4444' : '#3b82f6' }}>
                  {getMarkerShortLabel(opt.type, opt.splitIndex)}
                </span>
                {opt.label}
              </button>
            ))}
          </div>
        </>
      )}

      {pendingMarkerType && pendingMarkerLabel && (
        <div className={`absolute ${menuTop} left-1/2 -translate-x-1/2 z-[500] bg-card rounded-xl border border-border shadow-xl px-4 py-2.5 flex items-center gap-2`}>
          <MapPin className="w-4 h-4 text-primary" />
          <span className="text-sm font-bold text-foreground">{t('common.add')} {pendingMarkerLabel}</span>
          <button
            type="button"
            onClick={() => { setPendingMarkerType(null); setPendingMarkerLabel(null); }}
            className="ml-1 text-muted-foreground hover:text-foreground"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {hint && (
        <div className={`absolute ${menuTop} left-1/2 -translate-x-1/2 z-[900] bg-card rounded-xl border border-border shadow-xl px-4 py-2`}>
          <p className="text-sm font-bold text-foreground">{hint}</p>
        </div>
      )}

      <input ref={fileInputRef} type="file" accept="image/jpeg,image/jpg,image/png,image/webp" className="hidden" onChange={handleImageUpload} />

      {notice && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[10000] bg-card rounded-xl border border-border shadow-xl px-4 py-3 max-w-sm">
          <p className="text-sm text-foreground">{notice}</p>
          <button type="button" onClick={() => setNotice(null)} className="mt-2 text-xs font-bold text-primary">{t('common.ok')}</button>
        </div>
      )}

      {showAutoDetect && (
        <div className="absolute inset-0 z-[10000] bg-black/60 flex items-center justify-center p-6">
          <div className="bg-card rounded-2xl p-6 max-w-sm w-full space-y-4">
            <h3 className="text-lg font-black text-center">{t('route.autoDetectTitle')}</h3>
            <p className="text-sm text-muted-foreground text-center">{t('route.autoDetectDesc')}</p>
            <div className="flex gap-2">
              <button type="button" onClick={() => handleAutoDetect(showAutoDetect)} disabled={detecting}
                      className="flex-1 h-12 rounded-xl bg-primary text-primary-foreground font-bold text-sm disabled:opacity-50">
                {detecting ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : t('route.autoDetectAccept')}
              </button>
              <button type="button" onClick={() => setShowAutoDetect(null)} disabled={detecting}
                      className="flex-1 h-12 rounded-xl bg-muted text-foreground font-bold text-sm">
                {t('route.autoDetectDecline')}
              </button>
            </div>
          </div>
        </div>
      )}

      {detectError && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[10000] bg-card rounded-xl border border-border shadow-xl px-4 py-3 max-w-sm">
          <p className="text-sm text-foreground">{detectError}</p>
          <button type="button" onClick={() => setDetectError(null)} className="mt-2 text-xs font-bold text-primary">{t('common.ok')}</button>
        </div>
      )}

      {uploading && (
        <div className="absolute inset-0 z-[10000] bg-black/70 flex items-center justify-center">
          <div className="bg-card rounded-2xl p-8 flex flex-col items-center gap-4 max-w-xs w-full mx-6">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
            <div className="text-center">
              <p className="font-bold text-foreground">{t('route.uploadingImage')}</p>
              <p className="text-sm text-muted-foreground mt-1">{t('route.uploadingImageDesc')}</p>
            </div>
          </div>
        </div>
      )}

      {detecting && (
        <div className="absolute inset-0 z-[10000] bg-black/70 flex items-center justify-center">
          <div className="bg-card rounded-2xl p-8 flex flex-col items-center gap-4 max-w-xs w-full mx-6">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
            <div className="text-center">
              <p className="font-bold text-foreground">{t('route.detectingRoute')}</p>
              <p className="text-sm text-muted-foreground mt-1">{t('route.detectingRouteDesc')}</p>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 relative">
        {!hasBaseLayer && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 text-center px-6">
            <Layers className="w-12 h-12 text-muted-foreground" />
            <div>
              <p className="font-bold text-foreground">{t('route.noBaseLayer')}</p>
              <p className="text-sm text-muted-foreground mt-1">{t('route.addBaseLayerHint')}</p>
            </div>
            <button type="button" onClick={() => setShowBaseMenu(true)} className="flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-bold shadow-lg">
              <Layers className="w-5 h-5" /> {t('route.addBaseLayer')}
            </button>
          </div>
        )}
        {hasBaseLayer && routeData.mode === 'image' && (
          <RouteImageCanvas
            routeData={routeData}
            activeTool={activeTool}
            selectedPoint={selectedPoint}
            selectedMarker={selectedMarker}
            routeActive={routeActive}
            pendingMarkerType={pendingMarkerType}
            onUpdate={updateRouteData}
            onSelectPoint={setSelectedPoint}
            onSelectMarker={setSelectedMarker}
            onRouteActive={setRouteActive}
            onActivateTool={handleActivateTool}
            onDeactivateTool={handleDeactivateTool}
            onCloseRoute={handleRouteClosed}
          />
        )}
        {hasBaseLayer && routeData.mode === 'map' && (
          <RouteMapCanvas
            routeData={routeData}
            activeTool={activeTool}
            selectedPoint={selectedPoint}
            selectedMarker={selectedMarker}
            routeActive={routeActive}
            pendingMarkerType={pendingMarkerType}
            onUpdate={updateRouteData}
            onSelectPoint={setSelectedPoint}
            onSelectMarker={setSelectedMarker}
            onRouteActive={setRouteActive}
            onActivateTool={handleActivateTool}
            onDeactivateTool={handleDeactivateTool}
            mapSearchTarget={mapSearchTarget}
            onCloseRoute={handleRouteClosed}
          />
        )}
        {routeData.mode === 'map' && hasBaseLayer && searchOpen && (
          <PlaceSearch onPick={handlePickPlace} onClose={() => setSearchOpen(false)} t={t} />
        )}
      </div>

      {activeTool === 'route' && hasBaseLayer && routeData.routePoints.length === 0 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-card/90 backdrop-blur rounded-xl px-4 py-2 shadow-lg">
          <p className="text-sm font-semibold text-foreground">{t('route.clickToAddPoints')}</p>
        </div>
      )}

      {routeData.mode === 'map' && (selectedPoint !== null || selectedMarker !== null) && hasBaseLayer && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[500] flex gap-2">
          <button
            type="button"
            onClick={() => {
              if (selectedPoint !== null) {
                const newPoints = routeData.routePoints.filter((_, i) => i !== selectedPoint);
                updateRouteData({ ...routeData, routePoints: newPoints, closed: newPoints.length >= 3 ? routeData.closed : false });
                setSelectedPoint(null);
              } else if (selectedMarker !== null) {
                const newMarkers = routeData.markers.filter((_, i) => i !== selectedMarker);
                updateRouteData({ ...routeData, markers: newMarkers });
                setSelectedMarker(null);
              }
            }}
            className="px-4 py-2.5 rounded-xl bg-destructive text-destructive-foreground font-bold text-sm shadow-lg flex items-center gap-2 active:scale-95 transition-transform"
          >
            <Trash2 className="w-4 h-4" />
            {t('common.delete')}
          </button>
        </div>
      )}

      <AlertDialog open={confirmReject} onOpenChange={setConfirmReject}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('route.discardConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>{t('route.discardDesc')}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleRejectConfirm} className="bg-destructive text-destructive-foreground">
              {t('route.reject')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!pendingBase} onOpenChange={(open) => { if (!open) setPendingBase(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('route.switchBaseConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>{t('route.switchBaseDesc')}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              const next = pendingBase;
              setPendingBase(null);
              if (next?.type === 'image') applyImageBase(next.file);
              else applyMapBase();
            }}>
              {t('common.confirm')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}