import React, { useCallback, useEffect, useRef, useState } from 'react';
import { X, MapPin, Check, Loader2 } from 'lucide-react';
import { defaultRouteData, getMarkerShortLabel } from '@/lib/routeUtils';
import { cropImageAndUpload, buildRoutePreviewUrl } from '@/lib/routeImage';
import { lockSwipeNavigation } from '@/lib/swipeNav';
import RouteImageCanvas from './RouteImageCanvas';

const MIN_SIZE = 48;

const HANDLES = [
  { dir: 'nw', cls: '-left-2.5 -top-2.5 cursor-nwse-resize' },
  { dir: 'n', cls: 'left-1/2 -ml-2.5 -top-2.5 cursor-ns-resize' },
  { dir: 'ne', cls: '-right-2.5 -top-2.5 cursor-nesw-resize' },
  { dir: 'e', cls: '-right-2.5 top-1/2 -mt-2.5 cursor-ew-resize' },
  { dir: 'se', cls: '-right-2.5 -bottom-2.5 cursor-nwse-resize' },
  { dir: 's', cls: 'left-1/2 -ml-2.5 -bottom-2.5 cursor-ns-resize' },
  { dir: 'sw', cls: '-left-2.5 -bottom-2.5 cursor-nesw-resize' },
  { dir: 'w', cls: '-left-2.5 top-1/2 -mt-2.5 cursor-ew-resize' },
];

const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

export default function RouteImageEditor({ imageUrl, imageSize, splitCount, onDone, onCancel, t }) {
  const [phase, setPhase] = useState('crop');
  const [routeData, setRouteData] = useState(() => ({
    ...defaultRouteData(),
    mode: 'image',
    type: 'uploaded_image',
    imageUrl,
    imageSize,
  }));
  // The crop is kept normalized (0..1) so it survives every layout or screen change
  const [crop, setCrop] = useState({ x: 0.07, y: 0.07, width: 0.86, height: 0.86 });
  const [view, setView] = useState({ width: 0, height: 0 });
  const [saving, setSaving] = useState(false);
  const [cropping, setCropping] = useState(false);
  const [error, setError] = useState(null);
  const [showMarkerMenu, setShowMarkerMenu] = useState(false);
  const [pendingMarker, setPendingMarker] = useState(null);

  const imgRef = useRef(null);
  const previewRef = useRef(null);
  const loadedImgRef = useRef(null);
  const dragRef = useRef(null);
  const frameRef = useRef(0);

  // No tab swiping while the editor is open: crop gestures stay image gestures
  useEffect(() => lockSwipeNavigation(), []);

  // Block browser back-swipe while the editor is open
  useEffect(() => {
    let active = true;
    const pushGuard = () => window.history.pushState({ ...(window.history.state || {}), routeImageEditor: true }, '');
    pushGuard();
    const onPop = () => {
      if (active) pushGuard();
    };
    window.addEventListener('popstate', onPop);
    return () => {
      active = false;
      window.removeEventListener('popstate', onPop);
      if (window.history.state?.routeImageEditor) window.history.back();
    };
  }, []);

  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => { loadedImgRef.current = img; };
    img.onerror = () => setError(t('route.invalidImage'));
    img.src = imageUrl;
  }, [imageUrl, t]);

  // Follow the displayed image size, never moving the crop itself
  useEffect(() => {
    if (phase !== 'crop') return;
    const el = imgRef.current;
    if (!el) return;
    const update = () => {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) return;
      setView({ width: r.width, height: r.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [phase]);

  // Live preview of the cropped result
  useEffect(() => {
    const cv = previewRef.current;
    const img = loadedImgRef.current;
    if (phase !== 'crop' || !cv || !img || !view.width) return;
    const sx = crop.x * img.naturalWidth;
    const sy = crop.y * img.naturalHeight;
    const sw = Math.max(1, crop.width * img.naturalWidth);
    const sh = Math.max(1, crop.height * img.naturalHeight);

    let pw = 96;
    let ph = Math.round(pw * (sh / sw));
    if (ph > 96) { ph = 96; pw = Math.max(1, Math.round(ph * (sw / sh))); }
    cv.width = pw;
    cv.height = ph;
    const ctx = cv.getContext('2d');
    ctx.clearRect(0, 0, pw, ph);
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, pw, ph);
  }, [crop, view, phase]);

  // Pointer movement is applied once per animation frame so dragging stays smooth
  const applyMove = useCallback((clientX, clientY) => {
    const d = dragRef.current;
    if (!d) return;
    const dx = (clientX - d.startX) / d.view.width;
    const dy = (clientY - d.startY) / d.view.height;
    const s = d.start;
    const minW = Math.min(1, MIN_SIZE / d.view.width);
    const minH = Math.min(1, MIN_SIZE / d.view.height);

    if (d.mode === 'move') {
      setCrop({
        ...s,
        x: clamp(s.x + dx, 0, 1 - s.width),
        y: clamp(s.y + dy, 0, 1 - s.height),
      });
      return;
    }

    let left = s.x;
    let top = s.y;
    let right = s.x + s.width;
    let bottom = s.y + s.height;
    if (d.dir.includes('w')) left = clamp(s.x + dx, 0, right - minW);
    if (d.dir.includes('e')) right = clamp(s.x + s.width + dx, left + minW, 1);
    if (d.dir.includes('n')) top = clamp(s.y + dy, 0, bottom - minH);
    if (d.dir.includes('s')) bottom = clamp(s.y + s.height + dy, top + minH, 1);
    setCrop({ x: left, y: top, width: right - left, height: bottom - top });
  }, []);

  useEffect(() => {
    if (phase !== 'crop') return;
    const onMove = (e) => {
      const d = dragRef.current;
      if (!d) return;
      d.last = { x: e.clientX, y: e.clientY };
      if (frameRef.current) return;
      frameRef.current = requestAnimationFrame(() => {
        frameRef.current = 0;
        const cur = dragRef.current;
        if (cur?.last) applyMove(cur.last.x, cur.last.y);
      });
    };
    const onUp = () => { dragRef.current = null; };
    window.addEventListener('pointermove', onMove, { passive: false });
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [phase, applyMove]);

  const startDrag = (e, mode, dir) => {
    if (e.button !== undefined && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    if (!view.width || !view.height) return;
    dragRef.current = {
      mode,
      dir,
      startX: e.clientX,
      startY: e.clientY,
      start: { ...crop },
      view: { ...view },
      last: null,
    };
  };

  const handleCrop = async () => {
    if (!crop || cropping) return;
    setCropping(true);
    setError(null);
    try {
      const cropped = await cropImageAndUpload(routeData.imageUrl, crop);
      setRouteData((prev) => ({
        ...prev,
        imageUrl: cropped.url,
        imageSize: { width: cropped.width, height: cropped.height },
      }));
      setPhase('markers');
    } catch (err) {
      console.error('Crop failed', err);
      setError(t('route.invalidImage'));
    }
    setCropping(false);
  };

  const handleAccept = async () => {
    if (saving) return;
    setSaving(true);
    setError(null);
    const data = { ...routeData, type: 'uploaded_image' };
    let previewUrl = null;
    try {
      previewUrl = await buildRoutePreviewUrl(data);
    } catch (err) {
      console.error('Route preview failed', err);
    }
    try {
      // The parent saves the route and closes this editor only on success
      await onDone(data, previewUrl);
    } catch (err) {
      console.error('Route image save failed', err);
      setError(t('route.saveFailed'));
      setSaving(false);
    }
  };

  const markerOptions = [{ type: 'start', splitIndex: null, label: t('route.start') }];
  for (let i = 1; i <= splitCount; i++) {
    markerOptions.push({ type: 'split', splitIndex: i, label: t('route.split', { n: i }) });
  }
  markerOptions.push({ type: 'finish', splitIndex: null, label: t('route.finish') });

  const rectPx = view.width && view.height
    ? { x: crop.x * view.width, y: crop.y * view.height, width: crop.width * view.width, height: crop.height * view.height }
    : null;

  return (
    <div className="fixed inset-0 z-[9999] bg-background flex flex-col" style={{ overscrollBehavior: 'none' }}>
      <div className="flex items-center justify-between px-2 py-1.5 bg-card border-b border-border gap-1">
        <div className="flex items-center gap-0.5 min-w-0">
          <button
            type="button"
            onClick={onCancel}
            aria-label={t('route.close')}
            className="flex items-center justify-center p-1.5 rounded-lg text-foreground hover:bg-muted"
          >
            <X className="w-5 h-5" />
          </button>
          {phase === 'markers' && (
            <button
              type="button"
              onClick={() => setShowMarkerMenu((prev) => !prev)}
              aria-label={t('route.addMarkers')}
              title={t('route.addMarkers')}
              className={`flex items-center justify-center p-1.5 rounded-lg transition-all ${
                pendingMarker ? 'bg-primary text-primary-foreground shadow-md' : 'text-foreground hover:bg-muted'
              }`}
            >
              <MapPin className="w-5 h-5" />
            </button>
          )}
        </div>
        <button
          type="button"
          onClick={phase === 'crop' ? handleCrop : handleAccept}
          disabled={saving || cropping}
          className="px-3 h-9 rounded-lg bg-primary text-primary-foreground text-xs font-bold shadow-md disabled:opacity-50 flex items-center justify-center gap-1 flex-shrink-0"
        >
          {saving || cropping ? <Loader2 className="w-4 h-4 animate-spin" /> : phase === 'markers' ? <Check className="w-4 h-4" /> : null}
          {phase === 'crop' ? t('route.cropApply') : t('route.accept')}
        </button>
      </div>

      {showMarkerMenu && (
        <>
          <div className="fixed inset-0 z-[9998]" onClick={() => setShowMarkerMenu(false)} />
          <div className="absolute top-14 left-2 z-[9999] bg-card rounded-xl border border-border shadow-xl py-1 w-56">
            {markerOptions.map((opt) => (
              <button
                key={`${opt.type}-${opt.splitIndex || ''}`}
                type="button"
                onClick={() => {
                  setPendingMarker(opt);
                  setShowMarkerMenu(false);
                }}
                className="w-full flex items-center gap-2 px-4 py-2.5 text-sm font-semibold hover:bg-muted text-left"
              >
                <span
                  className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                  style={{ background: opt.type === 'start' ? '#22c55e' : opt.type === 'finish' ? '#ef4444' : '#3b82f6' }}
                >
                  {getMarkerShortLabel(opt.type, opt.splitIndex)}
                </span>
                {opt.label}
              </button>
            ))}
          </div>
        </>
      )}

      {phase === 'markers' && pendingMarker && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-[500] bg-card rounded-xl border border-border shadow-xl px-4 py-2.5 flex items-center gap-2 max-w-[90%]">
          <MapPin className="w-4 h-4 text-primary flex-shrink-0" />
          <span className="text-sm font-bold text-foreground">{t('common.add')} {pendingMarker.label}</span>
          <button type="button" onClick={() => setPendingMarker(null)} className="ml-1 text-muted-foreground hover:text-foreground">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {error && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[10000] bg-card rounded-xl border border-border shadow-xl px-4 py-3 max-w-sm">
          <p className="text-sm text-foreground">{error}</p>
          <button type="button" onClick={() => setError(null)} className="mt-2 text-xs font-bold text-primary">{t('common.ok')}</button>
        </div>
      )}

      {phase === 'crop' ? (
        <>
          <div
            className="flex-1 relative flex items-center justify-center overflow-hidden p-3"
            style={{ touchAction: 'none', overscrollBehavior: 'contain' }}
          >
            <div className="relative select-none" style={{ maxWidth: '100%' }}>
              <img ref={imgRef} src={routeData.imageUrl} alt="" draggable={false} className="block max-w-full max-h-[62vh] pointer-events-none" />
              {rectPx && (
                <div className="absolute inset-0" style={{ touchAction: 'none' }}>
                  <div
                    className="absolute border-2 border-white cursor-move shadow-[0_0_0_9999px_rgba(0,0,0,0.55)]"
                    style={{ left: rectPx.x, top: rectPx.y, width: rectPx.width, height: rectPx.height, touchAction: 'none' }}
                    onPointerDown={(e) => startDrag(e, 'move')}
                  >
                    {HANDLES.map((h) => (
                      <div
                        key={h.dir}
                        onPointerDown={(e) => startDrag(e, 'resize', h.dir)}
                        className={`absolute w-6 h-6 rounded-full bg-white border-2 border-primary shadow ${h.cls}`}
                        style={{ touchAction: 'none' }}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="px-3 py-2 bg-card border-t border-border flex items-center gap-3">
            <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wide">{t('route.cropPreview')}</span>
            <canvas ref={previewRef} className="rounded-md border border-border bg-black h-auto" />
            {!rectPx && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
          </div>
        </>
      ) : (
        <div className="flex-1 relative">
          <RouteImageCanvas
            routeData={routeData}
            activeTool="markers"
            selectedPoint={null}
            selectedMarker={null}
            routeActive={false}
            pendingMarkerType={pendingMarker}
            onUpdate={setRouteData}
            onSelectPoint={() => {}}
            onSelectMarker={() => {}}
            onRouteActive={() => {}}
            onActivateTool={() => {}}
            onDeactivateTool={() => {}}
          />
          {!pendingMarker && routeData.markers.length === 0 && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-card/90 backdrop-blur rounded-xl px-4 py-2 shadow-lg">
              <p className="text-sm font-semibold text-foreground">{t('route.addMarkers')}</p>
            </div>
          )}
        </div>
      )}

      {(saving || cropping) && (
        <div className="absolute inset-0 z-[10000] bg-black/70 flex items-center justify-center">
          <div className="bg-card rounded-2xl p-8 flex flex-col items-center gap-4 max-w-xs w-full mx-6">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
            <p className="font-bold text-foreground text-center">{cropping ? t('route.uploadingImage') : t('route.saving')}</p>
          </div>
        </div>
      )}
    </div>
  );
}