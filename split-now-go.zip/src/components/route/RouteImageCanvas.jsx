import React, { useRef, useState, useEffect, useMemo } from 'react';
import { getMarkerColor, getMarkerShortLabel, snapToRoute, smoothPathSVG, closedPathPoints } from '@/lib/routeUtils';

const HIT_RADIUS = 24;
const SNAP_THRESHOLD = 0.025;

function distToSegment(p, a, b) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return Math.hypot(p.x - a.x, p.y - a.y);
  let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
}

function SelectionArrows({ cx, cy, color = '#FF6600' }) {
  const offset = 22;
  const r = 9;
  const a = 5;
  return (
    <g style={{ pointerEvents: 'none' }}>
      <circle cx={cx} cy={cy - offset} r={r} fill="white" stroke={color} strokeWidth={1.5} opacity={0.95} />
      <path d={`M${cx} ${cy - offset - a} L${cx - a} ${cy - offset + 2} M${cx} ${cy - offset - a} L${cx + a} ${cy - offset + 2}`} stroke={color} strokeWidth={2} strokeLinecap="round" fill="none" />
      <circle cx={cx + offset} cy={cy} r={r} fill="white" stroke={color} strokeWidth={1.5} opacity={0.95} />
      <path d={`M${cx + offset + a} ${cy} L${cx + offset - 2} ${cy - a} M${cx + offset + a} ${cy} L${cx + offset - 2} ${cy + a}`} stroke={color} strokeWidth={2} strokeLinecap="round" fill="none" />
      <circle cx={cx} cy={cy + offset} r={r} fill="white" stroke={color} strokeWidth={1.5} opacity={0.95} />
      <path d={`M${cx} ${cy + offset + a} L${cx - a} ${cy + offset - 2} M${cx} ${cy + offset + a} L${cx + a} ${cy + offset - 2}`} stroke={color} strokeWidth={2} strokeLinecap="round" fill="none" />
      <circle cx={cx - offset} cy={cy} r={r} fill="white" stroke={color} strokeWidth={1.5} opacity={0.95} />
      <path d={`M${cx - offset - a} ${cy} L${cx - offset + 2} ${cy - a} M${cx - offset - a} ${cy} L${cx - offset + 2} ${cy + a}`} stroke={color} strokeWidth={2} strokeLinecap="round" fill="none" />
    </g>
  );
}

export default function RouteImageCanvas({
  routeData, activeTool, selectedPoint, selectedMarker, routeActive,
  pendingMarkerType, onUpdate, onSelectPoint, onSelectMarker, onRouteActive, onActivateTool, onDeactivateTool, onImageLoad,
  onCloseRoute
}) {
  const parentRef = useRef();
  const imageContainerRef = useRef();
  const svgRef = useRef();
  const [dims, setDims] = useState({ width: 0, height: 0 });
  const [imgSize, setImgSize] = useState({ width: 0, height: 0 });
  const [parentDims, setParentDims] = useState({ width: 0, height: 0 });
  const dragRef = useRef(null);

  useEffect(() => {
    if (!routeData.imageUrl) return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setImgSize({ width: img.naturalWidth, height: img.naturalHeight });
      if (onImageLoad) onImageLoad(img);
    };
    img.src = routeData.imageUrl;
  }, [routeData.imageUrl]);

  useEffect(() => {
    if (!parentRef.current) return;
    const el = parentRef.current;
    const update = () => {
      const rect = el.getBoundingClientRect();
      setParentDims({ width: rect.width, height: rect.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const fit = useMemo(() => {
    if (!imgSize.width || !parentDims.width) return null;
    const imgRatio = imgSize.width / imgSize.height;
    const parentRatio = parentDims.width / parentDims.height;
    if (imgRatio > parentRatio) {
      return { width: parentDims.width, height: parentDims.width / imgRatio };
    }
    return { height: parentDims.height, width: parentDims.height * imgRatio };
  }, [imgSize, parentDims]);

  useEffect(() => {
    if (!imageContainerRef.current || !fit) return;
    const el = imageContainerRef.current;
    const updateDims = () => {
      const rect = el.getBoundingClientRect();
      setDims({ width: rect.width, height: rect.height });
    };
    updateDims();
    const ro = new ResizeObserver(updateDims);
    ro.observe(el);
    return () => ro.disconnect();
  }, [fit]);

  const toPx = (p) => ({ x: p.x * dims.width, y: p.y * dims.height });

  const getPointerPos = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const hitTestPoint = (px) => {
    for (let i = routeData.routePoints.length - 1; i >= 0; i--) {
      const p = toPx(routeData.routePoints[i]);
      if (Math.hypot(px.x - p.x, px.y - p.y) < HIT_RADIUS) return i;
    }
    return -1;
  };

  const hitTestMarker = (px) => {
    for (let i = routeData.markers.length - 1; i >= 0; i--) {
      const p = toPx(routeData.markers[i].position);
      if (Math.hypot(px.x - p.x, px.y - p.y) < HIT_RADIUS) return i;
    }
    return -1;
  };

  const hitTestRouteLine = (px) => {
    if (routeData.routePoints.length < 2) return -1;
    for (let i = 0; i < routeData.routePoints.length - 1; i++) {
      const a = toPx(routeData.routePoints[i]);
      const b = toPx(routeData.routePoints[i + 1]);
      if (distToSegment(px, a, b) < HIT_RADIUS) return i;
    }
    return -1;
  };

  const handlePointerDown = (e) => {
    e.preventDefault();
    const px = getPointerPos(e);

    const markerIdx = hitTestMarker(px);
    if (markerIdx >= 0) {
      if (activeTool === null) onActivateTool('markers');
      if (selectedMarker === markerIdx) onSelectMarker(null);
      else onSelectMarker(markerIdx);
      dragRef.current = { type: 'marker', index: markerIdx, moved: false };
      svgRef.current.setPointerCapture(e.pointerId);
      return;
    }

    if (activeTool === null) {
      const segmentIdx = hitTestRouteLine(px);
      if (segmentIdx >= 0) {
        onActivateTool('route');
      }
      return;
    }

    if (activeTool === 'route') {
      if (routeActive) {
        const pointIdx = hitTestPoint(px);
        if (pointIdx >= 0) {
          // Pressing the other end point closes the loop instead of selecting it
          const lastIdx = routeData.routePoints.length - 1;
          const closes = !routeData.closed && routeData.routePoints.length >= 3 &&
            ((pointIdx === 0 && selectedPoint === lastIdx) || (pointIdx === lastIdx && selectedPoint === 0));
          if (closes) {
            onUpdate({ ...routeData, closed: true });
            onSelectPoint(null);
            onSelectMarker(null);
            if (onCloseRoute) onCloseRoute();
            return;
          }
          if (selectedPoint === pointIdx) onSelectPoint(null);
          else onSelectPoint(pointIdx);
          onRouteActive(true);
          dragRef.current = { type: 'point', index: pointIdx, moved: false };
          svgRef.current.setPointerCapture(e.pointerId);
          return;
        }

        const segmentIdx = hitTestRouteLine(px);
        if (segmentIdx >= 0) {
          const norm = { x: px.x / dims.width, y: px.y / dims.height };
          const newPoints = [...routeData.routePoints];
          newPoints.splice(segmentIdx + 1, 0, norm);
          onUpdate({ ...routeData, routePoints: newPoints });
          return;
        }

        const norm = { x: px.x / dims.width, y: px.y / dims.height };
        onUpdate({ ...routeData, routePoints: [...routeData.routePoints, norm], closed: false });
        onRouteActive(true);
        // The new point becomes the active one, so drawing continues from it
        onSelectPoint(routeData.routePoints.length);
        onSelectMarker(null);
      } else {
        if (routeData.routePoints.length === 0) {
          const norm = { x: px.x / dims.width, y: px.y / dims.height };
          onUpdate({ ...routeData, routePoints: [...routeData.routePoints, norm] });
          onRouteActive(true);
          onSelectPoint(null);
          onSelectMarker(null);
        } else {
          const segmentIdx = hitTestRouteLine(px);
          if (segmentIdx >= 0) {
            onRouteActive(true);
          } else {
            onDeactivateTool();
          }
        }
      }
    } else if (activeTool === 'markers' && pendingMarkerType) {
      const existing = routeData.markers.find(m =>
        m.type === pendingMarkerType.type &&
        (m.type !== 'split' || m.splitIndex === pendingMarkerType.splitIndex)
      );
      if (!existing) {
        const norm = { x: px.x / dims.width, y: px.y / dims.height };
        const snap = snapToRoute(norm, routeData.routePoints, SNAP_THRESHOLD);
        const newMarker = {
          type: pendingMarkerType.type,
          splitIndex: pendingMarkerType.splitIndex,
          position: snap ? snap.point : norm,
        };
        onUpdate({ ...routeData, markers: [...routeData.markers, newMarker] });
      }
      onSelectMarker(null);
    } else if (activeTool === 'markers') {
      onDeactivateTool();
    }
  };

  const handleDoubleClick = (e) => {
    e.preventDefault();
    const px = getPointerPos(e);
    const pointIdx = hitTestPoint(px);
    if (pointIdx >= 0 && pointIdx === routeData.routePoints.length - 1) {
      onRouteActive(false);
      onSelectPoint(null);
    }
  };

  const handlePointerMove = (e) => {
    if (!dragRef.current) return;
    const px = getPointerPos(e);
    const norm = { x: px.x / dims.width, y: px.y / dims.height };
    dragRef.current.moved = true;

    if (dragRef.current.type === 'point') {
      const newPoints = [...routeData.routePoints];
      newPoints[dragRef.current.index] = norm;
      onUpdate({ ...routeData, routePoints: newPoints }, false);
    } else if (dragRef.current.type === 'marker') {
      let pos = norm;
      const snap = snapToRoute(norm, routeData.routePoints, SNAP_THRESHOLD);
      if (snap) pos = snap.point;
      const newMarkers = [...routeData.markers];
      newMarkers[dragRef.current.index] = { ...newMarkers[dragRef.current.index], position: pos };
      onUpdate({ ...routeData, markers: newMarkers }, false);
    }
  };

  const handlePointerUp = (e) => {
    if (dragRef.current && dragRef.current.moved) {
      onUpdate(routeData, true);
    }
    dragRef.current = null;
    try { svgRef.current.releasePointerCapture(e.pointerId); } catch {}
  };

  const deletePoint = (idx, e) => {
    e.stopPropagation();
    const newPoints = routeData.routePoints.filter((_, i) => i !== idx);
    onUpdate({ ...routeData, routePoints: newPoints });
    onSelectPoint(null);
  };

  const deleteMarker = (idx, e) => {
    e.stopPropagation();
    const newMarkers = routeData.markers.filter((_, i) => i !== idx);
    onUpdate({ ...routeData, markers: newMarkers });
    onSelectMarker(null);
  };

  if (!routeData.imageUrl) return null;

  return (
    <div ref={parentRef} className="absolute inset-0 flex items-center justify-center overflow-hidden bg-black/80">
      <div
        ref={imageContainerRef}
        className="relative"
        style={fit ? { width: `${fit.width}px`, height: `${fit.height}px` } : undefined}
      >
        <img src={routeData.imageUrl} className="absolute inset-0 w-full h-full" alt="" draggable={false} />
        <svg
          ref={svgRef}
          className="absolute inset-0 w-full h-full"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onDoubleClick={handleDoubleClick}
          style={{ touchAction: 'none' }}
        >
          {routeData.routePoints.length > 1 && (
            <path
              d={smoothPathSVG(closedPathPoints(routeData.routePoints, routeData.closed).map(p => toPx(p)))}
              fill="none"
              stroke="#FF6600"
              strokeWidth={4}
              strokeLinejoin="round"
              strokeLinecap="round"
              opacity={routeActive ? 1 : 0.6}
            />
          )}
          {activeTool === 'route' && routeActive && routeData.routePoints.map((p, i) => {
            const px = toPx(p);
            const isSel = selectedPoint === i;
            const isFirst = i === 0;
            return (
              <g key={i}>
                <circle cx={px.x} cy={px.y} r={isSel ? 11 : 8} fill={isSel ? 'white' : '#FF6600'} stroke={isFirst ? '#22c55e' : '#FF6600'} strokeWidth={isFirst ? 4 : 3} />
                {isSel && <SelectionArrows cx={px.x} cy={px.y} />}
                {isSel && (
                  <g onClick={(e) => deletePoint(i, e)} onPointerDown={(e) => e.stopPropagation()} style={{ cursor: 'pointer' }}>
                    <circle cx={px.x + 28} cy={px.y - 28} r={11} fill="#ef4444" stroke="white" strokeWidth={2} />
                    <text x={px.x + 28} y={px.y - 24} textAnchor="middle" fontSize="16" fill="white" fontWeight="bold">×</text>
                  </g>
                )}
              </g>
            );
          })}
          {routeData.markers.map((m, i) => {
            const px = toPx(m.position);
            const color = getMarkerColor(m.type);
            const label = getMarkerShortLabel(m.type, m.splitIndex);
            const isSel = selectedMarker === i;
            return (
              <g key={i}>
                <circle cx={px.x} cy={px.y} r={isSel ? 16 : 14} fill={color} stroke="white" strokeWidth={3} />
                <text x={px.x} y={px.y + 5} textAnchor="middle" fontSize="12" fill="white" fontWeight="bold">{label}</text>
                {isSel && <SelectionArrows cx={px.x} cy={px.y} color={color} />}
                {isSel && (
                  <g onClick={(e) => deleteMarker(i, e)} onPointerDown={(e) => e.stopPropagation()} style={{ cursor: 'pointer' }}>
                    <circle cx={px.x + 30} cy={px.y - 30} r={11} fill="#ef4444" stroke="white" strokeWidth={2} />
                    <text x={px.x + 30} y={px.y - 26} textAnchor="middle" fontSize="16" fill="white" fontWeight="bold">×</text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}