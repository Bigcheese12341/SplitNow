import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, useMap, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { getMarkerColor, getMarkerShortLabel, snapToRoute, smoothLatLngPoints, closedPathPoints } from '@/lib/routeUtils';
import { Satellite, Map as MapIcon } from 'lucide-react';

const STREET_URL = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
const SATELLITE_URL = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
const DEFAULT_CENTER = [60.1699, 24.9384];
const DEFAULT_ZOOM = 14;
const SNAP_THRESHOLD_LATLNG = 0.002;

function buildArrowHTML(color) {
  const offset = 14;
  const r = 5;
  const arrowSVG = (rotation) => `<svg width="6" height="6" viewBox="0 0 10 10" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="transform:rotate(${rotation}deg);"><path d="M5 8 L5 2 M2 5 L5 2 L8 5"/></svg>`;
  const arrow = (x, y, rotation) => `<div style="position:absolute;width:${r*2}px;height:${r*2}px;border-radius:50%;background:white;border:1px solid ${color};box-shadow:0 1px 2px rgba(0,0,0,0.2);left:${x - r}px;top:${y - r}px;display:flex;align-items:center;justify-content:center;">${arrowSVG(rotation)}</div>`;
  return { offset, arrow };
}

// The visible dot stays small but the touch area around it is 40px,
// which makes the end points easy to hit on a phone.
function createPointIcon(isSelected, isFirst) {
  const ring = isFirst ? '#22c55e' : 'white';
  if (!isSelected) {
    const hit = 40;
    const dot = 16;
    return L.divIcon({
      className: '',
      html: `<div style="width:${hit}px;height:${hit}px;display:flex;align-items:center;justify-content:center;"><div style="width:${dot}px;height:${dot}px;border-radius:50%;background:#FF6600;border:3px solid ${ring};box-shadow:0 1px 4px rgba(0,0,0,0.4);"></div></div>`,
      iconSize: [hit, hit],
      iconAnchor: [hit / 2, hit / 2],
    });
  }
  const dotSize = 18;
  const color = '#FF6600';
  const { offset, arrow } = buildArrowHTML(color);
  const totalSize = (offset + 11) * 2;
  const c = totalSize / 2;
  return L.divIcon({
    className: '',
    html: `<div style="position:relative;width:${totalSize}px;height:${totalSize}px;">
      <div style="position:absolute;top:${c - dotSize/2}px;left:${c - dotSize/2}px;width:${dotSize}px;height:${dotSize}px;border-radius:50%;background:white;border:3px solid ${ring};box-shadow:0 1px 4px rgba(0,0,0,0.4);"></div>
      ${arrow(c, c - offset, 0)}
      ${arrow(c + offset, c, 90)}
      ${arrow(c, c + offset, 180)}
      ${arrow(c - offset, c, 270)}
    </div>`,
    iconSize: [totalSize, totalSize],
    iconAnchor: [c, c],
  });
}

function createMarkerIcon(type, splitIndex, isSelected) {
  const color = getMarkerColor(type);
  const label = getMarkerShortLabel(type, splitIndex);
  if (!isSelected) {
    const size = 30;
    return L.divIcon({
      className: '',
      html: `<div style="display:flex;align-items:center;justify-content:center;width:${size}px;height:${size}px;border-radius:50%;background:white;box-shadow:0 2px 8px rgba(0,0,0,0.35);"><div style="display:flex;align-items:center;justify-content:center;width:${size-8}px;height:${size-8}px;border-radius:50%;background:${color};color:white;font-size:11px;font-weight:bold;font-family:Inter,sans-serif;">${label}</div></div>`,
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2],
    });
  }
  const dotSize = 28;
  const { offset, arrow } = buildArrowHTML(color);
  const totalSize = (offset + 9) * 2;
  const c = totalSize / 2;
  return L.divIcon({
    className: '',
    html: `<div style="position:relative;width:${totalSize}px;height:${totalSize}px;">
      <div style="position:absolute;top:${c - dotSize/2}px;left:${c - dotSize/2}px;display:flex;align-items:center;justify-content:center;width:${dotSize}px;height:${dotSize}px;border-radius:50%;background:white;box-shadow:0 2px 8px rgba(0,0,0,0.35);"><div style="display:flex;align-items:center;justify-content:center;width:${dotSize-8}px;height:${dotSize-8}px;border-radius:50%;background:${color};color:white;font-size:11px;font-weight:bold;font-family:Inter,sans-serif;">${label}</div></div>
      ${arrow(c, c - offset, 0)}
      ${arrow(c + offset, c, 90)}
      ${arrow(c, c + offset, 180)}
      ${arrow(c - offset, c, 270)}
    </div>`,
    iconSize: [totalSize, totalSize],
    iconAnchor: [c, c],
  });
}

function MapClickHandler({ activeTool, routeActive, routePoints, onAddPoint, pendingMarkerType, onAddMarker, onSelectPoint, onSelectMarker, onDeactivateTool }) {
  useMapEvents({
    click: (e) => {
      if (activeTool === 'route') {
        onSelectMarker(null);
        if (routeActive || routePoints.length === 0) {
          onAddPoint({ lat: e.latlng.lat, lng: e.latlng.lng });
        } else {
          onDeactivateTool();
        }
      } else if (activeTool === 'markers') {
        if (pendingMarkerType) {
          const pos = { lat: e.latlng.lat, lng: e.latlng.lng };
          const snap = snapToRoute(pos, routePoints, SNAP_THRESHOLD_LATLNG);
          onAddMarker(pendingMarkerType, snap ? snap.point : pos);
        } else {
          onDeactivateTool();
        }
      } else {
        onSelectPoint(null);
        onSelectMarker(null);
      }
    }
  });
  return null;
}

function MapController({ target }) {
  const map = useMap();
  useEffect(() => {
    if (!target) return;
    // A searched place comes with its own extent, so zoom straight to it
    if (target.bbox) {
      const bounds = L.latLngBounds([target.bbox[0], target.bbox[2]], [target.bbox[1], target.bbox[3]]);
      if (bounds.isValid()) {
        map.flyToBounds(bounds, { padding: [30, 30], maxZoom: 16, duration: 0.6 });
        return;
      }
    }
    if (target.center) map.flyTo(target.center, 16, { duration: 0.6 });
  }, [target, map]);
  return null;
}

function FitBoundsOnOpen({ routePoints, markers }) {
  const map = useMap();
  const didFit = useRef(false);
  useEffect(() => {
    if (didFit.current) return;
    const allPoints = [
      ...(routePoints || []).map(p => [p.lat, p.lng]),
      ...(markers || []).map(m => [m.position.lat, m.position.lng])
    ];
    if (allPoints.length > 0) {
      didFit.current = true;
      const bounds = L.latLngBounds(allPoints);
      const timer = setTimeout(() => {
        map.invalidateSize();
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 17, animate: false });
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [routePoints, markers, map]);
  return null;
}

function LayerToggle({ layer, onChange }) {
  const containerRef = useRef();

  useEffect(() => {
    if (containerRef.current) {
      L.DomEvent.disableClickPropagation(containerRef.current);
      L.DomEvent.disableScrollPropagation(containerRef.current);
    }
  }, []);

  return (
    <div ref={containerRef} className="absolute top-2 right-2 z-[500] flex flex-col gap-1">
      <button
        type="button"
        onClick={() => onChange('satellite')}
        className={`px-3 py-1.5 rounded-lg text-xs font-bold shadow-lg flex items-center justify-center ${layer === 'satellite' ? 'bg-primary text-primary-foreground' : 'bg-card text-foreground'}`}
      >
        <Satellite className="w-4 h-4" />
      </button>
      <button
        type="button"
        onClick={() => onChange('street')}
        className={`px-3 py-1.5 rounded-lg text-xs font-bold shadow-lg flex items-center justify-center ${layer === 'street' ? 'bg-primary text-primary-foreground' : 'bg-card text-foreground'}`}
      >
        <MapIcon className="w-4 h-4" />
      </button>
    </div>
  );
}

export default function RouteMapCanvas({
  routeData, activeTool, selectedPoint, selectedMarker, routeActive,
  pendingMarkerType, onUpdate, onSelectPoint, onSelectMarker, onRouteActive, onActivateTool, onDeactivateTool,
  mapSearchTarget, onCloseRoute
}) {
  const center = routeData.mapCenter || DEFAULT_CENTER;
  const zoom = routeData.mapZoom || DEFAULT_ZOOM;
  const layer = routeData.mapLayer || 'street';

  const handleAddPoint = (pos) => {
    const newPoints = [...routeData.routePoints, pos];
    onUpdate({ ...routeData, routePoints: newPoints, closed: false });
    onRouteActive(true);
    // The new point stays active so the route can be continued or closed from it
    onSelectPoint(newPoints.length - 1);
  };

  const handleAddMarker = (markerType, pos) => {
    const existing = routeData.markers.find(m =>
      m.type === markerType.type &&
      (m.type !== 'split' || m.splitIndex === markerType.splitIndex)
    );
    if (!existing) {
      onUpdate({ ...routeData, markers: [...routeData.markers, { ...markerType, position: pos }] });
    }
    onSelectMarker(null);
  };

  const handleRouteClick = (e) => {
    L.DomEvent.stopPropagation(e);
    if (activeTool === null) {
      onActivateTool('route');
      return;
    }
    if (activeTool !== 'route') return;
    if (!routeActive) { onRouteActive(true); return; }
    const pos = { lat: e.latlng.lat, lng: e.latlng.lng };
    const snap = snapToRoute(pos, routeData.routePoints, SNAP_THRESHOLD_LATLNG);
    const insertPos = snap ? snap.point : pos;
    const newPoints = [...routeData.routePoints];
    const seg = snap ? snap.segment : 0;
    newPoints.splice(seg + 1, 0, insertPos);
    onUpdate({ ...routeData, routePoints: newPoints });
  };

  const handlePointClick = (i, e) => {
    L.DomEvent.stopPropagation(e);
    const lastIdx = routeData.routePoints.length - 1;
    // Pressing the opposite end point closes the loop; a middle point never does
    const closes = activeTool === 'route' && routeActive && !routeData.closed && routeData.routePoints.length >= 3 &&
      ((i === 0 && selectedPoint === lastIdx) || (i === lastIdx && selectedPoint === 0));
    if (closes) {
      onUpdate({ ...routeData, closed: true });
      onSelectPoint(null);
      onRouteActive(true);
      if (onCloseRoute) onCloseRoute();
      return;
    }
    if (selectedPoint === i) onSelectPoint(null);
    else onSelectPoint(i);
    onRouteActive(true);
  };

  const handlePointDragEnd = (idx, e) => {
    const latlng = e.target.getLatLng();
    const newPoints = [...routeData.routePoints];
    newPoints[idx] = { lat: latlng.lat, lng: latlng.lng };
    onUpdate({ ...routeData, routePoints: newPoints });
  };

  const handleMarkerDragEnd = (idx, e) => {
    const latlng = e.target.getLatLng();
    let pos = { lat: latlng.lat, lng: latlng.lng };
    const snap = snapToRoute(pos, routeData.routePoints, SNAP_THRESHOLD_LATLNG);
    if (snap) pos = snap.point;
    const newMarkers = [...routeData.markers];
    newMarkers[idx] = { ...newMarkers[idx], position: pos };
    onUpdate({ ...routeData, markers: newMarkers });
  };

  const handleLayerChange = (newLayer) => {
    onUpdate({ ...routeData, mapLayer: newLayer });
  };

  return (
    <div className="absolute inset-0">
      <MapContainer
        center={center}
        zoom={zoom}
        className="w-full h-full"
        zoomControl={true}
        doubleClickZoom={activeTool !== 'route'}
      >
        <TileLayer
          url={layer === 'satellite' ? SATELLITE_URL : STREET_URL}
          attribution={layer === 'satellite' ? 'Esri' : 'OpenStreetMap'}
          maxZoom={20}
        />
        <FitBoundsOnOpen routePoints={routeData.routePoints} markers={routeData.markers} />
        <MapClickHandler
          activeTool={activeTool}
          routeActive={routeActive}
          routePoints={routeData.routePoints}
          onAddPoint={handleAddPoint}
          pendingMarkerType={pendingMarkerType}
          onAddMarker={handleAddMarker}
          onSelectPoint={onSelectPoint}
          onSelectMarker={onSelectMarker}
          onDeactivateTool={onDeactivateTool}
        />
        <MapController target={mapSearchTarget} />
        <LayerToggle layer={layer} onChange={handleLayerChange} />

        {routeData.routePoints.length > 1 && (
          <Polyline
            positions={smoothLatLngPoints(closedPathPoints(routeData.routePoints, routeData.closed))}
            pathOptions={{ color: '#FF6600', weight: 4, opacity: routeActive ? 1 : 0.6 }}
            eventHandlers={{ click: handleRouteClick }}
          />
        )}

        {activeTool === 'route' && routeActive && routeData.routePoints.map((p, i) => (
          <Marker
            key={i}
            position={[p.lat, p.lng]}
            icon={createPointIcon(selectedPoint === i, i === 0)}
            draggable
            eventHandlers={{
              click: (e) => handlePointClick(i, e),
              dblclick: (e) => {
                L.DomEvent.stopPropagation(e);
                if (i === routeData.routePoints.length - 1) {
                  onRouteActive(false);
                  onSelectPoint(null);
                }
              },
              dragend: (e) => handlePointDragEnd(i, e),
            }}
          />
        ))}

        {routeData.markers.map((m, i) => (
          <Marker
            key={i}
            position={[m.position.lat, m.position.lng]}
            icon={createMarkerIcon(m.type, m.splitIndex, selectedMarker === i)}
            draggable
            eventHandlers={{
              click: (e) => {
                L.DomEvent.stopPropagation(e);
                if (activeTool === null) onActivateTool('markers');
                if (selectedMarker === i) onSelectMarker(null);
                else onSelectMarker(i);
              },
              dragend: (e) => handleMarkerDragEnd(i, e),
            }}
          />
        ))}
      </MapContainer>
    </div>
  );
}