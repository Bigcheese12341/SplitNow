import React, { useState, useEffect, useRef, useMemo } from 'react';
import { X } from 'lucide-react';
import { MapContainer, TileLayer, Polyline, Marker, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { getMarkerColor, getMarkerShortLabel, parseRouteData, smoothPathSVG, smoothLatLngPoints, closedPathPoints } from '@/lib/routeUtils';

function createViewMarkerIcon(type, splitIndex) {
  const color = getMarkerColor(type);
  const label = getMarkerShortLabel(type, splitIndex);
  return L.divIcon({
    className: '',
    html: `<div style="display:flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;background:${color};border:3px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.4);color:white;font-size:12px;font-weight:bold;font-family:Inter,sans-serif;">${label}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
}

function FitBounds({ routePoints, markers }) {
  const map = useMap();
  useEffect(() => {
    const allPoints = [
      ...(routePoints || []).map(p => [p.lat, p.lng]),
      ...(markers || []).map(m => [m.position.lat, m.position.lng])
    ];
    if (allPoints.length > 0) {
      const bounds = L.latLngBounds(allPoints);
      // Delay to ensure container has proper dimensions inside portal overlay
      const timer = setTimeout(() => {
        map.invalidateSize();
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 17, animate: false });
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [routePoints, markers, map]);
  return null;
}

function ImageView({ routeData }) {
  const parentRef = useRef();
  const containerRef = useRef();
  const [dims, setDims] = useState({ width: 0, height: 0 });
  const [imgSize, setImgSize] = useState({ width: 0, height: 0 });
  const [parentDims, setParentDims] = useState({ width: 0, height: 0 });

  useEffect(() => {
    if (!routeData.imageUrl) return;
    const img = new Image();
    img.onload = () => setImgSize({ width: img.naturalWidth, height: img.naturalHeight });
    img.src = routeData.imageUrl;
  }, [routeData.imageUrl]);

  useEffect(() => {
    if (!parentRef.current) return;
    const el = parentRef.current;
    const update = () => {
      const rect = el.getBoundingClientRect();
      setParentDims({ width: rect.width, height: rect.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const fit = useMemo(() => {
    if (!imgSize.width || !parentDims.width) return null;
    const imgRatio = imgSize.width / imgSize.height;
    const parentRatio = parentDims.width / parentDims.height;
    if (imgRatio > parentRatio) {
      return { width: parentDims.width, height: parentDims.width / imgRatio };
    }
    return { height: parentDims.height, width: parentDims.height * imgRatio };
  }, [imgSize, parentDims]);

  useEffect(() => {
    if (!containerRef.current || !fit) return;
    const el = containerRef.current;
    const update = () => {
      const rect = el.getBoundingClientRect();
      setDims({ width: rect.width, height: rect.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [fit]);

  const toPx = (p) => ({ x: p.x * dims.width, y: p.y * dims.height });

  return (
    <div ref={parentRef} className="absolute inset-0 flex items-center justify-center bg-black/80 overflow-hidden">
      <div
        ref={containerRef}
        className="relative"
        style={fit ? { width: `${fit.width}px`, height: `${fit.height}px` } : undefined}
      >
        <img src={routeData.imageUrl} className="absolute inset-0 w-full h-full" alt="" draggable={false} />
        {dims.width > 0 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {routeData.routePoints.length > 1 && (
              <path
                d={smoothPathSVG(closedPathPoints(routeData.routePoints, routeData.closed).map(p => toPx(p)))}
                fill="none"
                stroke="#FF6600"
                strokeWidth={5}
                strokeLinejoin="round"
                strokeLinecap="round"
                opacity={1}
              />
            )}
            {routeData.markers.map((m, i) => {
              const px = toPx(m.position);
              const color = getMarkerColor(m.type);
              const label = getMarkerShortLabel(m.type, m.splitIndex);
              return (
                <g key={i}>
                  <circle cx={px.x} cy={px.y} r={14} fill={color} stroke="white" strokeWidth={3} />
                  <text x={px.x} y={px.y + 5} textAnchor="middle" fontSize="12" fill="white" fontWeight="bold">{label}</text>
                </g>
              );
            })}
          </svg>
        )}
      </div>
    </div>
  );
}

export default function RouteView({ routeDataStr, onClose, t }) {
  const routeData = parseRouteData(routeDataStr);

  if (!routeData) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-background flex flex-col">
      <div className="flex items-center justify-between px-2 py-2 bg-card border-b border-border">
        <h2 className="font-black text-sm">{t('route.viewRoute')}</h2>
        <button type="button" onClick={onClose} className="p-1.5 rounded-lg text-foreground hover:bg-muted">
          <X className="w-5 h-5" />
        </button>
      </div>
      <div className="flex-1 relative">
        {routeData.mode === 'image' && routeData.imageUrl && (
          <ImageView routeData={routeData} />
        )}
        {routeData.mode === 'map' && (
          <MapContainer
            center={routeData.mapCenter || [60.1699, 24.9384]}
            zoom={routeData.mapZoom || 14}
            className="w-full h-full"
            zoomControl={true}
          >
            <FitBounds routePoints={routeData.routePoints} markers={routeData.markers} />
            <TileLayer
              url={routeData.mapLayer === 'street'
                ? 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
                : 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
              }
              attribution={routeData.mapLayer === 'satellite' ? 'Esri' : 'OpenStreetMap'}
              maxZoom={20}
            />
            {routeData.routePoints.length > 1 && (
              <Polyline
                positions={smoothLatLngPoints(closedPathPoints(routeData.routePoints, routeData.closed))}
                pathOptions={{ color: '#FF6600', weight: 5, opacity: 1 }}
              />
            )}
            {routeData.markers.map((m, i) => (
              <Marker
                key={i}
                position={[m.position.lat, m.position.lng]}
                icon={createViewMarkerIcon(m.type, m.splitIndex)}
              />
            ))}
          </MapContainer>
        )}
      </div>
    </div>
  );
}