import React, { useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Route as RouteIcon, Loader2, ImagePlus, Map as MapIcon } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { loadImageElement } from '@/lib/routeImage';
import { defaultRouteData, parseRouteData, routeKind, routeHasContent } from '@/lib/routeUtils';
import { Switch } from '@/components/ui/switch';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import RouteEditor from './RouteEditor';
import RouteImageEditor from './RouteImageEditor';
import RouteView from './RouteView';

export default function RouteSection({ routeData, routePreviewUrl, splitCount, addFinish, canEdit, onSave, onDelete, t }) {
  const [editorState, setEditorState] = useState(null);
  const [imageEditor, setImageEditor] = useState(null);
  const [showView, setShowView] = useState(false);
  const [showDisableConfirm, setShowDisableConfirm] = useState(false);
  const [pendingSwitch, setPendingSwitch] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [imageError, setImageError] = useState(null);
  const [loadingImage, setLoadingImage] = useState(false);

  const fileInputRef = useRef(null);

  const parsed = parseRouteData(routeData);
  const enabled = !!routeData;
  const kind = routeKind(parsed);
  const hasContent = routeHasContent(parsed);
  const thumbnail = routePreviewUrl || (kind === 'uploaded_image' ? parsed.imageUrl : null);

  const openEditor = (initialData, commitOnly = false) => {
    setImageError(null);
    setEditorState({ initialData, commitOnly });
  };

  // With a route already in place this always edits that one route
  const handleStartDraw = () => {
    openEditor(hasContent ? parsed : null);
  };

  const handleStartImage = () => {
    if (hasContent) {
      setPendingSwitch('uploaded_image');
      return;
    }
    fileInputRef.current?.click();
  };

  const handleConfirmSwitch = () => {
    const target = pendingSwitch;
    setPendingSwitch(null);
    if (target === 'drawn') openEditor(null, true);
    else fileInputRef.current?.click();
  };

  const handleRouteImagePick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const supported = /^image\/(jpeg|jpg|png|webp)$/i.test(file.type) || /\.(jpe?g|png|webp)$/i.test(file.name);
    if (!supported) {
      setImageError(t('route.invalidImage'));
      return;
    }
    setImageError(null);
    setLoadingImage(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      const img = await loadImageElement(file_url);
      setLoadingImage(false);
      setImageEditor({
        imageUrl: file_url,
        imageSize: { width: img.naturalWidth, height: img.naturalHeight },
      });
    } catch (err) {
      setLoadingImage(false);
      setImageError(t('route.invalidImage'));
    }
  };

  // The editors only close once the route has really been saved
  const handleMapDone = async (data, previewUrl) => {
    await onSave(JSON.stringify(data), previewUrl);
    setEditorState(null);
  };

  const handleImageDone = async (data, previewUrl) => {
    await onSave(JSON.stringify(data), previewUrl);
    setImageEditor(null);
  };

  const handleEditorAutoSave = async (data) => {
    await onSave(JSON.stringify(data), null);
  };

  const handleToggle = (checked) => {
    if (!checked && enabled) {
      setShowDisableConfirm(true);
    } else if (checked && !enabled) {
      onSave(JSON.stringify(defaultRouteData()), null);
    }
  };

  const handleConfirmDelete = async () => {
    setShowDisableConfirm(false);
    setDeleting(true);
    await onDelete();
    setDeleting(false);
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-4 space-y-3">
      <div className="flex items-center gap-2 text-sm font-bold text-foreground">
        <span className="text-primary"><RouteIcon className="w-4 h-4" /></span>
        {t('route.title')}
      </div>

      <div className="flex items-center justify-between">
        <div>
          <div className="font-bold text-sm">{t('route.addRoute')}</div>
          <div className="text-xs text-muted-foreground">{t('route.addRouteSub')}</div>
        </div>
        <Switch checked={enabled} onCheckedChange={handleToggle} disabled={!canEdit || deleting} />
      </div>

      {enabled && hasContent && (
        <button
          type="button"
          onClick={() => (canEdit ? openEditor(parsed) : setShowView(true))}
          className="w-full rounded-xl overflow-hidden border border-border active:scale-[0.99] transition-all"
        >
          {thumbnail ? (
            <img
              src={thumbnail}
              alt={t('route.title')}
              className={`w-full h-40 ${kind === 'uploaded_image' ? 'object-contain bg-black' : 'object-cover'}`}
            />
          ) : (
            <div className="w-full h-40 bg-muted flex items-center justify-center">
              <RouteIcon className="w-10 h-10 text-muted-foreground" />
            </div>
          )}
        </button>
      )}

      {enabled && !hasContent && (
        <div className="space-y-2">
          <button
            type="button"
            onClick={handleStartDraw}
            disabled={!canEdit || loadingImage || deleting}
            className="w-full h-12 rounded-xl bg-primary/10 text-primary font-bold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-all disabled:opacity-50"
          >
            <MapIcon className="w-4 h-4" />
            {t('route.createRoute')}
          </button>
          <button
            type="button"
            onClick={handleStartImage}
            disabled={!canEdit || loadingImage || deleting}
            className="w-full h-12 rounded-xl bg-muted text-foreground font-bold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-all disabled:opacity-50"
          >
            {loadingImage ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImagePlus className="w-4 h-4" />}
            {t('route.downloadRoute')}
          </button>
          {imageError && (
            <p className="text-xs text-destructive font-semibold text-center">{imageError}</p>
          )}
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp"
        className="hidden"
        onChange={handleRouteImagePick}
      />

      {deleting && (
        <div className="flex items-center justify-center py-2">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </div>
      )}

      {editorState && createPortal(
        <RouteEditor
          initialRouteData={editorState.initialData}
          splitCount={splitCount}
          addFinish={addFinish}
          onDone={handleMapDone}
          onAutoSave={editorState.commitOnly ? undefined : handleEditorAutoSave}
          onClose={() => setEditorState(null)}
          t={t}
        />,
        document.body
      )}

      {imageEditor && createPortal(
        <RouteImageEditor
          imageUrl={imageEditor.imageUrl}
          imageSize={imageEditor.imageSize}
          splitCount={splitCount}
          onDone={handleImageDone}
          onCancel={() => setImageEditor(null)}
          t={t}
        />,
        document.body
      )}

      {showView && createPortal(
        <RouteView routeDataStr={routeData} onClose={() => setShowView(false)} t={t} />,
        document.body
      )}

      <AlertDialog open={!!pendingSwitch} onOpenChange={(open) => { if (!open) setPendingSwitch(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('route.replaceConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>{t('route.replaceDesc')}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmSwitch}>{t('route.replaceAction')}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showDisableConfirm} onOpenChange={setShowDisableConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('route.disableRouteConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>{t('route.disableRouteDesc')}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete} className="bg-destructive text-destructive-foreground">
              {t('common.delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}