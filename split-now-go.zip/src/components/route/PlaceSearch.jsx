import React, { useEffect, useRef, useState } from 'react';
import { Loader2, Search } from 'lucide-react';
import { searchPlaces } from '@/lib/placeSearch';

const DEBOUNCE_MS = 350;
const MIN_LENGTH = 2;

export default function PlaceSearch({ onPick, onClose, t }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeIndex, setActiveIndex] = useState(-1);

  const inputRef = useRef(null);
  const requestIdRef = useRef(0);
  const abortRef = useRef(null);
  const resultsQueryRef = useRef('');
  const submittingRef = useRef(false);
  const suppressNextRef = useRef(false);

  useEffect(() => () => abortRef.current?.abort(), []);

  const runSearch = async (q) => {
    const id = requestIdRef.current + 1;
    requestIdRef.current = id;
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setLoading(true);
    setError(null);
    try {
      const found = await searchPlaces(q, controller.signal);
      if (id !== requestIdRef.current) return null;
      resultsQueryRef.current = q;
      setResults(found);
      setActiveIndex(-1);
      setOpen(true);
      return found;
    } catch (err) {
      if (err?.name === 'AbortError' || id !== requestIdRef.current) return null;
      resultsQueryRef.current = q;
      setResults([]);
      setError(t('route.searchError'));
      setOpen(true);
      return null;
    } finally {
      if (id === requestIdRef.current) setLoading(false);
    }
  };

  // Live suggestions: one debounced request per pause, stale answers are dropped
  useEffect(() => {
    if (suppressNextRef.current) {
      suppressNextRef.current = false;
      return;
    }
    const q = query.trim();
    if (q.length < MIN_LENGTH) {
      abortRef.current?.abort();
      resultsQueryRef.current = '';
      setResults([]);
      setOpen(false);
      setLoading(false);
      setError(null);
      setActiveIndex(-1);
      return;
    }
    const timer = setTimeout(() => { runSearch(q); }, DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [query]);

  const pick = (place) => {
    if (!place) return;
    suppressNextRef.current = true;
    setQuery(place.name);
    setResults([]);
    setOpen(false);
    setActiveIndex(-1);
    setLoading(false);
    setError(null);
    resultsQueryRef.current = '';
    inputRef.current?.blur();
    onPick(place);
  };

  const submit = async () => {
    const q = query.trim();
    if (!q || submittingRef.current) return;
    if (activeIndex >= 0 && results[activeIndex]) {
      pick(results[activeIndex]);
      return;
    }
    submittingRef.current = true;
    try {
      const fresh = resultsQueryRef.current === q && results.length > 0 ? results : await runSearch(q);
      if (fresh && fresh.length > 0) pick(fresh[0]);
    } finally {
      submittingRef.current = false;
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      submit();
    } else if (e.key === 'ArrowDown' && results.length > 0) {
      e.preventDefault();
      setOpen(true);
      setActiveIndex((i) => (i + 1) % results.length);
    } else if (e.key === 'ArrowUp' && results.length > 0) {
      e.preventDefault();
      setActiveIndex((i) => (i <= 0 ? results.length - 1 : i - 1));
    } else if (e.key === 'Escape') {
      e.preventDefault();
      if (open) setOpen(false);
      else onClose();
    }
  };

  const hasText = query.trim().length >= MIN_LENGTH;
  const showPanel = open || !!error || (loading && hasText);

  return (
    <div className="absolute inset-x-0 top-0 z-[1100] pointer-events-none">
      <div className="pointer-events-auto mx-12 mt-2 flex items-center gap-1.5 bg-card border border-border rounded-xl shadow-lg pl-2.5 pr-1 py-1">
        <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={t('route.searchLocation')}
          autoComplete="off"
          enterKeyHint="search"
          className="flex-1 min-w-0 h-9 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
        />
        <button
          type="button"
          onClick={submit}
          className="h-9 px-3 rounded-lg bg-primary text-primary-foreground text-xs font-bold flex-shrink-0 flex items-center justify-center"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : t('route.searchAction')}
        </button>
      </div>

      {showPanel && (
        <div className="pointer-events-auto mx-2 mt-1 bg-card border border-border rounded-xl shadow-xl overflow-y-auto max-h-[45vh] overscroll-contain">
          {error ? (
            <p className="px-4 py-3 text-sm text-destructive">{error}</p>
          ) : results.length === 0 ? (
            hasText && !loading ? (
              <p className="px-4 py-3 text-sm text-muted-foreground">{t('route.searchNoResults')}</p>
            ) : (
              <p className="px-4 py-3 text-sm text-muted-foreground flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" /> {t('route.searching')}
              </p>
            )
          ) : (
            results.map((place, i) => (
              <button
                key={place.id || `${place.lat}-${place.lng}-${i}`}
                type="button"
                onClick={() => pick(place)}
                className={`w-full text-left px-4 py-3 border-b border-border last:border-b-0 active:bg-muted ${activeIndex === i ? 'bg-muted' : ''}`}
              >
                <p className="text-sm font-bold text-foreground truncate">{place.name}</p>
                {place.detail && (
                  <p className="text-xs text-muted-foreground truncate mt-0.5">{place.detail}</p>
                )}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}