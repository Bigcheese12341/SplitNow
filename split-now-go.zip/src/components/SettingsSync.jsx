import { useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useTheme } from '@/lib/ThemeContext';
import i18n from '@/i18n';
import { setOnSyncComplete } from '@/lib/syncQueue';
import { syncPublicProfile } from '@/lib/syncPublicProfile';

export default function SettingsSync() {
  const queryClient = useQueryClient();
  const { data: user } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me(),
  });
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    if (user?.id && !user.is_guest) {
      syncPublicProfile(user);
    }
  }, [user?.id, user?.display_name, user?.avatar_url, user?.bio, user?.is_profile_public]);

  useEffect(() => {
    if (user?.language && user.language !== i18n.language) {
      i18n.changeLanguage(user.language);
      localStorage.setItem('lang', user.language);
    }
  }, [user?.language]);

  useEffect(() => {
    if (user?.theme && user.theme !== theme) {
      setTheme(user.theme);
    }
  }, [user?.theme]);

  useEffect(() => {
    setOnSyncComplete(() => {
      queryClient.invalidateQueries({ queryKey: ['competitors'] });
      queryClient.invalidateQueries({ queryKey: ['competition'] });
    });
  }, [queryClient]);

  return null;
}