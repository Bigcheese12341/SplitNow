import React from 'react';
import { ChevronRight, QrCode, Zap, Check, Users } from 'lucide-react';

export function PhoneFrame({ children }) {
  return (
    <div className="relative mx-auto w-full max-w-[230px]">
      <div className="relative rounded-[2rem] bg-card border-2 border-border p-2 shadow-2xl shadow-primary/10">
        <div className="rounded-[1.4rem] bg-background overflow-hidden h-[300px] flex flex-col">
          {children}
        </div>
      </div>
    </div>
  );
}

export function CreateMockup() {
  return (
    <PhoneFrame>
      <div className="bg-gradient-to-br from-amber-500 to-primary px-3.5 pt-3.5 pb-2.5">
        <div className="text-white/70 text-[9px] font-medium">← Takaisin</div>
        <h3 className="text-white font-black text-sm mt-0.5">Luo kilpailu</h3>
        <p className="text-white/60 text-[9px]">Aloita uusi kilpailu</p>
      </div>
      <div className="flex-1 px-3 py-2 space-y-2 overflow-hidden">
        <div>
          <div className="text-[7px] font-bold text-muted-foreground uppercase tracking-wide">Kilpailun nimi</div>
          <div className="mt-0.5 h-6 rounded-md bg-card border border-border flex items-center px-2 text-[10px] font-medium">Talvi-SM 2026</div>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <div>
            <div className="text-[7px] font-bold text-muted-foreground uppercase">Päivä</div>
            <div className="mt-0.5 h-6 rounded-md bg-card border border-border flex items-center px-2 text-[10px]">21.9.2026</div>
          </div>
          <div>
            <div className="text-[7px] font-bold text-muted-foreground uppercase">Lähtöaika</div>
            <div className="mt-0.5 h-6 rounded-md bg-card border border-border flex items-center px-2 text-[10px]">12:00</div>
          </div>
        </div>
        <div>
          <div className="text-[7px] font-bold text-muted-foreground uppercase">Lähtömuoto</div>
          <div className="mt-0.5 grid grid-cols-2 gap-1">
            <div className="p-1.5 rounded-md border-2 border-primary bg-primary/5">
              <div className="text-[9px] font-bold">Väliaika</div>
              <div className="text-[7px] text-muted-foreground">30s väli</div>
            </div>
            <div className="p-1.5 rounded-md border border-border">
              <div className="text-[9px] font-bold">Yhteis-</div>
              <div className="text-[7px] text-muted-foreground">Kaikki yht.</div>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-center py-1 bg-primary/5 rounded-md">
          <span className="text-[9px] font-semibold text-primary">30 kilpailijaa</span>
        </div>
      </div>
      <div className="px-3 pb-2.5">
        <div className="h-7 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-[10px]">Luo kilpailu</div>
      </div>
    </PhoneFrame>
  );
}

export function JoinMockup() {
  return (
    <PhoneFrame>
      <div className="px-3.5 pt-3.5 pb-1">
        <h3 className="font-black text-sm">Liity kilpailuun</h3>
        <p className="text-muted-foreground text-[9px]">Syötä koodi tai skannaa QR</p>
      </div>
      <div className="flex-1 px-3.5 py-2 flex flex-col items-center justify-center gap-3">
        <div className="w-full">
          <div className="text-[7px] font-bold text-muted-foreground uppercase text-center">Tunnusluku</div>
          <div className="mt-1.5 flex gap-1 justify-center">
            {['4', '8', '2', '1', '5', '7'].map((n, i) => (
              <div key={i} className={`w-6 h-8 rounded-md flex items-center justify-center text-xs font-black ${i < 4 ? 'bg-primary/10 border-2 border-primary text-primary' : 'bg-card border border-border text-muted-foreground'}`}>
                {n}
              </div>
            ))}
          </div>
        </div>
        <div className="w-full flex items-center gap-2">
          <div className="flex-1 h-px bg-border"></div>
          <span className="text-[8px] text-muted-foreground">tai</span>
          <div className="flex-1 h-px bg-border"></div>
        </div>
        <div className="w-14 h-14 rounded-xl bg-card border-2 border-border flex items-center justify-center">
          <QrCode className="w-7 h-7 text-muted-foreground" />
        </div>
      </div>
      <div className="px-3 pb-2.5">
        <div className="h-7 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-[10px] gap-1">
          Liity kilpailuun <ChevronRight className="w-3 h-3" />
        </div>
      </div>
    </PhoneFrame>
  );
}

export function RecordMockup() {
  return (
    <PhoneFrame>
      <div className="px-3 pt-3 pb-1 flex items-center justify-between">
        <div>
          <h3 className="font-black text-xs">Väliaika 1</h3>
          <p className="text-muted-foreground text-[8px]">3 väliaikaa</p>
        </div>
        <div className="w-5 h-5 rounded-md bg-muted flex items-center justify-center">
          <Users className="w-3 h-3 text-muted-foreground" />
        </div>
      </div>
      <div className="flex-1 px-2.5 py-1 space-y-1 overflow-hidden">
        {[
          { bib: 5, name: 'Maija K.', status: 'recorded', time: '12:01:45' },
          { bib: 7, name: 'Antti L.', status: 'active' },
          { bib: 9, name: 'Liisa M.', status: 'waiting' },
          { bib: 11, name: 'Pekka R.', status: 'waiting' },
        ].map((c, i) => (
          <div key={i} className={`flex items-center gap-1.5 px-1.5 py-1 rounded-md ${
            c.status === 'recorded' ? 'bg-primary/10 border border-primary/30' :
            c.status === 'active' ? 'bg-card border-2 border-primary' :
            'bg-card border border-border'
          }`}>
            <div className={`w-5 h-5 rounded flex items-center justify-center text-[9px] font-black ${
              c.status === 'recorded' ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'
            }`}>
              {c.bib}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[9px] font-bold truncate">{c.name}</div>
              <div className="text-[7px] text-muted-foreground">
                {c.status === 'recorded' ? c.time : c.status === 'active' ? 'Seuraavaksi' : 'Odottaa'}
              </div>
            </div>
            {c.status === 'active' && (
              <div className="px-1.5 py-0.5 rounded bg-primary text-primary-foreground text-[8px] font-black">NYT</div>
            )}
            {c.status === 'recorded' && (
              <Check className="w-3 h-3 text-primary" />
            )}
          </div>
        ))}
      </div>
      <div className="px-3 pb-2.5">
        <div className="h-9 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-black text-[11px] gap-1 shadow-lg shadow-primary/30">
          <Zap className="w-3.5 h-3.5" /> Kirjaa NYT
        </div>
      </div>
    </PhoneFrame>
  );
}