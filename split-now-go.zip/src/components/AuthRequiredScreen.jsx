import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/lib/AuthContext';
import { Lock, LogIn, Home } from 'lucide-react';

export default function AuthRequiredScreen({ message }) {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { exitGuestMode, navigateToLogin } = useAuth();

  const handleLogin = () => {
    exitGuestMode();
    navigateToLogin();
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
      <div className="w-full max-w-sm flex flex-col items-center text-center">
        <div className="w-20 h-20 rounded-3xl bg-primary/10 flex items-center justify-center mb-6">
          <Lock className="w-9 h-9 text-primary" />
        </div>
        <p className="font-black text-lg text-foreground mb-2">{t('guest.loginRequired')}</p>
        <p className="text-muted-foreground text-sm mb-8 max-w-xs">{message}</p>
        <button
          onClick={handleLogin}
          className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-black text-base shadow-xl shadow-primary/30 active:scale-[0.98] transition-transform flex items-center justify-center gap-2 mb-3"
        >
          <LogIn className="w-5 h-5" />
          {t('guest.login')}
        </button>
        <button
          onClick={() => navigate('/')}
          className="w-full h-14 rounded-2xl bg-card border border-border text-foreground font-bold text-base active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
        >
          <Home className="w-5 h-5 text-muted-foreground" />
          {t('guest.backToHome')}
        </button>
      </div>
    </div>
  );
}