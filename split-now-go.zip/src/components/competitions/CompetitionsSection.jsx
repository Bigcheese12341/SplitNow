import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import CompetitionCard from '@/components/competitions/CompetitionCard';
import { getCompetitionPhase, sortCompetitions } from '@/lib/competitionSections';

const FINISHED_PREVIEW = 3;

export default function CompetitionsSection({ title, competitions, roleByCompId, highlightNext }) {
  const { t } = useTranslation();
  const [showAllFinished, setShowAllFinished] = useState(false);

  if (!competitions.length) return null;

  const ordered = sortCompetitions(competitions);
  const nextUpcoming = highlightNext
    ? ordered.find((comp) => getCompetitionPhase(comp) === 'upcoming')
    : null;
  const finished = ordered.filter((comp) => getCompetitionPhase(comp) === 'finished');
  const visibleFinished = showAllFinished ? finished : finished.slice(0, FINISHED_PREVIEW);
  const visibleFinishedIds = new Set(visibleFinished.map((comp) => comp.id));
  const visible = ordered.filter(
    (comp) => getCompetitionPhase(comp) !== 'finished' || visibleFinishedIds.has(comp.id)
  );
  const hiddenCount = finished.length - visibleFinished.length;

  return (
    <section>
      <div className="mb-3 flex items-baseline gap-1.5 px-0.5">
        <h2 className="text-[13px] font-black uppercase tracking-[0.12em] text-muted-foreground">
          {title}
        </h2>
        <span className="text-[13px] font-black text-primary">· {competitions.length}</span>
      </div>

      <div className="space-y-3">
        {visible.map((comp) => (
          <CompetitionCard
            key={comp.id}
            comp={comp}
            role={roleByCompId[comp.id]}
            highlight={nextUpcoming?.id === comp.id}
          />
        ))}
      </div>

      {hiddenCount > 0 && (
        <button
          onClick={() => setShowAllFinished(true)}
          className="mt-2.5 h-10 w-full rounded-xl border border-border/70 text-xs font-bold text-muted-foreground transition-transform active:scale-[0.99]"
        >
          {t('competitions.showAllFinished')} · {hiddenCount}
        </button>
      )}

      {showAllFinished && finished.length > FINISHED_PREVIEW && (
        <button
          onClick={() => setShowAllFinished(false)}
          className="mt-1.5 h-9 w-full text-xs font-bold text-muted-foreground"
        >
          {t('competitions.showLess')}
        </button>
      )}
    </section>
  );
}