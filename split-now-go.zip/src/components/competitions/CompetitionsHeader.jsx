import React from 'react';
import { useTranslation } from 'react-i18next';
import { Search, X } from 'lucide-react';
import CompetitionsHeaderActions from '@/components/competitions/CompetitionsHeaderActions';

export default function CompetitionsHeader({
  totalCount,
  searchQuery,
  onSearchChange,
  isGuest,
}) {
  const { t } = useTranslation();

  return (
    <div className="border-b border-border/60 bg-background">
      <div className="mx-auto max-w-lg px-4 pb-3.5 pt-14">
        <div className="mb-3 flex items-center gap-2">
          <h1 className="text-[26px] font-black leading-none tracking-tight text-foreground">
            {t('competitions.title')}
          </h1>
          <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
          <span className="text-sm font-semibold text-muted-foreground">
            {t('competitions.count', { count: totalCount })}
          </span>
        </div>
        {!isGuest && <div className="mb-3"><CompetitionsHeaderActions /></div>}

        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={t('competitions.searchPlaceholder')}
            className="h-11 w-full rounded-xl border border-transparent bg-muted/60 pl-10 pr-10 text-sm font-medium text-foreground transition-colors placeholder:text-muted-foreground focus:border-primary/40 focus:bg-card focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full bg-muted-foreground/15"
            >
              <X className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}