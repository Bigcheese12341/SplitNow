import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Timer, Plus, UserPlus } from 'lucide-react';

export default function CompetitionsEmptyState() {
  const { t } = useTranslation();

  return (
    <div className="py-14 text-center">
      <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
        <Timer className="h-7 w-7 text-primary" />
      </div>
      <p className="text-base font-black text-foreground">{t('home.noCompetitions')}</p>
      <p className="mx-auto mt-1.5 max-w-xs text-sm text-muted-foreground">
        {t('competitions.emptyDesc')}
      </p>
      <div className="mt-6 grid grid-cols-2 gap-2.5">
        <Link
          to="/create"
          className="flex h-12 items-center justify-center gap-1.5 rounded-xl bg-primary text-sm font-bold text-primary-foreground shadow-sm shadow-primary/25 transition-transform active:scale-[0.98]"
        >
          <Plus className="h-4 w-4" />
          {t('home.createCompetition')}
        </Link>
        <Link
          to="/join"
          className="flex h-12 items-center justify-center gap-1.5 rounded-xl border border-border bg-card text-sm font-bold text-foreground transition-transform active:scale-[0.98]"
        >
          <UserPlus className="h-4 w-4 text-muted-foreground" />
          {t('home.joinCompetition')}
        </Link>
      </div>
    </div>
  );
}