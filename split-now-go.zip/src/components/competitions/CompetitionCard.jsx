import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { format } from 'date-fns';
import { Calendar, MapPin, Users } from 'lucide-react';
import { getCompetitionPhase } from '@/lib/competitionSections';
import { sportLabel } from '@/lib/sportLabels';

// Same pill colours as the competition cards on the home screen.
const PHASE_BADGES = {
  finished: { className: 'bg-red-100 text-red-600 dark:bg-red-500/20 dark:text-red-400', label: 'competitions.statusFinished' },
  upcoming: { className: 'bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400', label: 'competitions.statusUpcoming' },
  active: { className: 'bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400', label: 'competitions.statusActive' },
};

const ROLE_LABELS = {
  owner: 'home.owner',
  editor: 'home.roleEditor',
  timer: 'home.roleTimer',
  viewer: 'home.roleViewer',
};

export default function CompetitionCard({ comp, role, highlight }) {
  const { t } = useTranslation();
  const phase = getCompetitionPhase(comp);
  const badge = PHASE_BADGES[phase];
  const totalCompetitors = Math.max(0, (comp.last_number || 0) - (comp.first_number || 0) + 1);

  return (
    <Link to={`/competition/${comp.id}/startlist`}>
      <div
        className={`overflow-hidden rounded-2xl border bg-card shadow-sm transition-all duration-150 active:scale-[0.98] hover:shadow-md ${
          highlight ? 'border-primary/40' : 'border-border hover:border-primary/40'
        }`}
      >
        {comp.images && comp.images.length > 0 && (
          <div className="h-32 overflow-hidden bg-muted">
            <img src={comp.images[0]} alt={comp.name} className="h-full w-full object-cover" />
          </div>
        )}
        <div className="p-4">
          <div className="mb-1.5 flex flex-wrap items-center gap-2">
            <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${badge.className}`}>
              {t(badge.label)}
            </span>
            {comp.sport && (
              <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-bold text-primary">
                {sportLabel(comp.sport, t)}
              </span>
            )}
            {highlight && (
              <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground">
                {t('competitions.nextCompetition')}
              </span>
            )}
          </div>

          <h3 className="mb-1 text-base font-black text-foreground">{comp.name}</h3>

          {comp.description && (
            <p className="mb-2 line-clamp-2 text-sm text-muted-foreground">{comp.description}</p>
          )}

          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3" />
              {comp.date ? format(new Date(comp.date), 'd.M.yyyy') : '—'}
            </span>
            {comp.location && (
              <>
                <span className="h-1 w-1 rounded-full bg-muted-foreground" />
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" />
                  {comp.location}
                </span>
              </>
            )}
            {role && ROLE_LABELS[role] && (
              <>
                <span className="h-1 w-1 rounded-full bg-muted-foreground" />
                <span className="text-xs font-bold text-foreground/70">{t(ROLE_LABELS[role])}</span>
              </>
            )}
            {totalCompetitors > 0 && (
              <>
                <span className="h-1 w-1 rounded-full bg-muted-foreground" />
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Users className="h-3 w-3" />
                  {totalCompetitors}
                </span>
              </>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}