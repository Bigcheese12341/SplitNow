import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, UserPlus } from 'lucide-react';

export default function CompetitionsHeaderActions() {
  const { t } = useTranslation();

  return (
    <div className="mb-3 grid grid-cols-2 gap-2.5">
      <Link
        to="/create"
        className="flex h-11 items-center justify-center gap-1.5 rounded-xl bg-primary text-sm font-bold text-primary-foreground shadow-sm shadow-primary/25 transition-transform active:scale-[0.98]"
      >
        <Plus className="h-4 w-4" />
        {t('home.createCompetition')}
      </Link>
      <Link
        to="/join"
        className="flex h-11 items-center justify-center gap-1.5 rounded-xl border border-border bg-card text-sm font-bold text-foreground shadow-sm transition-transform active:scale-[0.98]"
      >
        <UserPlus className="h-4 w-4 text-muted-foreground" />
        {t('home.joinCompetition')}
      </Link>
    </div>
  );
}