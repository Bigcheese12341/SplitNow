import React from 'react';
import { useTranslation } from 'react-i18next';
import { LogIn } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

export default function GuestLoginButton() {
  const { t } = useTranslation();
  const { navigateToLogin } = useAuth();

  return (
    <button
      onClick={navigateToLogin}
      className="h-9 px-4 rounded-full bg-primary text-primary-foreground font-bold text-sm flex items-center gap-1.5 active:scale-95 transition-transform shadow-sm shadow-primary/20"
    >
      <LogIn className="w-4 h-4" />
      {t('guest.login')}
    </button>
  );
}