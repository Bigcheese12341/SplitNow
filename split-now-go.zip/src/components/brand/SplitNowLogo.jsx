import React from 'react';

const LOGO_URL = 'https://media.base44.com/images/public/69f8e1ea02249993eb2621a8/84f3cc41b_ChatGPTImage2392026klo170118.png';

export default function SplitNowLogo({ className = '' }) {
  return (
    <div className={`overflow-hidden ${className}`}>
      <img
        src={LOGO_URL}
        alt="SplitNow"
        className="w-full h-full object-cover"
      />
    </div>
  );
}