import React from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/lib/AuthContext';
import SplitNowLogo from '@/components/brand/SplitNowLogo';
import { LogIn, Eye } from 'lucide-react';

export default function GuestAuthScreen() {
  const { t } = useTranslation();
  const { navigateToLogin, enterGuestMode } = useAuth();

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-b from-primary/8 to-transparent pointer-events-none" />
      <div className="relative w-full max-w-sm flex flex-col items-center">
        <SplitNowLogo className="w-20 h-20 rounded-3xl shadow-2xl shadow-primary/30 ring-1 ring-primary/20 mb-8" />
        <h1 className="text-3xl font-black text-foreground mb-2 text-center">{t('home.brand')}</h1>
        <p className="text-muted-foreground text-sm text-center mb-10 max-w-xs">
          {t('guest.welcome')}
        </p>
        <button
          onClick={navigateToLogin}
          className="w-full h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/85 text-primary-foreground font-black text-base shadow-xl shadow-primary/30 active:scale-[0.98] transition-transform flex items-center justify-center gap-2 mb-3"
        >
          <LogIn className="w-5 h-5" />
          {t('guest.login')}
        </button>
        <button
          onClick={enterGuestMode}
          className="text-sm font-semibold text-muted-foreground active:scale-95 transition-transform flex items-center gap-1.5"
        >
          <Eye className="w-4 h-4" />
          {t('guest.useWithoutLogin')}
        </button>
      </div>
    </div>
  );
}