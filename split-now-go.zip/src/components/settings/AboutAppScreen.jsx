import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { Timer, Users, Globe, Map, Download, Wifi, Mail, Shield, Loader2, Check } from 'lucide-react';
import SplitNowLogo from '@/components/brand/SplitNowLogo';

export default function AboutAppScreen({ onBack }) {
  const { t } = useTranslation();
  const [contactMessage, setContactMessage] = useState('');
  const [contactSending, setContactSending] = useState(false);
  const [contactSent, setContactSent] = useState(false);
  const [contactError, setContactError] = useState(false);

  const features = [
    { icon: Timer, text: t('aboutApp.feature1') },
    { icon: Globe, text: t('aboutApp.feature2') },
    { icon: Users, text: t('aboutApp.feature3') },
    { icon: Map, text: t('aboutApp.feature4') },
    { icon: Download, text: t('aboutApp.feature5') },
    { icon: Wifi, text: t('aboutApp.feature6') },
  ];

  const handleContactSend = async () => {
    if (!contactMessage.trim() || contactSending) return;
    setContactSending(true);
    setContactError(false);
    try {
      await base44.integrations.Core.SendEmail({
        to: 'support.splitnow@gmail.com',
        subject: t('aboutApp.contactSubject'),
        body: contactMessage
      });
      setContactSent(true);
      setContactMessage('');
      setTimeout(() => setContactSent(false), 4000);
    } catch (err) {
      console.error('Contact send failed', err);
      setContactError(true);
      setTimeout(() => setContactError(false), 5000);
    }
    setContactSending(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 pt-12 pb-6">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-card flex items-center justify-center">
            <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-black text-foreground">{t('settings.aboutApp')}</h1>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 space-y-4 pb-12">
        {/* Hero card */}
        <div className="bg-card rounded-2xl border border-border p-6 text-center">
          <SplitNowLogo className="w-16 h-16 rounded-2xl shadow-lg shadow-primary/20 ring-1 ring-primary/10 mx-auto mb-4" />
          <h2 className="text-2xl font-black text-foreground mb-1">SplitNow</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">{t('aboutApp.tagline')}</p>
          <div className="inline-flex items-center gap-1.5 mt-4 px-3 py-1.5 rounded-full bg-muted text-xs font-bold text-muted-foreground">
            <span>{t('aboutApp.version')}</span>
            <span>1.0.0</span>
          </div>
        </div>

        {/* Description */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <p className="text-sm text-muted-foreground leading-relaxed">{t('aboutApp.description')}</p>
        </div>

        {/* Features */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <h3 className="text-xs font-black uppercase tracking-widest text-muted-foreground mb-4">
            {t('aboutApp.featuresTitle')}
          </h3>
          <div className="space-y-3">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-4 h-4 text-primary" />
                  </div>
                  <p className="text-sm text-foreground font-medium leading-relaxed pt-1">{feature.text}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Contact form */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-2 mb-3">
            <Mail className="w-4 h-4 text-primary" />
            <h3 className="text-xs font-black uppercase tracking-widest text-muted-foreground">
              {t('aboutApp.contactTitle')}
            </h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed mb-4">{t('aboutApp.contactDesc')}</p>
          <div className="space-y-3">
            <textarea
              value={contactMessage}
              onChange={(e) => setContactMessage(e.target.value)}
              placeholder={t('aboutApp.contactMessagePlaceholder')}
              rows={4}
              className="w-full px-4 py-3 rounded-xl bg-muted text-foreground border border-border text-sm focus:outline-none focus:border-primary resize-none"
            />
            <button
              onClick={handleContactSend}
              disabled={!contactMessage.trim() || contactSent || contactSending}
              className="w-full h-11 rounded-xl bg-primary text-primary-foreground font-bold text-sm active:scale-95 transition-transform flex items-center justify-center gap-1.5"
            >
              {contactSent ? (
                <><Check className="w-4 h-4" /> {t('aboutApp.contactSent')}</>
              ) : contactError ? (
                t('aboutApp.contactError')
              ) : contactSending ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> {t('aboutApp.contactSending')}</>
              ) : (
                t('aboutApp.contactSend')
              )}
            </button>
            {contactError && (
              <p className="text-xs text-destructive text-center">{t('aboutApp.contactErrorDesc')}</p>
            )}
            <p className="text-center text-xs text-muted-foreground">
              support.splitnow@gmail.com
            </p>
          </div>
        </div>

        {/* Responsible note */}
        <div className="flex items-start gap-3 px-2">
          <Shield className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground leading-relaxed">{t('aboutApp.responsibleNote')}</p>
        </div>
      </div>
    </div>
  );
}