import React from 'react';
import { useTranslation } from 'react-i18next';
import { Lock, Database, Eye, ShieldCheck, UserCheck, FileText } from 'lucide-react';

export default function PrivacyTermsScreen({ onBack }) {
  const { t } = useTranslation();

  const dataItems = [
    t('privacyInfo.dataItem1'),
    t('privacyInfo.dataItem2'),
    t('privacyInfo.dataItem3'),
  ];

  const rightsItems = [
    t('privacyInfo.rightsItem1'),
    t('privacyInfo.rightsItem2'),
    t('privacyInfo.rightsItem3'),
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 pt-12 pb-6">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-card flex items-center justify-center">
            <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-black text-foreground">{t('settings.privacyTerms')}</h1>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 space-y-4 pb-12">
        {/* Privacy policy intro */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
              <Lock className="w-4 h-4 text-primary" />
            </div>
            <h3 className="font-black text-foreground text-sm">{t('privacyInfo.privacyTitle')}</h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">{t('privacyInfo.privacyDesc')}</p>
        </div>

        {/* Data collection */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
              <Database className="w-4 h-4 text-muted-foreground" />
            </div>
            <h3 className="font-black text-foreground text-sm">{t('privacyInfo.dataTitle')}</h3>
          </div>
          <div className="space-y-2.5">
            {dataItems.map((item, i) => (
              <div key={i} className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0 mt-1.5" />
                <p className="text-sm text-muted-foreground leading-relaxed">{item}</p>
              </div>
            ))}
          </div>
        </div>

        {/* How we use data */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
              <Eye className="w-4 h-4 text-muted-foreground" />
            </div>
            <h3 className="font-black text-foreground text-sm">{t('privacyInfo.usageTitle')}</h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">{t('privacyInfo.usageDesc')}</p>
        </div>

        {/* Security */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-muted-foreground" />
            </div>
            <h3 className="font-black text-foreground text-sm">{t('privacyInfo.securityTitle')}</h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">{t('privacyInfo.securityDesc')}</p>
        </div>

        {/* User rights */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
              <UserCheck className="w-4 h-4 text-muted-foreground" />
            </div>
            <h3 className="font-black text-foreground text-sm">{t('privacyInfo.rightsTitle')}</h3>
          </div>
          <div className="space-y-2.5">
            {rightsItems.map((item, i) => (
              <div key={i} className="flex items-start gap-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0 mt-1.5" />
                <p className="text-sm text-muted-foreground leading-relaxed">{item}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Terms of use */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
              <FileText className="w-4 h-4 text-muted-foreground" />
            </div>
            <h3 className="font-black text-foreground text-sm">{t('privacyInfo.termsTitle')}</h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">{t('privacyInfo.termsDesc')}</p>
        </div>

        {/* Last updated */}
        <p className="text-center text-xs text-muted-foreground pt-2">
          {t('privacyInfo.lastUpdated')}: 20.9.2026
        </p>
      </div>
    </div>
  );
}