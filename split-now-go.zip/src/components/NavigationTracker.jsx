import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { trackMainPage } from '@/lib/navHistory';

// Invisible component that records main page visits for smart back navigation.
export default function NavigationTracker() {
  const location = useLocation();

  useEffect(() => {
    trackMainPage(location.pathname);
  }, [location.pathname]);

  return null;
}