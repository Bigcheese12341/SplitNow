import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

export default function ReportNotification({ visible, onClose, message }) {
  useEffect(() => {
    if (visible) {
      const timer = setTimeout(onClose, 5000);
      return () => clearTimeout(timer);
    }
  }, [visible, onClose]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: -150, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -150, opacity: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          drag="y"
          dragConstraints={{ top: -150, bottom: 0 }}
          dragElastic={0.1}
          onDragEnd={(e, info) => {
            if (info.offset.y < -30) onClose();
          }}
          className="fixed top-0 left-0 right-0 z-[100] px-4 pt-4"
        >
          <div className="bg-card border border-border rounded-2xl shadow-lg p-4 flex items-center gap-3 max-w-lg mx-auto">
            <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-primary" />
            </div>
            <p className="text-sm font-semibold text-foreground flex-1">{message}</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}