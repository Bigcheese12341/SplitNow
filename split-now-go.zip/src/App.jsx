import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import Login from '@/pages/Login';
import Welcome from '@/pages/Welcome';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';

import Home from '@/pages/Home';
import Onboarding from '@/pages/Onboarding';
import Settings from '@/pages/Settings';
import Competitions from '@/pages/Competitions';
import Profile from '@/pages/Profile';
import UserProfile from '@/pages/UserProfile';
import CreateCompetition from '@/pages/CreateCompetition';
import StartList from '@/pages/StartList';
import SplitTime from '@/pages/SplitTime';
import Results from '@/pages/Results';
import EditCompetition from '@/pages/EditCompetition';
import EditCompetitionForm from '@/pages/EditCompetitionForm';
import PublicCompetition from '@/pages/PublicCompetition';
import JoinCompetition from '@/pages/JoinCompetition';
import ImportResults from '@/pages/ImportResults';
import QuickTouch from '@/pages/QuickTouch';
import SettingsSync from '@/components/SettingsSync';
import NavigationTracker from '@/components/NavigationTracker';
import MainLayout from '@/components/layout/MainLayout';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, needsLoginChoice } = useAuth();
  const location = useLocation();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  const authPaths = ['/welcome', '/login', '/register', '/forgot-password', '/reset-password'];
  if (needsLoginChoice && !authPaths.includes(location.pathname)) {
    return <Navigate to="/welcome" replace />;
  }

  return (
    <>
    <SettingsSync />
    <NavigationTracker />
    <Routes>
      <Route path="/welcome" element={<Welcome />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<MainLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/competitions" element={<Competitions />} />
        <Route path="/create" element={<CreateCompetition />} />
        <Route path="/join" element={<JoinCompetition />} />
        <Route path="/profile" element={<Profile />} />
      </Route>
      <Route path="/onboarding" element={<Onboarding />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="/profile/:userId" element={<UserProfile />} />
      <Route path="/competition/:id/startlist" element={<StartList />} />
      <Route path="/competition/:id/split/:splitNum" element={<SplitTime />} />
      <Route path="/competition/:id/results" element={<Results />} />
      <Route path="/competition/:id/edit" element={<EditCompetition />} />
      <Route path="/competition/:id/edit-form" element={<EditCompetitionForm />} />
      <Route path="/competition/:id/public" element={<PublicCompetition />} />
      <Route path="/competition/:id/import" element={<ImportResults />} />
      <Route path="/competition/:id/quicktouch" element={<QuickTouch />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
    </>
  );
};

function App() {
  return (
    <QueryClientProvider client={queryClientInstance}>
      <AuthProvider>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  )
}

export default App