import React, { useState, useEffect } from 'react';

const DRAFT_KEY = 'createCompetitionDraft';
const DRAFT_MAX_AGE = 10 * 60 * 1000; // 10 minutes
import { useNavigate, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft, Flag, Users, Timer, Clock, MapPin, ImagePlus, ListPlus, Lock, Globe, FileText } from 'lucide-react';
import { detectStartFormat, normalizeTime, hasSecondPrecision } from '@/lib/timeUtils';
import StartListUpload from '@/components/startlist/StartListUpload';
import {
  recognizeStartListImage,
  buildCompetitors,
  inferCategorization,
  applyManualSeries,
  applyManualSeriesToRows,
  countDuplicates,
  rowKeyOf,
  syncSeriesLabels
} from '@/lib/startListRecognition';
import { hapticSuccess } from '@/lib/haptics';
import StartTimeInput from '@/components/competition/StartTimeInput';
import SecondsPrecisionToggle from '@/components/competition/SecondsPrecisionToggle';
import RouteSection from '@/components/route/RouteSection';
import SportSelect from '@/components/competition/SportSelect';
import SplitNamesEditor from '@/components/competition/SplitNamesEditor';
import { normalizeSplitNames } from '@/lib/splitLabels';
import GuestLoginOverlay from '@/components/GuestLoginOverlay';
import { isGuestMode } from '@/lib/guestMode';
import { goBack } from '@/lib/navHistory';

export default function CreateCompetition() {
  const { t } = useTranslation();
  const guest = isGuestMode();

  return (
    <div className="relative min-h-screen bg-background">
      <div className={guest ? 'opacity-50 pointer-events-none select-none' : ''}>
        <CreateCompetitionContent />
      </div>
      {guest && <GuestLoginOverlay message={t('guest.createRequiresLogin')} />}
    </div>
  );
}

function CreateCompetitionContent() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [numberMode, setNumberMode] = useState(null);
  const [manualNumbers, setManualNumbers] = useState('');
  const [uploadedCompetitors, setUploadedCompetitors] = useState([]);
  const [uploadedImages, setUploadedImages] = useState([]);
  const [recognizedPages, setRecognizedPages] = useState({});
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({
    name: '',
    date: new Date().toISOString().split('T')[0],
    start_time: '12:00:00',
    start_interval: 30,
    split_count: 1,
    add_finish: true,
    format: 'interval',
    first_number: 1,
    last_number: 30,
    is_public: false,
    description: '',
    sport: '',
    location: '',
    route_data: null,
    route_preview_url: null,
    gender_categorization: false,
    age_categorization: false,
    seconds_precision: false,
    edit_split_names: false,
    split_names: []
  });

  const [draftLoaded, setDraftLoaded] = useState(false);

  // Load draft on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        if (Date.now() - data.timestamp < DRAFT_MAX_AGE) {
          const s = data.state;
          if (s.form) setForm(s.form);
          if (s.numberMode !== undefined) setNumberMode(s.numberMode);
          if (s.manualNumbers !== undefined) setManualNumbers(s.manualNumbers);
          if (s.uploadedCompetitors) setUploadedCompetitors(s.uploadedCompetitors);
          if (s.uploadedImages) setUploadedImages(s.uploadedImages);
          if (s.recognizedPages) setRecognizedPages(s.recognizedPages);
        } else {
          localStorage.removeItem(DRAFT_KEY);
        }
      }
    } catch {}
    setDraftLoaded(true);
  }, []);

  // Save draft (debounced)
  useEffect(() => {
    if (!draftLoaded) return;
    const timer = setTimeout(() => {
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify({
          timestamp: Date.now(),
          state: { form, numberMode, manualNumbers, uploadedCompetitors, uploadedImages, recognizedPages }
        }));
      } catch {}
    }, 500);
    return () => clearTimeout(timer);
  }, [draftLoaded, form, numberMode, manualNumbers, uploadedCompetitors, uploadedImages, recognizedPages]);

  const handleChange = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const parseManualNumbers = (str) => {
    const numbers = new Set();
    str.split(/[,\s]+/).forEach(part => {
      part = part.trim();
      if (!part) return;
      if (part.includes('-')) {
        const [a, b] = part.split('-').map(Number);
        if (!isNaN(a) && !isNaN(b)) {
          for (let i = Math.min(a, b); i <= Math.max(a, b); i++) numbers.add(i);
        }
      } else {
        const n = Number(part);
        if (!isNaN(n)) numbers.add(n);
      }
    });
    return Array.from(numbers).sort((a, b) => a - b);
  };

  const handleFilesSelected = async (files) => {
    if (files.length === 0) return;
    setUploading(true);
    try {
      const uploadResults = await Promise.all(
        files.map(file => base44.integrations.Core.UploadFile({ file }))
      );
      const fileUrls = uploadResults.map(r => r.file_url).filter(Boolean);
      setUploadedImages(prev => [...prev, ...fileUrls]);

      // Every page is recognised on its own, then all pages are read together:
      // a series printed on one page is carried over to the pages that continue
      // the same list.
      const pages = await Promise.all(fileUrls.map(url => recognizeStartListImage(url)));
      const nextPages = { ...recognizedPages };
      fileUrls.forEach((url, i) => { nextPages[url] = pages[i]; });
      setRecognizedPages(nextPages);

      const orderedPages = [...uploadedImages, ...fileUrls].map(url => nextPages[url]).filter(Boolean);
      const competitors = buildCompetitors(orderedPages, uploadedCompetitors);
      setUploadedCompetitors(competitors);

      const { hasGender, hasAge } = inferCategorization(competitors);
      const detected = detectStartFormat(competitors);
      // Start times read from the list already carry their seconds. When any of
      // them is not a flat minute (09:00:15), second precision is switched on so
      // those seconds can be kept exactly; flat minute times leave it alone.
      const hasSeconds = competitors.some((c) => hasSecondPrecision(c.start_time));
      setForm(prev => ({
        ...prev,
        gender_categorization: prev.gender_categorization || hasGender,
        age_categorization: prev.age_categorization || hasAge,
        ...(hasSeconds ? { seconds_precision: true } : {}),
        ...(detected
          ? {
            format: detected.format,
            start_interval: detected.start_interval,
            start_time: normalizeTime(detected.start_time)
          }
          : {})
      }));
    } catch (err) {
      console.error('Start list recognition failed', err);
    }
    setUploading(false);
  };

  const handleRemoveImage = (url) => setUploadedImages(prev => prev.filter(u => u !== url));

  // A series the user filled in also needs its classification switched on.
  const enableCategorization = (next) => {
    const { hasGender, hasAge } = inferCategorization(next);
    setForm(prev => ({
      ...prev,
      gender_categorization: prev.gender_categorization || hasGender,
      age_categorization: prev.age_categorization || hasAge
    }));
  };

  // The classification switches only decide what the competition filters on.
  // They never edit the stored data, but every competitor already in the list
  // follows them at once: its series label is kept in step with its own gender
  // and age class, so switching the age classification on needs no new upload.
  useEffect(() => {
    if (!draftLoaded) return;
    setUploadedCompetitors(prev => syncSeriesLabels(prev));
  }, [form.gender_categorization, form.age_categorization, draftLoaded]);

  // A correction by hand is final: it is marked as manual so no later automatic
  // pass overwrites it. Rows are identified by their row key, so a competitor
  // whose bib number is still missing can be corrected too.
  const handleSaveCompetitor = (key, patch) => {
    const next = uploadedCompetitors.map(c => (rowKeyOf(c) === key ? applyManualSeries(c, patch) : c));
    setUploadedCompetitors(next);
    enableCategorization(next);
  };

  // One series for a whole selected range, e.g. a block read from an image that
  // carried no heading.
  const handleSetSeries = (keys, patch) => {
    const next = applyManualSeriesToRows(uploadedCompetitors, keys, patch);
    setUploadedCompetitors(next);
    enableCategorization(next);
  };

  const handleRemoveCompetitor = (key) => {
    setUploadedCompetitors(prev => prev.filter(c => rowKeyOf(c) !== key));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const startTimeFull = normalizeTime(form.start_time);

    const joinCode = Math.floor(100000 + Math.random() * 900000).toString();
    const startSec = parseTime(startTimeFull);
    const interval = form.format === 'mass_start' ? 0 : Number(form.start_interval);

    let competitorConfigs = [];
    if (numberMode === 'manual') {
      parseManualNumbers(manualNumbers).forEach((num) => {
        const start = form.format === 'mass_start' ? startSec : startSec + (num - 1) * interval;
        competitorConfigs.push({ bib_number: num, name: '', start_time: formatSeconds(start) });
      });
    } else if (numberMode === 'upload') {
      uploadedCompetitors.forEach((c) => {
        // A row whose bib number is still unreadable stays in the review list but
        // cannot become a competitor, so the rest of the list is never blocked.
        if (c.bib_number === null || c.bib_number === undefined) return;
        const start = c.start_time ? c.start_time : (form.format === 'mass_start' ? formatSeconds(startSec) : formatSeconds(startSec + (c.bib_number - 1) * interval));
        const config = { bib_number: c.bib_number, name: c.name || '', start_time: start };
        if (c.gender === 'male' || c.gender === 'female') config.gender = c.gender;
        const age = Number(c.age);
        if (Number.isFinite(age) && age > 0) config.age = Math.round(age);
        if (c.series) config.series = c.series;
        if (c.printed_series) config.printed_series = c.printed_series;
        competitorConfigs.push(config);
      });
    } else {
      for (let i = Number(form.first_number); i <= Number(form.last_number); i++) {
        const start = form.format === 'mass_start' ? startSec : startSec + (i - 1) * interval;
        competitorConfigs.push({ bib_number: i, name: '', start_time: formatSeconds(start) });
      }
    }

    const comp = await base44.entities.Competition.create({
      name: form.name,
      date: form.date,
      start_time: startTimeFull,
      seconds_precision: form.seconds_precision || false,
      start_interval: form.format === 'mass_start' ? 0 : Number(form.start_interval),
      split_count: Number(form.split_count),
      add_finish: form.add_finish,
      format: form.format,
      status: 'active',
      first_number: competitorConfigs.length > 0 ? Math.min(...competitorConfigs.map(c => c.bib_number)) : 1,
      last_number: competitorConfigs.length > 0 ? Math.max(...competitorConfigs.map(c => c.bib_number)) : 1,
      join_code: joinCode,
      default_join_role: 'viewer',
      is_public: form.is_public,
      description: form.description || '',
      sport: form.sport || '',
      location: form.location || '',
      route_data: form.route_data || '',
      route_preview_url: form.route_preview_url || '',
      gender_categorization: form.gender_categorization || false,
      age_categorization: form.age_categorization || false,
      edit_split_names: form.edit_split_names || false,
      split_names: normalizeSplitNames(form.split_names, form.split_count)
    });

    const competitors = competitorConfigs.map(c => ({
      ...c,
      competition_id: comp.id,
      status: 'active',
      split_times: []
    }));

    for (let i = 0; i < competitors.length; i += 50) {
      await base44.entities.Competitor.bulkCreate(competitors.slice(i, i + 50));
    }

    const me = await base44.auth.me();
    await base44.entities.CompetitionMember.create({
      competition_id: comp.id,
      user_id: me.id,
      user_email: me.email,
      user_name: me.display_name || me.full_name,
      role: 'owner'
    });

    localStorage.removeItem(DRAFT_KEY);
    hapticSuccess();
    navigate(`/competition/${comp.id}/startlist`);
  };

  const competitorCount = numberMode === 'manual'
    ? parseManualNumbers(manualNumbers).length
    : numberMode === 'upload'
      ? uploadedCompetitors.length
      : Math.max(0, Number(form.last_number) - Number(form.first_number) + 1);

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-br from-amber-500 to-primary text-white px-4 pt-10 pb-14">
        <div className="max-w-lg mx-auto">
          <button onClick={() => goBack(navigate)} className="inline-flex items-center text-white/80 text-sm font-medium mb-6">
            <ArrowLeft className="w-4 h-4 mr-1" /> {t('common.back')}
          </button>
          <h1 className="text-2xl font-black">{t('create.title')}</h1>
          <p className="text-white/70 text-sm mt-1">{t('create.subtitle')}</p>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 -mt-6 pb-24">
        <form onSubmit={handleSubmit} className="space-y-4">

          <Section icon={<Flag className="w-4 h-4" />} title={t('create.basicInfo')}>
            <Field label={t('create.compName')}>
              <Input
                value={form.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder={t('create.compNamePlaceholder')}
                required
                className="h-12 rounded-xl text-base"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t('create.date')}>
                <Input type="date" value={form.date} onChange={(e) => handleChange('date', e.target.value)} required className="h-12 rounded-xl text-base" />
              </Field>
              <Field
                label={t('create.startTime')}
                className={form.seconds_precision ? 'col-span-2' : ''}
              >
                <StartTimeInput
                  value={form.start_time}
                  onChange={(v) => handleChange('start_time', v)}
                  secondsPrecision={form.seconds_precision}
                  className="h-12 rounded-xl text-base"
                />
              </Field>
            </div>
            <SecondsPrecisionToggle
              checked={form.seconds_precision}
              onChange={(checked) => handleChange('seconds_precision', checked)}
            />
          </Section>

          <Section icon={<Users className="w-4 h-4" />} title={t('create.startList')}>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setNumberMode(numberMode === 'manual' ? null : 'manual')}
                className={`h-12 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                  numberMode === 'manual' ? 'bg-primary text-primary-foreground shadow-md' : 'bg-muted text-foreground'
                }`}
              >
                <ListPlus className="w-4 h-4" />
                {t('create.selectNumbers')}
              </button>
              <button
                type="button"
                onClick={() => setNumberMode(numberMode === 'upload' ? null : 'upload')}
                className={`h-12 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                  numberMode === 'upload' ? 'bg-primary text-primary-foreground shadow-md' : 'bg-muted text-foreground'
                }`}
              >
                <ImagePlus className="w-4 h-4" />
                {t('create.uploadStartList')}
              </button>
            </div>

            {numberMode === null && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <Field label={t('create.firstNumber')}>
                    <Input type="number" min="1" value={form.first_number} onChange={(e) => handleChange('first_number', e.target.value)} required className="h-12 rounded-xl text-base" />
                  </Field>
                  <Field label={t('create.lastNumber')}>
                    <Input type="number" min="1" value={form.last_number} onChange={(e) => handleChange('last_number', e.target.value)} required className="h-12 rounded-xl text-base" />
                  </Field>
                </div>
                <div className="flex items-center justify-center py-2 bg-primary/5 rounded-xl">
                  <span className="text-sm font-semibold text-primary">{t('create.competitorCount', { count: competitorCount })}</span>
                </div>
              </>
            )}

            {numberMode === 'manual' && (
              <Field label={t('create.numbersInput')}>
                <Input
                  value={manualNumbers}
                  onChange={(e) => setManualNumbers(e.target.value)}
                  placeholder={t('create.numbersInputPlaceholder')}
                  className="h-12 rounded-xl text-base"
                />
                <p className="text-xs text-muted-foreground mt-1.5">{t('create.numbersInputHint')}</p>
                <div className="flex items-center justify-center py-2 bg-primary/5 rounded-xl mt-2">
                  <span className="text-sm font-semibold text-primary">{t('create.competitorCount', { count: competitorCount })}</span>
                </div>
              </Field>
            )}

            {numberMode === 'upload' && (
              <StartListUpload
                images={uploadedImages}
                competitors={uploadedCompetitors}
                duplicates={countDuplicates(Object.values(recognizedPages), uploadedCompetitors)}
                uploading={uploading}
                onFilesSelected={handleFilesSelected}
                onRemoveImage={handleRemoveImage}
                onSaveCompetitor={handleSaveCompetitor}
                onRemoveCompetitor={handleRemoveCompetitor}
                onSetSeries={handleSetSeries}
              />
            )}

            <div className="space-y-3 pt-3 border-t border-border">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm">{t('create.genderCategorization')}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{t('create.genderCategorizationSub')}</div>
                </div>
                <Switch
                  checked={form.gender_categorization}
                  onCheckedChange={(checked) => handleChange('gender_categorization', checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm">{t('create.ageCategorization')}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{t('create.ageCategorizationSub')}</div>
                </div>
                <Switch
                  checked={form.age_categorization}
                  onCheckedChange={(checked) => handleChange('age_categorization', checked)}
                />
              </div>
            </div>
          </Section>

          <Section icon={<Timer className="w-4 h-4" />} title={t('create.format')}>
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: 'interval', label: t('create.intervalStart'), sub: t('create.intervalStartSub') },
                { value: 'mass_start', label: t('create.massStart'), sub: t('create.massStartSub') }
              ].map((opt) =>
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => handleChange('format', opt.value)}
                  className={`p-3 rounded-xl border-2 text-left transition-all ${
                  form.format === opt.value ? 'border-primary bg-primary/5' : 'border-border bg-card'}`
                  }>
                  <div className="font-bold text-sm">{opt.label}</div>
                  <div className="text-xs text-muted-foreground">{opt.sub}</div>
                </button>
              )}
            </div>

            {form.format === 'interval' &&
            <div>
                <Label className="text-sm font-semibold">{t('create.startInterval')}</Label>
                <div className="flex gap-2 mt-2">
                  {[15, 20, 30].map((val) =>
                <button
                  key={val}
                  type="button"
                  onClick={() => handleChange('start_interval', val)}
                  className={`flex-1 h-11 rounded-xl font-bold text-sm transition-all ${
                  Number(form.start_interval) === val ?
                  'bg-primary text-primary-foreground shadow-md' :
                  'bg-muted text-foreground'}`
                  }>
                      {val}s
                    </button>
                )}
                </div>
                <Input
                type="number" min="1"
                value={form.start_interval}
                onChange={(e) => handleChange('start_interval', e.target.value)}
                className="mt-2 h-11 rounded-xl text-base"
                placeholder={t('create.otherValue')} />
            </div>
            }
          </Section>

          <Section icon={<Clock className="w-4 h-4" />} title={t('create.splits')}>
            <Field label={t('create.splitCount')}>
              <div className="flex gap-2">
                {[1, 2, 3].map((val) =>
                <button
                  key={val}
                  type="button"
                  onClick={() => handleChange('split_count', val)}
                  className={`flex-1 h-11 rounded-xl font-bold text-sm transition-all ${
                  Number(form.split_count) === val ?
                  'bg-primary text-primary-foreground shadow-md' :
                  'bg-muted text-foreground'}`
                  }>
                    {val}
                  </button>
                )}
                <Input
                  type="number" min="1" max="10"
                  value={form.split_count}
                  onChange={(e) => handleChange('split_count', e.target.value)}
                  className="h-11 rounded-xl text-base w-20" />
              </div>
            </Field>
            <SplitNamesEditor
              enabled={form.edit_split_names}
              names={form.split_names}
              splitCount={form.split_count}
              onChange={(enabled, names) => setForm(prev => ({ ...prev, edit_split_names: enabled, split_names: names }))}
            />
          </Section>

          <Section icon={<MapPin className="w-4 h-4" />} title={t('create.finish')}>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-sm">{t('create.addFinish')}</div>
                <div className="text-xs text-muted-foreground">{t('create.addFinishSub')}</div>
              </div>
              <Switch
                checked={form.add_finish}
                onCheckedChange={(checked) => handleChange('add_finish', checked)}
              />
            </div>
          </Section>

          <RouteSection
            routeData={form.route_data}
            routePreviewUrl={form.route_preview_url}
            splitCount={Number(form.split_count)}
            addFinish={form.add_finish}
            canEdit={true}
            onSave={(data, preview) => setForm(prev => ({ ...prev, route_data: data, route_preview_url: preview || prev.route_preview_url }))}
            onDelete={() => setForm(prev => ({ ...prev, route_data: null, route_preview_url: null }))}
            t={t}
          />

          <Section icon={form.is_public ? <Globe className="w-4 h-4" /> : <Lock className="w-4 h-4" />} title={t('create.privacy')}>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleChange('is_public', false)}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  !form.is_public ? 'border-primary bg-primary/5' : 'border-border bg-card'
                }`}
              >
                <Lock className={`w-4 h-4 mb-1.5 ${!form.is_public ? 'text-primary' : 'text-muted-foreground'}`} />
                <div className="font-bold text-sm">{t('create.private')}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{t('create.privateDesc')}</div>
              </button>
              <button
                type="button"
                onClick={() => handleChange('is_public', true)}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  form.is_public ? 'border-primary bg-primary/5' : 'border-border bg-card'
                }`}
              >
                <Globe className={`w-4 h-4 mb-1.5 ${form.is_public ? 'text-primary' : 'text-muted-foreground'}`} />
                <div className="font-bold text-sm">{t('create.public')}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{t('create.publicDesc')}</div>
              </button>
            </div>
          </Section>

          {form.is_public && (
            <Section icon={<FileText className="w-4 h-4" />} title={t('create.publicPageInfo')}>
              <Field label={t('create.sport')}>
                <SportSelect
                  value={form.sport}
                  onChange={(v) => handleChange('sport', v)}
                />
              </Field>
              <Field label={t('create.location')}>
                <Input
                  value={form.location}
                  onChange={(e) => handleChange('location', e.target.value)}
                  placeholder={t('create.locationPlaceholder')}
                  className="h-12 rounded-xl text-base"
                />
              </Field>
              <Field label={t('create.description')}>
                <textarea
                  value={form.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  placeholder={t('create.descriptionPlaceholder')}
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl bg-transparent border border-input text-base text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring resize-none"
                />
              </Field>
            </Section>
          )}

          <Button
            type="submit"
            disabled={saving || !form.name || competitorCount === 0}
            className="w-full h-14 text-lg font-bold rounded-2xl shadow-lg shadow-primary/25">
            {saving ? t('create.creating') : t('create.create')}
          </Button>
        </form>
      </div>
    </div>
  );
}

function Section({ icon, title, children }) {
  return (
    <div className="bg-card rounded-2xl border border-border p-4 space-y-3">
      <div className="flex items-center gap-2 text-sm font-bold text-foreground">
        <span className="text-primary">{icon}</span>
        {title}
      </div>
      {children}
    </div>
  );
}

function Field({ label, children, className }) {
  return (
    <div className={`space-y-1.5 ${className || ''}`}>
      <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</Label>
      {children}
    </div>
  );
}

function parseTime(timeStr) {
  const parts = timeStr.split(':').map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 3600 + parts[1] * 60;
  return 0;
}

function formatSeconds(totalSec) {
  const wrapped = ((totalSec % 86400) + 86400) % 86400;
  const h = Math.floor(wrapped / 3600);
  const m = Math.floor((wrapped % 3600) / 60);
  const s = wrapped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}