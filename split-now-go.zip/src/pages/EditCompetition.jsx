import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import CompetitionNav from '@/components/competition/CompetitionNav';
import { Trash2, Share2, Users, UserMinus, Pencil, Route as RouteIcon, ImageDown, Eye, UserPlus, LogOut } from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from
'@/components/ui/alert-dialog';
import ShareSheet from '@/components/competition/ShareSheet';
import MembersSheet from '@/components/competition/MembersSheet';
import { ROLE_STYLES } from '@/lib/roleStyles';
import { useUserRole } from '@/lib/permissions';
import RouteEditor from '@/components/route/RouteEditor';
import RouteView from '@/components/route/RouteView';
import { parseRouteData, routeHasContent } from '@/lib/routeUtils';
import ViewModeSheet from '@/components/competition/ViewModeSheet';
import { useViewMode } from '@/lib/quickTouchPrefs';
import { useToast } from '@/components/ui/use-toast';

export default function EditCompetition() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { permissions, role, user, membership } = useUserRole(id);
  const [showDelete, setShowDelete] = useState(false);
  const [showLeave, setShowLeave] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showMembers, setShowMembers] = useState(false);
  const [showRouteEditor, setShowRouteEditor] = useState(false);
  const [showRouteView, setShowRouteView] = useState(false);
  const [showViewMode, setShowViewMode] = useState(false);
  const [joining, setJoining] = useState(false);
  const [leaving, setLeaving] = useState(false);
  const [viewMode, setViewMode] = useViewMode(user?.id, id);

  const { data: competition } = useQuery({
    queryKey: ['competition', id],
    queryFn: () => base44.entities.Competition.filter({ id }),
    select: (data) => data[0]
  });

  const isMember = !!membership;
  const isOwner = role === 'owner';

  const handleDelete = async () => {
    await base44.functions.invoke('manageCompetitionMember', { action: 'purgeMembers', competitionId: id });
    await base44.entities.Competitor.deleteMany({ competition_id: id });
    await base44.entities.Competition.delete(id);
    queryClient.removeQueries({ queryKey: ['competitions'] });
    queryClient.removeQueries({ queryKey: ['competition', id] });
    queryClient.removeQueries({ queryKey: ['competitors', id] });
    queryClient.removeQueries({ queryKey: ['members', id] });
    navigate('/');
  };

  const handleJoin = async () => {
    setJoining(true);
    try {
      const me = await base44.auth.me();
      await base44.entities.CompetitionMember.create({
        competition_id: id,
        user_id: me.id,
        user_email: me.email,
        user_name: me.display_name || me.full_name,
        role: competition?.default_join_role || 'viewer'
      });
      queryClient.invalidateQueries({ queryKey: ['my-membership', id, me.id] });
      queryClient.invalidateQueries({ queryKey: ['members', id] });
      queryClient.invalidateQueries({ queryKey: ['competitions'] });
    } catch (err) {
      console.error('Join failed', err);
    }
    setJoining(false);
  };

  const handleLeave = async () => {
    // Guard against a double tap firing two delete requests.
    if (leaving || !membership) return;
    setLeaving(true);
    try {
      await base44.entities.CompetitionMember.delete(membership.id);
      queryClient.removeQueries({ queryKey: ['my-membership', id, user?.id] });
      queryClient.invalidateQueries({ queryKey: ['members', id] });
      queryClient.invalidateQueries({ queryKey: ['competitions'] });
      setShowLeave(false);
      navigate('/', { replace: true });
    } catch (err) {
      setLeaving(false);
      toast({ variant: 'destructive', title: t('join.leaveFailed') });
    }
  };

  const roleStyle = ROLE_STYLES[role] || ROLE_STYLES.viewer;
  const roleLabel = t(`members.role${role.charAt(0).toUpperCase() + role.slice(1)}`);
  // Timers and editors reach the shared settings: view mode, member list, leaving.
  const canUseViewMode = permissions.canRecordTimes;
  const canSeeMembers = permissions.canRecordTimes || permissions.canManageMembers;
  const hasRoute = routeHasContent(parseRouteData(competition?.route_data));

  return (
    <div className="min-h-screen bg-background">
      <CompetitionNav competition={competition} />

      <div className="max-w-lg mx-auto px-4 py-4 pb-10 space-y-6">
        {/* Role badge */}
        {isMember && (
          <div className={`flex items-center gap-2 rounded-2xl px-4 py-3 border ${roleStyle.bg} ${roleStyle.border}`}>
            <span className={`font-black text-sm ${roleStyle.accent}`}>{roleLabel}</span>
          </div>
        )}

        {isOwner ? (
          <>
            {/* Section: Kilpailu */}
            <div className="space-y-3">
              <p className="text-xs font-black uppercase tracking-widest text-muted-foreground px-1">
                {t('edit.sectionCompetition')}
              </p>
              <button
                type="button"
                onClick={() => navigate(`/competition/${id}/edit-form`)}
                className="w-full h-16 rounded-2xl bg-primary text-primary-foreground font-black text-base flex items-center justify-center gap-2 shadow-lg shadow-primary/25 active:scale-[0.98] transition-all">
                <Pencil className="w-5 h-5" />
                {t('edit.editCompetition')}
              </button>
              <button
                type="button"
                onClick={() => navigate(`/competition/${id}/import?context=settings`)}
                className="w-full h-14 rounded-2xl bg-amber-500/10 text-amber-700 dark:text-amber-400 font-black text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-all border border-amber-500/20">
                <ImageDown className="w-5 h-5" />
                {t('importResults.button')}
              </button>
              {hasRoute ? (
                <button
                  type="button"
                  onClick={() => setShowRouteEditor(true)}
                  className="w-full rounded-2xl overflow-hidden border border-purple-500/20 active:scale-[0.99] transition-all"
                >
                  {competition?.route_preview_url ? (
                    <img src={competition.route_preview_url} alt={t('route.title')} className="w-full h-40 object-cover" />
                  ) : (
                    <div className="w-full h-12 bg-purple-500/10 text-purple-600 dark:text-purple-400 font-bold text-sm flex items-center justify-center gap-2">
                      <RouteIcon className="w-4 h-4" />
                      {t('route.viewRoute')}
                    </div>
                  )}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowRouteEditor(true)}
                  className="w-full h-12 rounded-2xl bg-purple-500/10 text-purple-600 dark:text-purple-400 font-bold text-sm flex items-center justify-center gap-2 border border-purple-500/20 active:scale-95 transition-all">
                  <RouteIcon className="w-4 h-4" />
                  {t('route.addRoute')}
                </button>
              )}
            </div>

            {/* Section: Yhteistyö */}
            <div className="space-y-3">
              <p className="text-xs font-black uppercase tracking-widest text-muted-foreground px-1">
                {t('edit.sectionCollaboration')}
              </p>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setShowShare(true)}
                  className="h-12 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold text-sm flex items-center justify-center gap-2 border border-blue-500/20 active:scale-95 transition-all">
                  <Share2 className="w-4 h-4" />
                  {t('edit.share')}
                </button>
                <button
                  type="button"
                  onClick={() => setShowMembers(true)}
                  className="h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold text-sm flex items-center justify-center gap-2 border border-emerald-500/20 active:scale-95 transition-all">
                  <Users className="w-4 h-4" />
                  {t('edit.members')}
                </button>
              </div>
            </div>

            {/* Section: Käyttöasetukset */}
            <div className="space-y-3">
              <p className="text-xs font-black uppercase tracking-widest text-muted-foreground px-1">
                {t('edit.sectionSettings')}
              </p>
              <button
                type="button"
                onClick={() => setShowViewMode(true)}
                className="w-full h-14 rounded-2xl bg-muted text-foreground font-bold text-sm flex items-center justify-center gap-2 border border-border active:scale-[0.98] transition-all">
                <Eye className="w-5 h-5" />
                {t('quickTouch.viewMode')}
              </button>
            </div>

            {/* Section: Poista kilpailu */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => setShowDelete(true)}
                className="w-full h-12 rounded-2xl border-2 border-red-200 dark:border-red-500/30 text-red-500 dark:text-red-400 font-bold flex items-center justify-center gap-2 hover:bg-red-50 dark:hover:bg-red-500/10 active:scale-[0.98] transition-all">
                <Trash2 className="w-4 h-4" />
                {t('edit.delete')}
              </button>
            </div>
          </>
        ) : (
          <>
            {/* Yhteistyö */}
            <div className="space-y-3">
              <p className="text-xs font-black uppercase tracking-widest text-muted-foreground px-1">
                {t('edit.sectionCollaboration')}
              </p>
              <div className={`grid gap-3 ${canSeeMembers ? 'grid-cols-2' : 'grid-cols-1'}`}>
                <button
                  type="button"
                  onClick={() => setShowShare(true)}
                  className="h-12 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold text-sm flex items-center justify-center gap-2 border border-blue-500/20 active:scale-95 transition-all">
                  <Share2 className="w-4 h-4" />
                  {t('edit.share')}
                </button>
                {canSeeMembers && (
                  <button
                    type="button"
                    onClick={() => setShowMembers(true)}
                    className="h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold text-sm flex items-center justify-center gap-2 border border-emerald-500/20 active:scale-95 transition-all">
                    <Users className="w-4 h-4" />
                    {t('edit.members')}
                  </button>
                )}
              </div>
            </div>

            {/* Non-owner: Kilpailureitti (if exists) */}
            {hasRoute && (
              <div className="space-y-3">
                <p className="text-xs font-black uppercase tracking-widest text-muted-foreground px-1">
                  {t('route.title')}
                </p>
                <button
                  type="button"
                  onClick={() => setShowRouteView(true)}
                  className="w-full rounded-2xl overflow-hidden border border-purple-500/20 active:scale-[0.99] transition-all"
                >
                  {competition?.route_preview_url ? (
                    <img src={competition.route_preview_url} alt={t('route.title')} className="w-full h-40 object-cover" />
                  ) : (
                    <div className="w-full h-12 bg-purple-500/10 text-purple-600 dark:text-purple-400 font-bold text-sm flex items-center justify-center gap-2">
                      <RouteIcon className="w-4 h-4" />
                      {t('route.viewRoute')}
                    </div>
                  )}
                </button>
              </div>
            )}

            {/* Käyttöasetukset */}
            {(canUseViewMode || isMember) && (
              <div className="space-y-3">
                <p className="text-xs font-black uppercase tracking-widest text-muted-foreground px-1">
                  {t('edit.sectionSettings')}
                </p>
                {canUseViewMode && (
                  <button
                    type="button"
                    onClick={() => setShowViewMode(true)}
                    className="w-full h-14 rounded-2xl bg-muted text-foreground font-bold text-sm flex items-center justify-center gap-2 border border-border active:scale-[0.98] transition-all">
                    <Eye className="w-5 h-5" />
                    {t('quickTouch.viewMode')}
                  </button>
                )}
                {isMember && (
                  <button
                    type="button"
                    onClick={() => setShowLeave(true)}
                    className="w-full h-12 rounded-2xl border-2 border-border text-muted-foreground font-bold flex items-center justify-center gap-2 hover:bg-muted active:scale-[0.98] transition-all">
                    <LogOut className="w-4 h-4" />
                    {t('join.leaveCompetition')}
                  </button>
                )}
              </div>
            )}

            {!isMember && competition?.is_public && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleJoin}
                  disabled={joining}
                  className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition-all disabled:opacity-50">
                  <UserPlus className="w-4 h-4" />
                  {joining ? '...' : t('join.joinCompetition')}
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {showViewMode && (
        <ViewModeSheet
          open={showViewMode}
          onOpenChange={setShowViewMode}
          currentMode={viewMode}
          onSelect={setViewMode}
        />
      )}
      {showShare && <ShareSheet competition={competition} onClose={() => setShowShare(false)} />}
      {showMembers && <MembersSheet competitionId={id} onClose={() => setShowMembers(false)} />}

      {showRouteEditor && (
        <RouteEditor
          initialRouteData={competition?.route_data ? JSON.parse(competition.route_data) : null}
          splitCount={competition?.split_count || 1}
          addFinish={competition?.add_finish || false}
          onDone={async (data, preview) => {
            await base44.entities.Competition.update(id, {
              route_data: JSON.stringify(data),
              ...(preview ? { route_preview_url: preview } : {})
            });
            queryClient.invalidateQueries({ queryKey: ['competition', id] });
            setShowRouteEditor(false);
            toast({ title: t('route.savedToast') });
          }}
          onAutoSave={async (data) => {
            try {
              await base44.entities.Competition.update(id, { route_data: JSON.stringify(data) });
              queryClient.invalidateQueries({ queryKey: ['competition', id] });
            } catch (err) {
              console.error('Route autosave failed', err);
            }
          }}
          onClose={() => setShowRouteEditor(false)}
          t={t}
        />
      )}
      {showRouteView && (
        <RouteView routeDataStr={competition?.route_data} onClose={() => setShowRouteView(false)} t={t} />
      )}

      <AlertDialog open={showDelete} onOpenChange={setShowDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('edit.deleteConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('edit.deleteDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              {t('common.delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showLeave} onOpenChange={(open) => { if (!leaving) setShowLeave(open); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('join.leaveConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('join.leaveConfirmDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); handleLeave(); }}
              disabled={leaving}
              className="bg-destructive text-destructive-foreground disabled:opacity-60">
              {leaving ? '...' : t('join.leaveCompetition')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}