import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { LogIn, Eye } from 'lucide-react';
import SplitNowLogo from '@/components/brand/SplitNowLogo';
import { useAuth } from '@/lib/AuthContext';

export default function Welcome() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { enterGuestMode } = useAuth();

  const handleGuest = () => {
    enterGuestMode();
    const onboardingDone = localStorage.getItem('guest_onboarding_done') === 'true';
    navigate(onboardingDone ? '/' : '/onboarding');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
      <div className="w-full max-w-sm flex flex-col items-center">
        <SplitNowLogo className="w-24 h-24 rounded-3xl shadow-2xl shadow-primary/30 ring-1 ring-primary/20 mb-8" />
        <h1 className="text-3xl font-black text-foreground text-center mb-2">
          {t('welcome.title')}
        </h1>
        <p className="text-muted-foreground text-center mb-10">
          {t('guest.welcome')}
        </p>
        <button
          onClick={() => navigate('/login')}
          className="w-full h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/85 text-primary-foreground font-black text-base shadow-xl shadow-primary/30 active:scale-[0.98] transition-transform flex items-center justify-center gap-2 mb-3"
        >
          <LogIn className="w-5 h-5" />
          {t('guest.login')}
        </button>
        <button
          onClick={handleGuest}
          className="w-full h-14 rounded-2xl bg-card border border-border text-foreground font-bold text-base active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
        >
          <Eye className="w-5 h-5 text-muted-foreground" />
          {t('guest.useWithoutLogin')}
        </button>
      </div>
    </div>
  );
}