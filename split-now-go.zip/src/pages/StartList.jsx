import React, { useState, useRef, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import CompetitionNav from '@/components/competition/CompetitionNav';
import StartListSheet from '@/components/competition/StartListSheet';
import LongPressDragList from '@/components/competition/LongPressDragList';
import CompetitorSearch, { matchCompetitor } from '@/components/competition/CompetitorSearch';
import { Plus, UserPlus, X, AlertTriangle } from 'lucide-react';
import { useUserRole } from '@/lib/permissions';
import TimeInput from '@/components/competition/TimeInput';
import SeriesBadge from '@/components/competition/SeriesBadge';
import { computeNextStartTime } from '@/lib/startTimeUtils';
import { execOrQueue, cacheData, getCachedData, addCachedCompetitor, updateCachedCompetitor, removeCachedCompetitor } from '@/lib/syncQueue';
import { capitalizeName } from '@/lib/nameUtils';
import { useSeriesPalette } from '@/lib/seriesPalette';

export default function StartList() {
  const { t } = useTranslation();
  const { id } = useParams();
  const queryClient = useQueryClient();
  const [selectedComp, setSelectedComp] = useState(null);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState('');
  const [newBib, setNewBib] = useState('');
  const [newName, setNewName] = useState('');
  const [newStart, setNewStart] = useState('00:00:00');
  const [namingId, setNamingId] = useState(null);
  const [namingValue, setNamingValue] = useState('');
  const { permissions, role } = useUserRole(id);
  const nameInputRef = useRef(null);
  const skipBlurRef = useRef(false);

  const { data: competition } = useQuery({
    queryKey: ['competition', id],
    queryFn: async () => {
      try {
        const data = await base44.entities.Competition.filter({ id });
        cacheData(`competition_${id}`, data[0]);
        return data[0];
      } catch (err) {
        if (!navigator.onLine) return getCachedData(`competition_${id}`);
        throw err;
      }
    },
  });

  const { data: competitors = [], isLoading } = useQuery({
    queryKey: ['competitors', id],
    queryFn: async () => {
      try {
        const data = await base44.entities.Competitor.filter({ competition_id: id }, 'bib_number');
        cacheData(`competitors_${id}`, data);
        return data;
      } catch (err) {
        if (!navigator.onLine) return getCachedData(`competitors_${id}`) || [];
        throw err;
      }
    },
  });

  useSeriesPalette(competitors, competition);

  useEffect(() => {
    if (namingId && nameInputRef.current) {
      nameInputRef.current.focus();
      nameInputRef.current.select();
    }
  }, [namingId]);

  const openSheet = (comp) => {
    if (namingId) {
      setNamingId(null);
      return;
    }
    if (!permissions.canRecordTimes) return;
    setSelectedComp(comp);
    setSheetOpen(true);
  };

  const handleSheetChange = (open) => {
    setSheetOpen(open);
    if (!open) setSelectedComp(null);
  };

  const openAddForm = () => {
    const nextStart = computeNextStartTime(competition, competitors);
    setNewStart(nextStart);
    const nextBibNum = competitors.length > 0
      ? Math.max(...competitors.map(c => c.bib_number || 0)) + 1
      : (competition?.first_number || 1);
    setNewBib(String(nextBibNum));
    setShowAdd(true);
  };

  const handleAdd = async () => {
    const bib = Number(newBib);
    if (!bib) return;
    const nextSortOrder = competitors.length > 0
      ? Math.max(...competitors.map(c => c.sort_order ?? c.bib_number ?? 0)) + 1
      : 1;
    const tempId = `temp_${Date.now()}`;
    const newComp = {
      id: tempId,
      competition_id: id,
      bib_number: bib,
      name: newName,
      start_time: newStart || '00:00:00',
      status: 'active',
      split_times: [],
      sort_order: nextSortOrder,
    };
    queryClient.setQueryData(['competitors', id], (old) => [...(old || []), newComp]);
    addCachedCompetitor(id, newComp);
    await execOrQueue('Competitor', 'create', {
      competition_id: id,
      bib_number: bib,
      name: newName,
      start_time: newStart || '00:00:00',
      status: 'active',
      sort_order: nextSortOrder,
    });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
    setShowAdd(false);
    setNewBib('');
    setNewName('');
    setNewStart('00:00:00');
  };

  // Quick naming
  const startNaming = (comp, e) => {
    e.stopPropagation();
    setNamingId(comp.id);
    setNamingValue('');
  };

  const saveName = async (compId) => {
    const name = namingValue.trim();
    if (!name) {
      setNamingId(null);
      return;
    }
    const comp = competitors.find(c => c.id === compId);
    if (!comp) {
      setNamingId(null);
      return;
    }

    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === compId ? { ...c, name } : c)
    );
    updateCachedCompetitor(id, compId, { name });
    await execOrQueue('Competitor', 'update', compId, { name });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });

    // Find next unnamed competitor (sorted by bib_number)
    const sortedComps = [...competitors].sort((a, b) => {
      const aOrder = a.sort_order ?? a.bib_number ?? 0;
      const bOrder = b.sort_order ?? b.bib_number ?? 0;
      return aOrder - bOrder;
    });
    const currentIdx = sortedComps.findIndex(c => c.id === compId);
    const nextUnnamed = sortedComps.slice(currentIdx + 1).find(c => !c.name);

    if (nextUnnamed) {
      skipBlurRef.current = true;
      setNamingId(nextUnnamed.id);
      setNamingValue('');
      setTimeout(() => { skipBlurRef.current = false; }, 100);
    } else {
      setNamingId(null);
    }
  };

  const handleNamingKeyDown = (e, compId) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      saveName(compId);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setNamingId(null);
    }
  };

  const handleNamingBlur = () => {
    if (skipBlurRef.current) return;
    setNamingId(null);
  };

  // Reorder - updates sort_order only, never bib_number
  const handleReorder = async (reordered) => {
    const previousCompetitors = [...competitors];

    const updates = reordered.map((comp, i) => ({
      id: comp.id,
      sort_order: i + 1,
    }));

    const updatedCompetitors = reordered.map((comp, i) => ({ ...comp, sort_order: i + 1 }));
    queryClient.setQueryData(['competitors', id], updatedCompetitors);
    updatedCompetitors.forEach(c => updateCachedCompetitor(id, c.id, { sort_order: c.sort_order }));

    try {
      await base44.entities.Competitor.bulkUpdate(updates);
      queryClient.invalidateQueries({ queryKey: ['competitors', id] });
    } catch (err) {
      queryClient.setQueryData(['competitors', id], previousCompetitors);
      previousCompetitors.forEach(c => updateCachedCompetitor(id, c.id, { sort_order: c.sort_order }));
    }
  };

  const duplicateBibs = React.useMemo(() => {
    const counts = {};
    competitors.forEach(c => {
      const bib = c.bib_number;
      counts[bib] = (counts[bib] || 0) + 1;
    });
    return new Set(Object.entries(counts).filter(([, count]) => count > 1).map(([bib]) => Number(bib)));
  }, [competitors]);

  const sortedCompetitors = React.useMemo(() => {
    return [...competitors].sort((a, b) => {
      const aOrder = a.sort_order ?? a.bib_number ?? 0;
      const bOrder = b.sort_order ?? b.bib_number ?? 0;
      return aOrder - bOrder;
    });
  }, [competitors]);

  const filtered = React.useMemo(() =>
    sortedCompetitors.filter(c => matchCompetitor(c, search)),
    [sortedCompetitors, search]
  );

  const statusBadge = (status) => {
    if (status === 'DNS') return <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-400">DNS</span>;
    if (status === 'DNF') return <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400">DNF</span>;
    if (status === 'DSQ') return <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400">DSQ</span>;
    return null;
  };

  return (
    <div className="min-h-screen bg-background">
      <CompetitionNav competition={competition} />

      <div className="max-w-lg mx-auto px-4 py-4">
        {isLoading ? (
          <div className="space-y-1">
            {[1, 2, 3, 4, 5, 6, 7].map(i => (
              <div key={i} className="h-11 rounded-lg bg-muted animate-pulse" />
            ))}
          </div>
        ) : competitors.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <p className="font-semibold">{t('startList.noCompetitors')}</p>
            <p className="text-sm mt-1">{t('startList.emptyHint')}</p>
          </div>
        ) : (
          <div className="space-y-0.5">
            <CompetitorSearch value={search} onChange={setSearch} />
            {filtered.length === 0 && (
              <p className="text-center py-8 text-sm text-muted-foreground">{t('common.noResults')}</p>
            )}
            <div className="grid grid-cols-[2.25rem_4.5rem_1fr_auto] gap-1 px-2.5 py-1 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
              <span>{t('startList.bibNumber')}</span>
              <span>{t('startList.startTime')}</span>
              <span>{t('startList.name')}</span>
              <span></span>
            </div>

            <LongPressDragList
              items={search ? filtered : sortedCompetitors}
              onReorder={handleReorder}
              onTap={openSheet}
              canReorder={role === 'owner' && !search}
              isItemDisabled={(comp) => namingId === comp.id}
              renderItem={(comp, isDragging) => {
                const status = comp.status || 'active';
                const isNaming = namingId === comp.id;
                const hasName = !!comp.name;

                if (isNaming) {
                  return (
                    <div className="grid grid-cols-[2.25rem_4.5rem_1fr_auto] gap-1 items-center px-2.5 py-1.5 rounded-lg border-2 border-primary bg-card">
                      <span className="font-bold text-base tabular-nums flex items-center gap-1">
                        {comp.bib_number}
                        {duplicateBibs.has(comp.bib_number) && (
                          <span title={t('startList.duplicateBibTooltip')} className="text-amber-500">
                            <AlertTriangle className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </span>
                      <span className="text-xs text-muted-foreground tabular-nums font-mono">{comp.start_time}</span>
                        <input
                          ref={nameInputRef}
                        value={namingValue}
                        onChange={e => setNamingValue(capitalizeName(e.target.value))}
                        onKeyDown={e => handleNamingKeyDown(e, comp.id)}
                        onBlur={handleNamingBlur}
                        className="h-8 px-2 rounded-md bg-muted border border-primary outline-none text-base min-w-0 w-full"
                        placeholder={t('startList.name')}
                      />
                      <button
                        onClick={(e) => { e.stopPropagation(); setNamingId(null); }}
                        className="flex justify-end items-center"
                      >
                        <X className="w-4 h-4 text-muted-foreground" />
                      </button>
                    </div>
                  );
                }

                return (
                  <div className={`w-full grid grid-cols-[2.25rem_4.5rem_1fr_auto] gap-1 items-center px-2.5 py-1.5 rounded-lg border text-left transition-transform ${
                    isDragging
                      ? 'border-primary bg-card shadow-lg shadow-primary/20'
                      : 'border-border bg-card active:scale-[0.98]'
                  }`}>
                    <span className="font-bold text-base tabular-nums flex items-center gap-1">
                      {comp.bib_number}
                      {duplicateBibs.has(comp.bib_number) && (
                        <span title={t('startList.duplicateBibTooltip')} className="text-amber-500">
                          <AlertTriangle className="w-3.5 h-3.5" />
                        </span>
                      )}
                    </span>
                    <span className="text-xs text-muted-foreground tabular-nums font-mono">{comp.start_time}</span>
                    <div className="flex items-center gap-1.5 min-w-0">
                      {hasName ? (
                        <span className="text-sm truncate min-w-0">{comp.name}</span>
                      ) : permissions.canEditCompetitors ? (
                        <button
                          onClick={(e) => startNaming(comp, e)}
                          className="flex items-center gap-1.5 text-sm font-semibold text-primary min-w-0"
                        >
                          <UserPlus className="w-3.5 h-3.5 flex-shrink-0" />
                          <span className="truncate">{t('startList.addName')}</span>
                        </button>
                      ) : (
                        <span className="text-sm text-muted-foreground/50 italic truncate min-w-0">{t('startList.addNamePlaceholder')}</span>
                      )}
                    </div>
                    <div className="flex items-center justify-end gap-1.5 flex-shrink-0">
                      <SeriesBadge competitor={comp} competition={competition} />
                      {statusBadge(status)}
                    </div>
                  </div>
                );
              }}
            />
          </div>
        )}

        {/* Add competitor */}
        {permissions.canEditCompetitors && (
          !showAdd ? (
            <button
              onClick={openAddForm}
              className="w-full mt-4 h-12 rounded-xl border-2 border-dashed border-border text-muted-foreground font-bold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
            >
              <Plus className="w-4 h-4" />
              {t('startList.addCompetitor')}
            </button>
          ) : (
            <div className="mt-4 rounded-xl border border-border bg-card p-4 space-y-3">
              <p className="font-bold text-sm">{t('startList.addCompetitorTitle')}</p>
              <input
                type="number"
                value={newBib}
                onChange={e => setNewBib(e.target.value)}
                className="w-full h-10 px-3 rounded-lg bg-muted border border-border outline-none text-base"
                placeholder={t('startList.newBibNumber')}
              />
              <input
                value={newName}
                onChange={e => setNewName(e.target.value)}
                className="w-full h-10 px-3 rounded-lg bg-muted border border-border outline-none text-base"
                placeholder={t('startList.newName')}
              />
              <div>
                <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">{t('startList.newStartTime')}</label>
                <TimeInput value={newStart} onChange={setNewStart} />
              </div>
              <div className="flex gap-2">
                <button onClick={() => setShowAdd(false)} className="flex-1 h-10 rounded-lg bg-muted font-bold text-sm">{t('common.cancel')}</button>
                <button onClick={handleAdd} className="flex-1 h-10 rounded-lg bg-primary text-primary-foreground font-bold text-sm">{t('common.add')}</button>
              </div>
            </div>
          )
        )}
      </div>

      <StartListSheet
        competitor={selectedComp}
        competitionId={id}
        competition={competition}
        competitors={competitors}
        open={sheetOpen}
        onOpenChange={handleSheetChange}
        permissions={permissions}
      />
    </div>
  );
}