import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import { isGuestMode, updateGuestProfile } from '@/lib/guestMode';
import { sportLabel } from '@/lib/sportLabels';
import { Search, Users, ChevronRight, Timer, CheckCircle2, Calendar, MapPin, Globe } from 'lucide-react';
import SplitNowLogo from '@/components/brand/SplitNowLogo';

export default function Home() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');

  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me()
  });

  useEffect(() => {
    if (userLoading || !user) return;
    const params = new URLSearchParams(window.location.search);
    const joinCode = params.get('join');

    if (user.onboarding_completed) {
      if (joinCode) navigate(`/join?join=${joinCode}`);
      return;
    }
    if (localStorage.getItem('onboarding_done')) {
      if (isGuestMode()) {
        updateGuestProfile({ onboarding_completed: true });
      } else {
        base44.auth.updateMe({ onboarding_completed: true });
      }
      queryClient.setQueryData(['me'], { ...user, onboarding_completed: true });
      if (joinCode) navigate(`/join?join=${joinCode}`);
      return;
    }
    if (joinCode) {
      navigate(`/onboarding?join=${joinCode}`);
    } else {
      navigate('/onboarding');
    }
  }, [navigate, user, userLoading, queryClient]);

  const { data: publicComps = [], isLoading } = useQuery({
    queryKey: ['public-competitions'],
    queryFn: () => base44.entities.Competition.filter({ is_public: true }, '-created_date', 50),
    refetchOnWindowFocus: true,
  });

  const filtered = searchQuery.trim()
    ? publicComps.filter(c => {
        const q = searchQuery.toLowerCase();
        return (
          c.name?.toLowerCase().includes(q) ||
          c.sport?.toLowerCase().includes(q) ||
          c.location?.toLowerCase().includes(q) ||
          c.description?.toLowerCase().includes(q)
        );
      })
    : publicComps;

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="absolute top-0 left-0 right-0 h-48 bg-gradient-to-b from-primary/8 to-transparent pointer-events-none" />

      <div className="relative px-4 pt-14 pb-4">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <SplitNowLogo className="w-10 h-10 rounded-xl shadow-md shadow-primary/20 ring-1 ring-primary/10 flex-shrink-0" />
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-primary block">{t('home.brand')}</span>
                <h1 className="text-2xl font-black text-foreground leading-none">{t('home.discover')}</h1>
              </div>
            </div>
          </div>

          <div className="relative mb-4">
            <Search className="w-5 h-5 text-muted-foreground absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('home.searchPlaceholder')}
              className="w-full h-12 pl-12 pr-4 rounded-2xl bg-card border border-border text-base font-medium text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary shadow-sm"
            />
          </div>
        </div>
      </div>

      <div className="relative max-w-lg mx-auto px-4 space-y-3">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 rounded-2xl bg-card animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 rounded-3xl bg-primary/10 flex items-center justify-center mx-auto mb-5">
              <Globe className="w-9 h-9 text-primary" />
            </div>
            <p className="font-black text-lg text-foreground">{t('home.noPublicCompetitions')}</p>
            <p className="text-sm mt-1.5 text-muted-foreground max-w-xs mx-auto">{t('home.noPublicCompetitionsDesc')}</p>
          </div>
        ) : (
          filtered.map((comp) => <PublicCompCard key={comp.id} comp={comp} t={t} />)
        )}
      </div>

    </div>
  );
}

function PublicCompCard({ comp, t }) {
  const today = new Date().toISOString().split('T')[0];
  const isFinished = comp.status === 'finished';
  const isUpcoming = comp.date > today;
  const statusKey = isFinished ? 'statusFinished' : isUpcoming ? 'statusUpcoming' : 'statusActive';
  const statusColor = isFinished
    ? 'bg-red-100 text-red-600 dark:bg-red-500/20 dark:text-red-400'
    : isUpcoming
      ? 'bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400'
      : 'bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400';
  const totalCompetitors = Math.max(0, (comp.last_number || 0) - (comp.first_number || 0) + 1);

  return (
    <Link to={`/competition/${comp.id}/public`}>
      <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden transition-all active:scale-[0.98] hover:border-primary/40 hover:shadow-md">
        {comp.images && comp.images.length > 0 && (
          <div className="h-32 bg-muted overflow-hidden">
            <img src={comp.images[0]} alt={comp.name} className="w-full h-full object-cover" />
          </div>
        )}
        <div className="p-4">
          <div className="flex items-center gap-2 flex-wrap mb-1.5">
            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${statusColor}`}>
              {t(`home.${statusKey}`)}
            </span>
            {comp.sport && (
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                {sportLabel(comp.sport, t)}
              </span>
            )}
          </div>
          <h3 className="font-black text-foreground text-base mb-1">{comp.name}</h3>
          {comp.description && (
            <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{comp.description}</p>
          )}
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {comp.date ? format(new Date(comp.date), 'd.M.yyyy') : ''}
            </span>
            {comp.location && (
              <>
                <span className="w-1 h-1 rounded-full bg-muted-foreground" />
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {comp.location}
                </span>
              </>
            )}
            {totalCompetitors > 0 && (
              <>
                <span className="w-1 h-1 rounded-full bg-muted-foreground" />
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Users className="w-3 h-3" />{totalCompetitors}
                </span>
              </>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}