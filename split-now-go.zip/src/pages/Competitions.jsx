import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import CompetitionsHeader from '@/components/competitions/CompetitionsHeader';
import CompetitionsSection from '@/components/competitions/CompetitionsSection';
import CompetitionsEmptyState from '@/components/competitions/CompetitionsEmptyState';
import GuestLoginOverlay from '@/components/GuestLoginOverlay';
import { getCompetitionPhase } from '@/lib/competitionSections';

export default function Competitions() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');

  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me()
  });

  const isGuest = user?.is_guest;

  const { data: memberships = [], isLoading: membershipsLoading } = useQuery({
    queryKey: ['my-memberships', user?.id],
    queryFn: () => base44.entities.CompetitionMember.filter({ user_id: user.id }),
    enabled: !!user?.id && !isGuest
  });

  const { data: createdComps = [], isLoading: createdLoading } = useQuery({
    queryKey: ['my-created-competitions', user?.id],
    queryFn: () => base44.entities.Competition.filter({ created_by_id: user.id }, '-created_date'),
    enabled: !!user?.id && !isGuest
  });

  const memberCompIds = memberships.map((m) => m.competition_id);
  const { data: memberComps = [], isLoading: memberLoading } = useQuery({
    queryKey: ['my-member-competitions', memberCompIds],
    queryFn: () => base44.entities.Competition.filter({ id: { $in: memberCompIds } }, '-created_date'),
    enabled: memberCompIds.length > 0
  });

  const roleByCompId = {};
  memberships.forEach((m) => { roleByCompId[m.competition_id] = m.role; });
  createdComps.forEach((c) => { if (!roleByCompId[c.id]) roleByCompId[c.id] = 'owner'; });

  const myCompetitions = createdComps;
  const joinedCompetitions = memberComps.filter(
    (comp) => !createdComps.some((mine) => mine.id === comp.id)
  );

  const matchesSearch = (comp) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
    return (
      comp.name?.toLowerCase().includes(query) ||
      comp.sport?.toLowerCase().includes(query) ||
      comp.location?.toLowerCase().includes(query)
    );
  };

  const filteredMy = myCompetitions.filter(matchesSearch);
  const filteredJoined = joinedCompetitions.filter(matchesSearch);
  const totalCount = myCompetitions.length + joinedCompetitions.length;
  const hasSearch = searchQuery.trim().length > 0;
  const noMatches = filteredMy.length === 0 && filteredJoined.length === 0;

  // The next upcoming competition is highlighted once: in the owned section when it
  // has one, otherwise in the joined section.
  const myHasUpcoming = filteredMy.some((comp) => getCompetitionPhase(comp) === 'upcoming');

  const showLoading = userLoading || membershipsLoading || createdLoading || (memberCompIds.length > 0 && memberLoading);

  return (
    <div className="relative min-h-screen bg-background pb-24">
      <div className={isGuest ? 'pointer-events-none select-none blur-[2px] opacity-50' : ''}>
        <CompetitionsHeader
          totalCount={totalCount}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          isGuest={isGuest}
        />

        <div className="mx-auto max-w-lg space-y-7 px-4 pt-5">
          {showLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 rounded-2xl bg-card animate-pulse" />
              ))}
            </div>
          ) : hasSearch && noMatches ? (
            <p className="py-12 text-center text-sm font-medium text-muted-foreground">
              {t('competitions.noMatches')}
            </p>
          ) : totalCount === 0 ? (
            <CompetitionsEmptyState />
          ) : (
            <>
              <CompetitionsSection
                title={t('competitions.myCompetitions')}
                competitions={filteredMy}
                roleByCompId={roleByCompId}
                highlightNext={myHasUpcoming}
              />
              <CompetitionsSection
                title={t('competitions.joinedCompetitions')}
                competitions={filteredJoined}
                roleByCompId={roleByCompId}
                highlightNext={!myHasUpcoming}
              />
            </>
          )}
        </div>
      </div>

      {isGuest && <GuestLoginOverlay message={t('guest.loginToManageDesc')} />}
    </div>
  );
}