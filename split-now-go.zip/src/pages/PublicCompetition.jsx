import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import {
  ArrowLeft, Trophy, List, Calendar, MapPin, Users, Loader2, Check, Globe, UserCircle, LogIn
} from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import CompetitionNav from '@/components/competition/CompetitionNav';
import RouteView from '@/components/route/RouteView';
import { isGuestMode } from '@/lib/guestMode';
import { sportLabel } from '@/lib/sportLabels';
import { useAuth } from '@/lib/AuthContext';

export default function PublicCompetition() {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const [joining, setJoining] = useState(false);
  const [showRouteView, setShowRouteView] = useState(false);
  const [showLoginRequired, setShowLoginRequired] = useState(false);
  const { navigateToLogin } = useAuth();

  const { data: user } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me()
  });

  const { data: competition, isLoading } = useQuery({
    queryKey: ['competition', id],
    queryFn: () => base44.entities.Competition.filter({ id }),
    select: (data) => data[0]
  });

  const { data: members = [] } = useQuery({
    queryKey: ['members', id],
    queryFn: () => base44.entities.CompetitionMember.filter({ competition_id: id }),
    enabled: !!id
  });

  const myMembership = members.find(m => m.user_id === user?.id);
  const isJoined = !!myMembership;
  const owners = members.filter(m => m.role === 'owner');

  const handleJoin = async () => {
    if (isGuestMode()) {
      setShowLoginRequired(true);
      return;
    }
    setJoining(true);
    const me = await base44.auth.me();
    await base44.entities.CompetitionMember.create({
      competition_id: id,
      user_id: me.id,
      user_email: me.email,
      user_name: me.display_name || me.full_name || me.email,
      role: competition?.default_join_role || 'viewer',
    });
    queryClient.invalidateQueries({ queryKey: ['members', id] });
    queryClient.invalidateQueries({ queryKey: ['my-membership', id, me.id] });
    queryClient.invalidateQueries({ queryKey: ['competitions'] });
    setJoining(false);
  };

  const handleLeave = async () => {
    setShowLeaveConfirm(false);
    if (!myMembership) return;
    await base44.entities.CompetitionMember.delete(myMembership.id);
    queryClient.invalidateQueries({ queryKey: ['members', id] });
    queryClient.invalidateQueries({ queryKey: ['my-membership', id, user?.id] });
    queryClient.invalidateQueries({ queryKey: ['competitions'] });
    queryClient.removeQueries({ queryKey: ['my-memberships', user?.id] });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!competition) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 text-center">
        <p className="font-black text-lg text-foreground">{t('home.noCompetitions')}</p>
        <button onClick={() => navigate('/')} className="mt-4 text-primary font-bold text-sm">
          {t('common.back')}
        </button>
      </div>
    );
  }

  const totalCompetitors = Math.max(0, (competition.last_number || 0) - (competition.first_number || 0) + 1);

  return (
    <div className="min-h-screen bg-background">
      <CompetitionNav competition={competition} />

      <div className="max-w-lg mx-auto px-4 py-4 pb-10">
        {competition.images && competition.images.length > 0 && (
          <div className="h-48 rounded-2xl overflow-hidden mb-4">
            <img src={competition.images[0]} alt={competition.name} className="w-full h-full object-cover" />
          </div>
        )}

        <div className="bg-card rounded-2xl border border-border p-5 mb-4">
          <h1 className="text-2xl font-black text-foreground mb-2">{competition.name}</h1>

          <div className="flex items-center gap-2 flex-wrap mb-3">
            {competition.sport && (
              <span className="text-xs font-bold px-2 py-1 rounded-full bg-primary/10 text-primary">
                {sportLabel(competition.sport, t)}
              </span>
            )}
            <span className="text-xs font-bold px-2 py-1 rounded-full bg-muted text-muted-foreground flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {competition.date ? format(new Date(competition.date), 'd.M.yyyy') : ''}
            </span>
            {competition.location && (
              <span className="text-xs font-bold px-2 py-1 rounded-full bg-muted text-muted-foreground flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                {competition.location}
              </span>
            )}
          </div>

          {competition.description && (
            <p className="text-sm text-muted-foreground leading-relaxed">{competition.description}</p>
          )}

          {totalCompetitors > 0 && (
            <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-border">
              <Users className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-semibold text-foreground">{totalCompetitors}</span>
              <span className="text-sm text-muted-foreground">{t('home.active').toLowerCase()}</span>
            </div>
          )}
        </div>

        {competition.route_preview_url && competition.route_data && (
          <button
            onClick={() => setShowRouteView(true)}
            className="w-full rounded-2xl overflow-hidden border border-border mb-4 active:scale-[0.99] transition-all"
          >
            <img src={competition.route_preview_url} alt={t('route.title')} className="w-full h-40 object-cover" />
          </button>
        )}

        <div className="grid grid-cols-2 gap-3 mb-4">
          <Link to={`/competition/${id}/results`}>
            <div className="h-14 rounded-2xl bg-card border border-border flex items-center justify-center gap-2 font-bold text-foreground text-sm shadow-sm active:scale-[0.98] transition-transform">
              <Trophy className="w-5 h-5 text-primary" />
              {t('publicCompetition.liveResults')}
            </div>
          </Link>
          <Link to={`/competition/${id}/startlist`}>
            <div className="h-14 rounded-2xl bg-card border border-border flex items-center justify-center gap-2 font-bold text-foreground text-sm shadow-sm active:scale-[0.98] transition-transform">
              <List className="w-5 h-5 text-primary" />
              {t('publicCompetition.startList')}
            </div>
          </Link>
        </div>

        {isJoined ? (
          myMembership?.role === 'owner' ? (
            <div className="w-full h-14 rounded-2xl bg-primary/10 text-primary font-bold text-base flex items-center justify-center gap-2 mb-4">
              <Check className="w-5 h-5" />
              {t('publicCompetition.joined')}
            </div>
          ) : (
            <button
              onClick={() => setShowLeaveConfirm(true)}
              className="w-full h-14 rounded-2xl bg-primary/10 text-primary font-bold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform mb-4"
            >
              <Check className="w-5 h-5" />
              {t('publicCompetition.joined')}
            </button>
          )
        ) : (
          <button
            onClick={handleJoin}
            disabled={joining}
            className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-black text-base shadow-xl shadow-primary/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-transform mb-4"
          >
            {joining ? <Loader2 className="w-5 h-5 animate-spin" /> : <UserCircle className="w-5 h-5" />}
            {t('publicCompetition.join')}
          </button>
        )}

        {owners.length > 0 && (
          <div className="bg-card rounded-2xl border border-border p-4">
            <p className="text-xs font-black uppercase tracking-widest text-muted-foreground mb-3">
              {t('publicCompetition.organizers')}
            </p>
            <div className="space-y-2">
              {owners.map(owner => (
                <button
                  key={owner.id}
                  onClick={() => navigate(`/profile/${owner.user_id}`)}
                  className="w-full flex items-center gap-3 active:opacity-70 transition-opacity"
                >
                  <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center">
                    <span className="text-primary font-black text-sm">
                      {(owner.user_name || '?')[0].toUpperCase()}
                    </span>
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-bold text-sm text-foreground">{owner.user_name || '—'}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <AlertDialog open={showLeaveConfirm} onOpenChange={setShowLeaveConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('publicCompetition.leaveConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('publicCompetition.leaveConfirmDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleLeave} className="bg-destructive text-destructive-foreground">
              {t('publicCompetition.leave')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {showRouteView && (
        <RouteView routeDataStr={competition.route_data} onClose={() => setShowRouteView(false)} t={t} />
      )}

      <AlertDialog open={showLoginRequired} onOpenChange={setShowLoginRequired}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('guest.loginRequired')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('guest.joinCompetitionRequiresLogin')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex flex-col gap-3 mt-2">
            <button
              onClick={() => {
                navigateToLogin();
              }}
              className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-black text-base shadow-xl shadow-primary/30 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
            >
              <LogIn className="w-5 h-5" />
              {t('guest.login')}
            </button>
            <button
              onClick={() => setShowLoginRequired(false)}
              className="w-full h-14 rounded-2xl bg-card border border-border text-foreground font-bold text-base active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
            >
              {t('guest.cancel')}
            </button>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}