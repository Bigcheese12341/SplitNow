import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import CompetitionNav from '@/components/competition/CompetitionNav';
import { Flag, Timer, Clock, Check, Users, AlertCircle, MapPin, ImagePlus, ListPlus, Lock, Globe, FileText } from 'lucide-react';
import { detectStartFormat, normalizeTime, hasSecondPrecision } from '@/lib/timeUtils';
import StartListUpload from '@/components/startlist/StartListUpload';
import {
  recognizeStartListImage,
  buildCompetitors,
  inferCategorization,
  applyManualSeries,
  applyManualSeriesToRows,
  countDuplicates,
  rowKeyOf,
  syncSeriesLabels
} from '@/lib/startListRecognition';
import StartTimeInput from '@/components/competition/StartTimeInput';
import SecondsPrecisionToggle from '@/components/competition/SecondsPrecisionToggle';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from
'@/components/ui/alert-dialog';
import { ROLE_STYLES } from '@/lib/roleStyles';
import { useUserRole } from '@/lib/permissions';
import RouteSection from '@/components/route/RouteSection';
import SportSelect from '@/components/competition/SportSelect';
import SplitNamesEditor from '@/components/competition/SplitNamesEditor';
import { normalizeSplitNames } from '@/lib/splitLabels';
import { remapSplitTimes } from '@/lib/competitionStructure';

export default function EditCompetitionForm() {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { permissions, role } = useUserRole(id);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState(null);
  const [numberMode, setNumberMode] = useState(null);
  const [manualNumbers, setManualNumbers] = useState('');
  const [uploadedCompetitors, setUploadedCompetitors] = useState([]);
  const [uploadedImages, setUploadedImages] = useState([]);
  const [recognizedPages, setRecognizedPages] = useState({});
  const [uploading, setUploading] = useState(false);
  const [showPrivacyConfirm, setShowPrivacyConfirm] = useState(false);

  const { data: competition } = useQuery({
    queryKey: ['competition', id],
    queryFn: () => base44.entities.Competition.filter({ id }),
    select: (data) => data[0]
  });

  const { data: existingCompetitors = [] } = useQuery({
    queryKey: ['competitors', id],
    queryFn: () => base44.entities.Competitor.filter({ competition_id: id }, 'bib_number'),
  });

  useEffect(() => {
    if (competition && !form) {
      setForm({
        name: competition.name || '',
        date: competition.date || new Date().toISOString().split('T')[0],
        start_time: normalizeTime(competition.start_time),
        start_interval: competition.start_interval || 30,
        split_count: competition.split_count || 1,
        add_finish: competition.add_finish || false,
        format: competition.format || 'interval',
        first_number: competition.first_number || 1,
        last_number: competition.last_number || 30,
        is_public: competition.is_public || false,
        description: competition.description || '',
        sport: competition.sport || '',
        location: competition.location || '',
        route_data: competition.route_data || null,
        route_preview_url: competition.route_preview_url || null,
        gender_categorization: competition.gender_categorization || false,
        age_categorization: competition.age_categorization || false,
        seconds_precision: competition.seconds_precision || false,
        edit_split_names: competition.edit_split_names || false,
        split_names: Array.isArray(competition.split_names) ? competition.split_names : []
      });
    }
  }, [competition]);

  const handleChange = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const parseManualNumbers = (str) => {
    const numbers = new Set();
    str.split(/[,\s]+/).forEach(part => {
      part = part.trim();
      if (!part) return;
      if (part.includes('-')) {
        const [a, b] = part.split('-').map(Number);
        if (!isNaN(a) && !isNaN(b)) {
          for (let i = Math.min(a, b); i <= Math.max(a, b); i++) numbers.add(i);
        }
      } else {
        const n = Number(part);
        if (!isNaN(n)) numbers.add(n);
      }
    });
    return Array.from(numbers).sort((a, b) => a - b);
  };

  // Same recognition as in the competition creation form: every page is read on
  // its own, then all pages together, so a series printed on one page carries
  // over to the pages that continue the same list.
  const handleFilesSelected = async (files) => {
    if (files.length === 0) return;
    setUploading(true);
    try {
      const uploadResults = await Promise.all(
        files.map(file => base44.integrations.Core.UploadFile({ file }))
      );
      const fileUrls = uploadResults.map(r => r.file_url).filter(Boolean);
      setUploadedImages(prev => [...prev, ...fileUrls]);

      const pages = await Promise.all(fileUrls.map(url => recognizeStartListImage(url)));
      const nextPages = { ...recognizedPages };
      fileUrls.forEach((url, i) => { nextPages[url] = pages[i]; });
      setRecognizedPages(nextPages);

      const orderedPages = [...uploadedImages, ...fileUrls].map(url => nextPages[url]).filter(Boolean);
      const competitors = buildCompetitors(orderedPages, uploadedCompetitors);
      setUploadedCompetitors(competitors);

      const { hasGender, hasAge } = inferCategorization(competitors);
      const detected = detectStartFormat(competitors);
      // Start times read from the list already carry their seconds. When any of
      // them is not a flat minute (09:00:15), second precision is switched on so
      // those seconds can be kept exactly; flat minute times leave it alone.
      const hasSeconds = competitors.some((c) => hasSecondPrecision(c.start_time));
      setForm(prev => ({
        ...prev,
        gender_categorization: prev.gender_categorization || hasGender,
        age_categorization: prev.age_categorization || hasAge,
        ...(hasSeconds ? { seconds_precision: true } : {}),
        ...(detected
          ? {
            format: detected.format,
            start_interval: detected.start_interval,
            start_time: normalizeTime(detected.start_time)
          }
          : {})
      }));
    } catch (err) {
      console.error('Start list recognition failed', err);
    }
    setUploading(false);
  };

  const handleRemoveImage = (url) => setUploadedImages(prev => prev.filter(u => u !== url));

  // A series the user filled in also needs its classification switched on.
  const enableCategorization = (next) => {
    const { hasGender, hasAge } = inferCategorization(next);
    setForm(prev => ({
      ...prev,
      gender_categorization: prev.gender_categorization || hasGender,
      age_categorization: prev.age_categorization || hasAge
    }));
  };

  // The classification switches only decide what the competition filters on;
  // they never edit the stored data, but every competitor already in the list
  // follows them at once so no image has to be read again.
  useEffect(() => {
    if (!form) return;
    setUploadedCompetitors(prev => syncSeriesLabels(prev));
  }, [form?.gender_categorization, form?.age_categorization]);

  // A correction by hand is final: it is marked as manual so no later automatic
  // pass overwrites it. Rows are identified by their row key, so a competitor
  // whose bib number is still missing can be corrected too.
  const handleSaveCompetitor = (key, patch) => {
    const next = uploadedCompetitors.map(c => (rowKeyOf(c) === key ? applyManualSeries(c, patch) : c));
    setUploadedCompetitors(next);
    enableCategorization(next);
  };

  // One series for a whole selected range, e.g. a block read from an image that
  // carried no heading.
  const handleSetSeries = (keys, patch) => {
    const next = applyManualSeriesToRows(uploadedCompetitors, keys, patch);
    setUploadedCompetitors(next);
    enableCategorization(next);
  };

  const handleRemoveCompetitor = (key) => {
    setUploadedCompetitors(prev => prev.filter(c => rowKeyOf(c) !== key));
  };

  const computeNewCompetitors = () => {
    const existingBibs = new Set(existingCompetitors.map(c => c.bib_number));
    const startTimeFull = normalizeTime(form.start_time);
    const startSec = parseTime(startTimeFull);
    const interval = form.format === 'mass_start' ? 0 : Number(form.start_interval);
    const configs = [];

    if (numberMode === 'manual') {
      parseManualNumbers(manualNumbers).forEach((num) => {
        if (!existingBibs.has(num)) {
          const start = form.format === 'mass_start' ? startSec : startSec + (num - 1) * interval;
          configs.push({ bib_number: num, name: '', start_time: formatSeconds(start) });
        }
      });
    } else if (numberMode === 'upload') {
      uploadedCompetitors.forEach((c) => {
        if (c.bib_number === null || c.bib_number === undefined) return;
        if (!existingBibs.has(c.bib_number)) {
          const start = c.start_time || formatSeconds(form.format === 'mass_start' ? startSec : startSec + (c.bib_number - 1) * interval);
          const config = { bib_number: c.bib_number, name: c.name || '', start_time: start };
          if (c.gender === 'male' || c.gender === 'female') config.gender = c.gender;
          const age = Number(c.age);
          if (Number.isFinite(age) && age > 0) config.age = Math.round(age);
          if (c.series) config.series = c.series;
          if (c.printed_series) config.printed_series = c.printed_series;
          configs.push(config);
        }
      });
    } else {
      for (let i = Number(form.first_number); i <= Number(form.last_number); i++) {
        if (!existingBibs.has(i)) {
          const start = form.format === 'mass_start' ? startSec : startSec + (i - 1) * interval;
          configs.push({ bib_number: i, name: '', start_time: formatSeconds(start) });
        }
      }
    }
    return configs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (competition && form.is_public !== (competition.is_public || false)) {
      setShowPrivacyConfirm(true);
      return;
    }
    await doSave();
  };

  const doSave = async () => {
    setShowPrivacyConfirm(false);
    setSaving(true);
    const startTimeFull = normalizeTime(form.start_time);

    const newCompetitorConfigs = computeNewCompetitors();

    let firstNumber = Number(form.first_number);
    let lastNumber = Number(form.last_number);
    if (numberMode === 'manual') {
      const nums = parseManualNumbers(manualNumbers);
      if (nums.length > 0) { firstNumber = Math.min(...nums); lastNumber = Math.max(...nums); }
    } else if (numberMode === 'upload' && uploadedCompetitors.length > 0) {
      const nums = uploadedCompetitors.map(c => c.bib_number);
      firstNumber = Math.min(...nums); lastNumber = Math.max(...nums);
    }

    await base44.entities.Competition.update(id, {
      name: form.name,
      date: form.date,
      start_time: startTimeFull,
      seconds_precision: form.seconds_precision || false,
      start_interval: form.format === 'mass_start' ? 0 : Number(form.start_interval),
      split_count: Number(form.split_count),
      add_finish: form.add_finish,
      format: form.format,
      first_number: firstNumber,
      last_number: lastNumber,
      is_public: form.is_public,
      description: form.description || '',
      sport: form.sport || '',
      location: form.location || '',
      route_data: form.route_data || '',
      route_preview_url: form.route_preview_url || '',
      gender_categorization: form.gender_categorization || false,
      age_categorization: form.age_categorization || false,
      edit_split_names: form.edit_split_names || false,
      split_names: normalizeSplitNames(form.split_names, form.split_count)
    });

    // The number of split points and the finish are two separate things: changing
    // the split count only removes or adds split points and never drops the finish.
    const oldSplitCount = competition?.split_count || 1;
    const oldAddFinish = !!competition?.add_finish;
    const newSplitCount = Number(form.split_count);
    const newAddFinish = !!form.add_finish;

    if (oldSplitCount !== newSplitCount || oldAddFinish !== newAddFinish) {
      const structureUpdates = existingCompetitors
        .map((competitor) => {
          const remapped = remapSplitTimes(competitor.split_times, {
            oldSplitCount,
            oldAddFinish,
            newSplitCount,
            newAddFinish
          });
          return remapped === competitor.split_times
            ? null
            : { id: competitor.id, split_times: remapped };
        })
        .filter(Boolean);
      for (let i = 0; i < structureUpdates.length; i += 50) {
        await base44.entities.Competitor.bulkUpdate(structureUpdates.slice(i, i + 50));
      }
    }

    if (newCompetitorConfigs.length > 0) {
      const competitors = newCompetitorConfigs.map(c => ({
        ...c,
        competition_id: id,
        status: 'active',
        split_times: []
      }));
      for (let i = 0; i < competitors.length; i += 50) {
        await base44.entities.Competitor.bulkCreate(competitors.slice(i, i + 50));
      }
    }

    queryClient.removeQueries({ queryKey: ['competition', id] });
    queryClient.invalidateQueries({ queryKey: ['competitions'] });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
    setSaving(false);
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      navigate(`/competition/${id}/startlist`);
    }, 1000);
  };

  if (!form) {
    return (
      <div className="min-h-screen bg-background">
        <CompetitionNav competition={competition} />
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  const canEdit = permissions.canEditCompetition;
  const newCompetitorCount = computeNewCompetitors().length;
  const roleStyle = ROLE_STYLES[role] || ROLE_STYLES.viewer;
  const roleLabel = t(`members.role${role.charAt(0).toUpperCase() + role.slice(1)}`);

  return (
    <div className="min-h-screen bg-background">
      <CompetitionNav competition={competition} />

      <div className="max-w-lg mx-auto px-4 py-4 pb-10">
        <div className={`flex items-center gap-2 rounded-2xl px-4 py-3 mb-4 border ${roleStyle.bg} ${roleStyle.border}`}>
          <span className={`font-black text-sm ${roleStyle.accent}`}>{roleLabel}</span>
        </div>
        <h2 className="text-xl font-black text-foreground mb-4">{t('edit.title')}</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Section icon={<Flag className="w-4 h-4" />} title={t('edit.basicInfo')}>
            <Field label={t('edit.compName')}>
              <Input
                value={form.name}
                onChange={(e) => handleChange('name', e.target.value)}
                required
                disabled={!canEdit}
                className="h-12 rounded-xl text-base" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t('edit.date')}>
                <Input type="date" value={form.date} onChange={(e) => handleChange('date', e.target.value)} required disabled={!canEdit} className="h-12 rounded-xl text-base" />
              </Field>
              <Field
                label={t('edit.startTime')}
                className={form.seconds_precision ? 'col-span-2' : ''}
              >
                <StartTimeInput
                  value={form.start_time}
                  onChange={(v) => handleChange('start_time', v)}
                  secondsPrecision={form.seconds_precision}
                  disabled={!canEdit}
                  className="h-12 rounded-xl text-base"
                />
              </Field>
            </div>
            <SecondsPrecisionToggle
              checked={form.seconds_precision}
              onChange={(checked) => handleChange('seconds_precision', checked)}
              disabled={!canEdit}
            />
          </Section>

          <Section icon={<Users className="w-4 h-4" />} title={t('create.startList')}>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setNumberMode(numberMode === 'manual' ? null : 'manual')}
                disabled={!canEdit}
                className={`h-12 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                  numberMode === 'manual' ? 'bg-primary text-primary-foreground shadow-md' : 'bg-muted text-foreground'
                }`}
              >
                <ListPlus className="w-4 h-4" />
                {t('create.selectNumbers')}
              </button>
              <button
                type="button"
                onClick={() => setNumberMode(numberMode === 'upload' ? null : 'upload')}
                disabled={!canEdit}
                className={`h-12 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                  numberMode === 'upload' ? 'bg-primary text-primary-foreground shadow-md' : 'bg-muted text-foreground'
                }`}
              >
                <ImagePlus className="w-4 h-4" />
                {t('create.uploadStartList')}
              </button>
            </div>

            {numberMode === null && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <Field label={t('create.firstNumber')}>
                    <Input type="number" min="1" value={form.first_number} onChange={(e) => handleChange('first_number', e.target.value)} disabled={!canEdit} className="h-12 rounded-xl text-base" />
                  </Field>
                  <Field label={t('create.lastNumber')}>
                    <Input type="number" min="1" value={form.last_number} onChange={(e) => handleChange('last_number', e.target.value)} disabled={!canEdit} className="h-12 rounded-xl text-base" />
                  </Field>
                </div>
                <div className="flex items-center justify-center py-2 bg-muted rounded-xl">
                  <span className="text-sm font-semibold text-muted-foreground">
                    {existingCompetitors.length} {t('edit.existingCompetitors')}
                  </span>
                </div>
                {newCompetitorCount > 0 && (
                  <div className="flex items-center justify-center py-2 bg-primary/5 rounded-xl">
                    <span className="text-sm font-semibold text-primary">
                      {t('edit.newCompetitors', { count: newCompetitorCount })}
                    </span>
                  </div>
                )}
              </>
            )}

            {numberMode === 'manual' && (
              <Field label={t('create.numbersInput')}>
                <Input
                  value={manualNumbers}
                  onChange={(e) => setManualNumbers(e.target.value)}
                  disabled={!canEdit}
                  placeholder={t('create.numbersInputPlaceholder')}
                  className="h-12 rounded-xl text-base"
                />
                <p className="text-xs text-muted-foreground mt-1.5">{t('create.numbersInputHint')}</p>
                <div className="flex items-center justify-center py-2 bg-primary/5 rounded-xl mt-2">
                  <span className="text-sm font-semibold text-primary">
                    {t('edit.newCompetitors', { count: newCompetitorCount })}
                  </span>
                </div>
              </Field>
            )}

            {numberMode === 'upload' && (
              <div className="space-y-3">
                <StartListUpload
                  images={uploadedImages}
                  competitors={uploadedCompetitors}
                  duplicates={countDuplicates(Object.values(recognizedPages), uploadedCompetitors)}
                  uploading={uploading}
                  onFilesSelected={handleFilesSelected}
                  onRemoveImage={handleRemoveImage}
                  onSaveCompetitor={handleSaveCompetitor}
                  onRemoveCompetitor={handleRemoveCompetitor}
                  onSetSeries={handleSetSeries}
                />
                <div className="flex items-center justify-center py-2 bg-primary/5 rounded-xl">
                  <span className="text-sm font-semibold text-primary">
                    {t('edit.newCompetitors', { count: newCompetitorCount })}
                  </span>
                </div>
              </div>
            )}

            <div className="space-y-3 pt-3 border-t border-border">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm">{t('create.genderCategorization')}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{t('create.genderCategorizationSub')}</div>
                </div>
                <Switch
                  checked={form.gender_categorization}
                  onCheckedChange={(checked) => handleChange('gender_categorization', checked)}
                  disabled={!canEdit}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm">{t('create.ageCategorization')}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{t('create.ageCategorizationSub')}</div>
                </div>
                <Switch
                  checked={form.age_categorization}
                  onCheckedChange={(checked) => handleChange('age_categorization', checked)}
                  disabled={!canEdit}
                />
              </div>
            </div>
          </Section>

          <Section icon={<Timer className="w-4 h-4" />} title={t('edit.format')}>
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: 'interval', label: t('edit.intervalStart'), sub: t('edit.intervalStartSub') },
                { value: 'mass_start', label: t('edit.massStart'), sub: t('edit.massStartSub') }
              ].map((opt) =>
              <button
                key={opt.value}
                type="button"
                onClick={() => handleChange('format', opt.value)}
                disabled={!canEdit}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                form.format === opt.value ? 'border-primary bg-primary/5' : 'border-border bg-card'}`
                }>
                <div className="font-bold text-sm">{opt.label}</div>
              </button>
              )}
            </div>

            {form.format === 'interval' &&
            <div>
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{t('edit.startInterval')}</Label>
                <div className="flex gap-2 mt-2">
                  {[15, 20, 30].map((val) =>
                <button
                  key={val}
                  type="button"
                  onClick={() => handleChange('start_interval', val)}
                  disabled={!canEdit}
                  className={`flex-1 h-11 rounded-xl font-bold text-sm transition-all ${
                  Number(form.start_interval) === val ?
                  'bg-primary text-primary-foreground shadow-md' :
                  'bg-muted text-foreground'}`
                  }>
                    {val}s
                  </button>
                )}
                </div>
                <Input
                type="number" min="1"
                value={form.start_interval}
                onChange={(e) => handleChange('start_interval', e.target.value)}
                disabled={!canEdit}
                className="mt-2 h-11 rounded-xl text-base"
                placeholder={t('edit.otherValue')} />
            </div>
            }
          </Section>

          <Section icon={<Clock className="w-4 h-4" />} title={t('edit.splits')}>
            <Field label={t('edit.splitCount')}>
              <div className="flex gap-2">
                {[1, 2, 3].map((val) =>
                <button
                  key={val}
                  type="button"
                  onClick={() => handleChange('split_count', val)}
                  disabled={!canEdit}
                  className={`flex-1 h-11 rounded-xl font-bold text-sm transition-all ${
                  Number(form.split_count) === val ?
                  'bg-primary text-primary-foreground shadow-md' :
                  'bg-muted text-foreground'}`
                  }>
                    {val}
                  </button>
                )}
                <Input
                  type="number" min="1" max="10"
                  value={form.split_count}
                  onChange={(e) => handleChange('split_count', e.target.value)}
                  disabled={!canEdit}
                  className="h-11 rounded-xl text-base w-20" />
              </div>
            </Field>
            <SplitNamesEditor
              enabled={form.edit_split_names}
              names={form.split_names}
              splitCount={form.split_count}
              disabled={!canEdit}
              onChange={(enabled, names) => setForm(prev => ({ ...prev, edit_split_names: enabled, split_names: names }))}
            />
          </Section>

          <Section icon={<MapPin className="w-4 h-4" />} title={t('edit.finish')}>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-sm">{t('edit.addFinish')}</div>
                <div className="text-xs text-muted-foreground">{t('edit.addFinishSub')}</div>
              </div>
              <Switch
                checked={form.add_finish}
                onCheckedChange={(checked) => handleChange('add_finish', checked)}
                disabled={!canEdit}
              />
            </div>
          </Section>

          <RouteSection
            routeData={form.route_data}
            routePreviewUrl={form.route_preview_url}
            splitCount={Number(form.split_count)}
            addFinish={form.add_finish}
            canEdit={canEdit}
            onSave={async (data, preview) => {
              setForm(prev => ({ ...prev, route_data: data, route_preview_url: preview || prev.route_preview_url }));
              await base44.entities.Competition.update(id, {
                route_data: data,
                ...(preview ? { route_preview_url: preview } : {})
              });
              queryClient.invalidateQueries({ queryKey: ['competition', id] });
            }}
            onDelete={async () => {
              setForm(prev => ({ ...prev, route_data: null, route_preview_url: null }));
              await base44.entities.Competition.update(id, { route_data: '', route_preview_url: '' });
              queryClient.invalidateQueries({ queryKey: ['competition', id] });
            }}
            t={t}
          />

          <Section icon={form.is_public ? <Globe className="w-4 h-4" /> : <Lock className="w-4 h-4" />} title={t('edit.privacy')}>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleChange('is_public', false)}
                disabled={!canEdit}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  !form.is_public ? 'border-primary bg-primary/5' : 'border-border bg-card'
                }`}
              >
                <Lock className={`w-4 h-4 mb-1.5 ${!form.is_public ? 'text-primary' : 'text-muted-foreground'}`} />
                <div className="font-bold text-sm">{t('edit.private')}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{t('edit.privateDesc')}</div>
              </button>
              <button
                type="button"
                onClick={() => handleChange('is_public', true)}
                disabled={!canEdit}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  form.is_public ? 'border-primary bg-primary/5' : 'border-border bg-card'
                }`}
              >
                <Globe className={`w-4 h-4 mb-1.5 ${form.is_public ? 'text-primary' : 'text-muted-foreground'}`} />
                <div className="font-bold text-sm">{t('edit.public')}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{t('edit.publicDesc')}</div>
              </button>
            </div>
          </Section>

          {form.is_public && (
            <Section icon={<FileText className="w-4 h-4" />} title={t('edit.publicPageInfo')}>
              <Field label={t('edit.sport')}>
                <SportSelect
                  value={form.sport}
                  onChange={(v) => handleChange('sport', v)}
                  disabled={!canEdit}
                />
              </Field>
              <Field label={t('edit.location')}>
                <Input
                  value={form.location}
                  onChange={(e) => handleChange('location', e.target.value)}
                  disabled={!canEdit}
                  className="h-12 rounded-xl text-base"
                />
              </Field>
              <Field label={t('edit.description')}>
                <textarea
                  value={form.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  disabled={!canEdit}
                  placeholder={t('edit.descriptionPlaceholder')}
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl bg-transparent border border-input text-base text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring resize-none disabled:opacity-50"
                />
              </Field>
            </Section>
          )}

          {canEdit && (
            <Button
              type="submit"
              disabled={saving || saved || !form.name}
              className="w-full h-14 text-lg font-bold rounded-2xl shadow-lg shadow-primary/25">
              {saved ?
              <span className="flex items-center gap-2"><Check className="w-5 h-5" /> {t('edit.saved')}</span> :
              saving ? t('edit.saving') : t('edit.save')}
            </Button>
          )}
        </form>
      </div>

      <AlertDialog open={showPrivacyConfirm} onOpenChange={setShowPrivacyConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('edit.privacyConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('edit.privacyConfirmDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={doSave}>
              {t('common.confirm')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Section({ icon, title, children }) {
  return (
    <div className="bg-card rounded-2xl border border-border p-4 space-y-3">
      <div className="flex items-center gap-2 text-sm font-bold text-foreground">
        <span className="text-primary">{icon}</span>
        {title}
      </div>
      {children}
    </div>
  );
}

function Field({ label, children, className }) {
  return (
    <div className={`space-y-1.5 ${className || ''}`}>
      <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</Label>
      {children}
    </div>
  );
}

function parseTime(timeStr) {
  const parts = timeStr.split(':').map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 3600 + parts[1] * 60;
  return 0;
}

function formatSeconds(totalSec) {
  const wrapped = ((totalSec % 86400) + 86400) % 86400;
  const h = Math.floor(wrapped / 3600);
  const m = Math.floor((wrapped % 3600) / 60);
  const s = wrapped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}