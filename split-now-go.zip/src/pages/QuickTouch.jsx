import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import CompetitionNav from '@/components/competition/CompetitionNav';
import QuickTouchStatusBar from '@/components/competition/QuickTouchStatusBar';
import QuickTouchGrid from '@/components/competition/QuickTouchGrid';
import LiveResultsPanel from '@/components/competition/LiveResultsPanel';
import { useToast } from '@/components/ui/use-toast';
import QuickTouchCompetitorSheet from '@/components/competition/QuickTouchCompetitorSheet';
import { useUserRole } from '@/lib/permissions';
import { parseTimeToSeconds, nowInSeconds } from '@/lib/timeUtils';
import { groupKey, groupLabel } from '@/lib/seriesUtils';
import { useSeriesPalette } from '@/lib/seriesPalette';
import { computeStandings, bestTimeInGroup } from '@/lib/comparisonUtils';
import { hapticPress } from '@/lib/haptics';
import { execOrQueue, cacheData, getCachedData, updateCachedCompetitor, removeCachedCompetitor, subscribe, isOnline } from '@/lib/syncQueue';
import { getTotalPoints, getCompetitorProgress, getNextSplitIndex, isFullyRecorded, getDismissed, dismissCompetitor, undismissCompetitor } from '@/lib/quickTouchPrefs';

export default function QuickTouch() {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const { permissions, user, isLoading: roleLoading } = useUserRole(id);
  const queryClient = useQueryClient();

  const [currentTime, setCurrentTime] = useState(nowInSeconds());
  const [lastEntry, setLastEntry] = useState(null);
  const [bottomBarFeedback, setBottomBarFeedback] = useState(null);
  const [selectedComp, setSelectedComp] = useState(null);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [online, setOnline] = useState(isOnline());
  const [panelSnap, setPanelSnap] = useState('closed');
  const [panelHeight, setPanelHeight] = useState(68);
  const [highlights, setHighlights] = useState({});
  const [focusEvent, setFocusEvent] = useState(null);

  const { toast } = useToast();
  const undoTimer = useRef(null);
  const feedbackTimer = useRef(null);
  const inFlight = useRef(new Set());
  const highlightTimers = useRef({});
  const pendingWrites = useRef(new Map());
  const invalidateTimer = useRef(null);

  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(nowInSeconds()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    return subscribe((status) => setOnline(status !== 'offline'));
  }, []);

  useEffect(() => {
    if (!roleLoading && !permissions.canRecordTimes) {
      navigate(`/competition/${id}/results`, { replace: true });
    }
  }, [roleLoading, permissions.canRecordTimes]);

  const { data: competition } = useQuery({
    queryKey: ['competition', id],
    queryFn: async () => {
      try {
        const data = await base44.entities.Competition.filter({ id });
        cacheData(`competition_${id}`, data[0]);
        return data[0];
      } catch (err) {
        if (!navigator.onLine) return getCachedData(`competition_${id}`);
        throw err;
      }
    },
  });

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors', id],
    queryFn: async () => {
      try {
        const data = await base44.entities.Competitor.filter({ competition_id: id }, 'bib_number');
        // A time that is still on its way to the server stays visible: a slower
        // fetch can never replace a newer local time with an older stored one.
        const merged = data.map(c => {
          const pending = pendingWrites.current.get(c.id);
          return pending ? { ...c, split_times: pending } : c;
        });
        cacheData(`competitors_${id}`, merged);
        return merged;
      } catch (err) {
        if (!navigator.onLine) return getCachedData(`competitors_${id}`) || [];
        throw err;
      }
    },
    refetchInterval: online ? 5000 : false,
  });

  // The competition's series colours are shared by the grid, the live results
  // and the competitor sheet.
  useSeriesPalette(competitors, competition);

  useEffect(() => {
    const timers = highlightTimers.current;
    return () => {
      if (undoTimer.current) clearTimeout(undoTimer.current);
      if (feedbackTimer.current) clearTimeout(feedbackTimer.current);
      if (invalidateTimer.current) clearTimeout(invalidateTimer.current);
      Object.values(timers).forEach(timer => clearTimeout(timer));
    };
  }, []);

  // One refresh for a burst of presses instead of a fetch per press.
  const scheduleRefresh = useCallback(() => {
    if (invalidateTimer.current) clearTimeout(invalidateTimer.current);
    invalidateTimer.current = setTimeout(() => {
      queryClient.invalidateQueries({ queryKey: ['competitors', id] });
    }, 900);
  }, [queryClient, id]);

  const handleButtonPress = useCallback((competitor) => {
    // Only the same competitor is blocked while its own write is on its way, so
    // a double tap can never store two times and every other button stays live.
    if (inFlight.current.has(competitor.id)) return;

    const cached = queryClient.getQueryData(['competitors', id]);
    const latestComp = cached?.find(c => c.id === competitor.id) || competitor;

    const totalPoints = getTotalPoints(competition);
    const progress = getCompetitorProgress(latestComp);

    if (progress >= totalPoints) {
      hapticPress();
      dismissCompetitor(user.id, id, competitor.id);
      queryClient.invalidateQueries({ queryKey: ['competitors', id] });
      return;
    }

    const nextIndex = getNextSplitIndex(latestComp, competition);
    if (nextIndex === -1) return;

    hapticPress();

    // The time is fixed at the moment of the press, before anything is awaited,
    // so a burst of presses keeps each competitor's own time.
    const now = nowInSeconds();
    const startSec = parseTimeToSeconds(latestComp.start_time);
    const elapsed = Math.round((now - startSec) * 100) / 100;

    const prevSplitTimes = [...(latestComp.split_times || [])];
    const splitTimes = prevSplitTimes.filter(s => s.split_index !== nextIndex);
    splitTimes.push({ split_index: nextIndex, timestamp: new Date().toISOString(), elapsed });

    // Same comparison logic as the split time view: rank and gap are taken from
    // the competitor's own group, never from the whole competition.
    const list = cached || competitors;
    const group = groupKey(latestComp, competition);
    const prevLeaderTime = bestTimeInGroup(list, competition, nextIndex, group, latestComp.id);
    const isNewLeader = prevLeaderTime === null || elapsed < prevLeaderTime;
    const leadSize = isNewLeader && prevLeaderTime !== null ? prevLeaderTime - elapsed : 0;

    const projected = list.map(c => (
      c.id === competitor.id ? { ...c, split_times: splitTimes } : c
    ));
    const standing = computeStandings(projected, competition, nextIndex).byId[competitor.id] || {};

    // Everything below is local state: the button, the feedback and the live
    // results react before the write leaves the device.
    inFlight.current.add(competitor.id);
    pendingWrites.current.set(competitor.id, splitTimes);

    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, split_times: splitTimes } : c)
    );
    updateCachedCompetitor(id, competitor.id, { split_times: splitTimes });

    if (undoTimer.current) clearTimeout(undoTimer.current);
    setLastEntry({ competitorId: competitor.id, prevSplitTimes });
    undoTimer.current = setTimeout(() => setLastEntry(null), 15000);

    if (feedbackTimer.current) clearTimeout(feedbackTimer.current);
    setBottomBarFeedback({
      competitorId: competitor.id,
      bibNumber: competitor.bib_number,
      name: competitor.name,
      seriesLabel: groupLabel(latestComp, competition, t),
      elapsed,
      rank: standing.rank,
      gap: standing.gap,
      isNewLeader: isNewLeader && standing.rank === 1,
      leadSize,
    });
    feedbackTimer.current = setTimeout(() => setBottomBarFeedback(null), 5000);

    // Every recording carries its own highlight and its own five second timer.
    const highlightTs = Date.now();
    const kind = standing.rank === 1 ? 'leader' : 'behind';
    setHighlights(prev => ({ ...prev, [competitor.id]: { kind, ts: highlightTs } }));
    if (highlightTimers.current[competitor.id]) clearTimeout(highlightTimers.current[competitor.id]);
    highlightTimers.current[competitor.id] = setTimeout(() => {
      delete highlightTimers.current[competitor.id];
      setHighlights(prev => {
        if (prev[competitor.id]?.ts !== highlightTs) return prev;
        const next = { ...prev };
        delete next[competitor.id];
        return next;
      });
    }, 5000);

    // Only the latest recording may move the results list.
    setFocusEvent({ ts: highlightTs, competitorId: competitor.id, splitIndex: nextIndex, seriesKey: group });

    execOrQueue('Competitor', 'update', competitor.id, { split_times: splitTimes })
      .catch(() => {
        // A rejected write is rolled back so an unsaved time is never shown as stored.
        queryClient.setQueryData(['competitors', id], (old) =>
          old?.map(c => c.id === competitor.id ? { ...c, split_times: prevSplitTimes } : c)
        );
        updateCachedCompetitor(id, competitor.id, { split_times: prevSplitTimes });
        toast({ variant: 'destructive', title: t('quickTouch.splitSaveError') });
      })
      .finally(() => {
        inFlight.current.delete(competitor.id);
        pendingWrites.current.delete(competitor.id);
        scheduleRefresh();
      });
  }, [competition, competitors, id, user, queryClient, t, toast, scheduleRefresh]);

  const handleUndo = useCallback(async () => {
    if (!lastEntry) return;
    const entry = lastEntry;

    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === entry.competitorId ? { ...c, split_times: entry.prevSplitTimes } : c)
    );
    updateCachedCompetitor(id, entry.competitorId, { split_times: entry.prevSplitTimes });
    undismissCompetitor(user.id, id, entry.competitorId);

    if (undoTimer.current) clearTimeout(undoTimer.current);
    setLastEntry(null);
    setBottomBarFeedback(null);

    await execOrQueue('Competitor', 'update', entry.competitorId, { split_times: entry.prevSplitTimes });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [lastEntry, id, user, queryClient]);

  const handleSetStatus = useCallback(async (competitor, status) => {
    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, status } : c)
    );
    updateCachedCompetitor(id, competitor.id, { status });
    await execOrQueue('Competitor', 'update', competitor.id, { status });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [queryClient, id]);

  const handleDelete = useCallback(async (competitor) => {
    queryClient.setQueryData(['competitors', id], (old) => old?.filter(c => c.id !== competitor.id));
    removeCachedCompetitor(id, competitor.id);
    undismissCompetitor(user.id, id, competitor.id);
    await execOrQueue('Competitor', 'delete', competitor.id);
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [queryClient, id, user]);

  const handleSaveName = useCallback(async (competitor, name) => {
    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, name } : c)
    );
    updateCachedCompetitor(id, competitor.id, { name });
    await execOrQueue('Competitor', 'update', competitor.id, { name });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [queryClient, id]);

  const handleManualTime = useCallback(async (competitor, splitIndex, elapsed) => {
    const prevSplitTimes = competitor.split_times || [];
    const splitTimes = [...prevSplitTimes];
    const existing = splitTimes.findIndex(s => s.split_index === splitIndex);
    if (existing >= 0) {
      splitTimes[existing] = { ...splitTimes[existing], elapsed, timestamp: new Date().toISOString() };
    } else {
      splitTimes.push({ split_index: splitIndex, timestamp: new Date().toISOString(), elapsed });
    }

    const restore = () => {
      queryClient.setQueryData(['competitors', id], (old) =>
        old?.map(c => c.id === competitor.id ? { ...c, split_times: prevSplitTimes } : c)
      );
      updateCachedCompetitor(id, competitor.id, { split_times: prevSplitTimes });
      setSelectedComp(prev => prev && prev.id === competitor.id ? { ...prev, split_times: prevSplitTimes } : prev);
    };

    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, split_times: splitTimes } : c)
    );
    updateCachedCompetitor(id, competitor.id, { split_times: splitTimes });
    undismissCompetitor(user.id, id, competitor.id);

    // A correction of an already stored time goes through the backend, which
    // checks the role against the competitor's own competition. A new time for
    // an empty timing point keeps the normal offline-friendly path.
    if (existing >= 0) {
      try {
        const res = await base44.functions.invoke('saveSplitTime', {
          competitorId: competitor.id,
          splitIndex,
          elapsed,
        });
        if (res?.data?.error) throw new Error(res.data.error);
        setSelectedComp(prev => prev && prev.id === competitor.id ? { ...prev, split_times: res?.data?.split_times || splitTimes } : prev);
        queryClient.invalidateQueries({ queryKey: ['competitors', id] });
      } catch (err) {
        restore();
        queryClient.invalidateQueries({ queryKey: ['competitors', id] });
        throw err;
      }
      return;
    }

    await execOrQueue('Competitor', 'update', competitor.id, { split_times: splitTimes });
    setSelectedComp(prev => prev && prev.id === competitor.id ? { ...prev, split_times: splitTimes } : prev);
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [queryClient, id, user]);

  const handleUndoSplit = useCallback(async (competitor, splitIndex) => {
    const prevSplitTimes = competitor.split_times || [];
    const splitTimes = prevSplitTimes.filter(s => s.split_index !== splitIndex);

    const restore = () => {
      queryClient.setQueryData(['competitors', id], (old) =>
        old?.map(c => c.id === competitor.id ? { ...c, split_times: prevSplitTimes } : c)
      );
      updateCachedCompetitor(id, competitor.id, { split_times: prevSplitTimes });
      setSelectedComp(prev => prev && prev.id === competitor.id ? { ...prev, split_times: prevSplitTimes } : prev);
    };

    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, split_times: splitTimes } : c)
    );
    updateCachedCompetitor(id, competitor.id, { split_times: splitTimes });
    setSelectedComp(prev => prev && prev.id === competitor.id ? { ...prev, split_times: splitTimes } : prev);
    undismissCompetitor(user.id, id, competitor.id);

    // Removing a stored time is checked against the competition role on the
    // backend (timer, editor or owner). Offline it keeps the queued path.
    if (!isOnline()) {
      await execOrQueue('Competitor', 'update', competitor.id, { split_times: splitTimes });
      queryClient.invalidateQueries({ queryKey: ['competitors', id] });
      return;
    }

    try {
      const res = await base44.functions.invoke('saveSplitTime', {
        competitorId: competitor.id,
        splitIndex,
        remove: true,
      });
      if (res?.data?.error) throw new Error(res.data.error);
      const saved = res?.data?.split_times || splitTimes;
      queryClient.setQueryData(['competitors', id], (old) =>
        old?.map(c => c.id === competitor.id ? { ...c, split_times: saved } : c)
      );
      updateCachedCompetitor(id, competitor.id, { split_times: saved });
      setSelectedComp(prev => prev && prev.id === competitor.id ? { ...prev, split_times: saved } : prev);
      queryClient.invalidateQueries({ queryKey: ['competitors', id] });
    } catch (err) {
      restore();
      queryClient.invalidateQueries({ queryKey: ['competitors', id] });
      throw err;
    }
  }, [queryClient, id, user]);

  const sortedCompetitors = [...competitors].sort((a, b) => {
    if (a.sort_order !== undefined && b.sort_order !== undefined) {
      return a.sort_order - b.sort_order;
    }
    return a.bib_number - b.bib_number;
  });

  const dismissed = user?.id ? getDismissed(user.id, id) : [];
  const activeCompetitors = sortedCompetitors.filter(c => {
    if (dismissed.includes(c.id)) {
      if (isFullyRecorded(c, competition)) return false;
      undismissCompetitor(user.id, id, c.id);
    }
    return true;
  });

  const totalPoints = getTotalPoints(competition);
  const totalRequired = activeCompetitors.length * totalPoints;
  const totalRecorded = activeCompetitors.reduce((sum, c) => sum + getCompetitorProgress(c), 0);
  const progressPct = totalRequired > 0 ? Math.round((totalRecorded / totalRequired) * 100) : 0;

  const openSheet = (competitor) => { setSelectedComp(competitor); setSheetOpen(true); };

  const handleFeedbackTap = () => {
    if (!bottomBarFeedback) return;
    const comp = competitors.find(c => c.id === bottomBarFeedback.competitorId);
    if (comp) openSheet(comp);
  };

  const now = new Date();
  const liveTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

  return (
    <div className="min-h-screen bg-background">
      <CompetitionNav competition={competition} />
      <QuickTouchStatusBar
        liveTime={liveTime}
        totalRecorded={totalRecorded}
        totalRequired={totalRequired}
        progressPct={progressPct}
        lastEntry={lastEntry}
        onUndo={handleUndo}
      />
      <div
        className="max-w-3xl mx-auto px-3 py-3"
        style={{ paddingBottom: panelHeight + 16 }}
      >
        <QuickTouchGrid
          competitors={activeCompetitors}
          competition={competition}
          onPress={handleButtonPress}
        />
      </div>
      <LiveResultsPanel
        competitors={competitors}
        competition={competition}
        snap={panelSnap}
        onSnapChange={setPanelSnap}
        onHeightChange={setPanelHeight}
        feedback={bottomBarFeedback}
        onFeedbackTap={handleFeedbackTap}
        focusEvent={focusEvent}
        highlights={highlights}
        onCompetitorTap={openSheet}
      />
      <QuickTouchCompetitorSheet
        competitor={selectedComp}
        competition={competition}
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        onUndoSplit={handleUndoSplit}
        onManualTime={handleManualTime}
        onSetStatus={handleSetStatus}
        onDelete={handleDelete}
        onSaveName={handleSaveName}
        permissions={permissions}
      />
    </div>
  );
}