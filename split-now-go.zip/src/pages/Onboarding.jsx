import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQueryClient } from '@tanstack/react-query';
import { AnimatePresence, motion } from 'framer-motion';
import { changeLanguage } from '@/i18n';
import { base44 } from '@/api/base44Client';
import { isGuestMode, updateGuestProfile } from '@/lib/guestMode';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import SplitNowLogo from '@/components/brand/SplitNowLogo';
import { CreateMockup, JoinMockup, RecordMockup } from '@/components/onboarding/OnboardingMockups';

const languages = [
  { code: 'fi', label: 'Suomi', flag: '🇫🇮' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'sv', label: 'Svenska', flag: '🇸🇪' },
];

export default function Onboarding() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [step, setStep] = useState('language');
  const [slideIndex, setSlideIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const [selectedLang, setSelectedLang] = useState(i18n.language || 'fi');
  const touchStart = useRef({ x: 0, y: 0 });

  const handleLangSelect = (code) => {
    setSelectedLang(code);
    changeLanguage(code);
  };

  const handleFinish = async () => {
    if (isGuestMode()) {
      updateGuestProfile({ onboarding_completed: true });
      localStorage.setItem('onboarding_done', 'true');
      queryClient.setQueryData(['me'], (old) => old ? { ...old, onboarding_completed: true } : old);
    } else {
      await base44.auth.updateMe({ onboarding_completed: true });
      queryClient.setQueryData(['me'], (old) => old ? { ...old, onboarding_completed: true } : old);
    }
    const params = new URLSearchParams(window.location.search);
    const joinCode = params.get('join');
    navigate(joinCode ? `/join?join=${joinCode}` : '/');
  };

  const handleNext = () => {
    if (slideIndex < 3) {
      setDirection(1);
      setSlideIndex(i => i + 1);
    } else {
      handleFinish();
    }
  };

  const handlePrev = () => {
    if (slideIndex > 0) {
      setDirection(-1);
      setSlideIndex(i => i - 1);
    }
  };

  const handleTouchStart = (e) => {
    touchStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };

  const handleTouchEnd = (e) => {
    const dx = e.changedTouches[0].clientX - touchStart.current.x;
    const dy = e.changedTouches[0].clientY - touchStart.current.y;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) {
      if (dx < 0) handleNext();
      else handlePrev();
    }
  };

  const slides = [
    {
      visual: <SplitNowLogo className="w-24 h-24 rounded-3xl shadow-2xl shadow-primary/30 ring-1 ring-primary/20 mx-auto" />,
      title: t('onboarding.slide1Title'),
      desc: t('onboarding.slide1Desc'),
    },
    {
      visual: <CreateMockup />,
      title: t('onboarding.slide2Title'),
      desc: t('onboarding.slide2Desc'),
    },
    {
      visual: <JoinMockup />,
      title: t('onboarding.slide3Title'),
      desc: t('onboarding.slide3Desc'),
    },
    {
      visual: <RecordMockup />,
      title: t('onboarding.slide4Title'),
      desc: t('onboarding.slide4Desc'),
    },
  ];

  if (step === 'language') {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-b from-primary/8 to-transparent pointer-events-none" />
        <div className="relative w-full max-w-sm">
          <SplitNowLogo className="w-20 h-20 rounded-3xl shadow-2xl shadow-primary/30 ring-1 ring-primary/20 mx-auto mb-8" />
          <h2 className="text-2xl font-black text-foreground mb-2 text-center">{t('onboarding.selectLanguage')}</h2>
          <p className="text-muted-foreground text-sm text-center mb-8">{t('onboarding.languageHint')}</p>
          <div className="space-y-3 mb-8">
            {languages.map(lang => (
              <button
                key={lang.code}
                onClick={() => handleLangSelect(lang.code)}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl border-2 transition-all font-bold text-base ${
                  selectedLang === lang.code
                    ? 'border-primary bg-primary/10 text-foreground'
                    : 'border-border bg-card text-muted-foreground'
                }`}
              >
                <span className="text-2xl">{lang.flag}</span>
                {lang.label}
                {selectedLang === lang.code && <span className="ml-auto text-primary text-lg">✓</span>}
              </button>
            ))}
          </div>
          <button
            onClick={() => setStep('slides')}
            className="w-full h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/85 text-primary-foreground font-black text-base shadow-xl shadow-primary/30 active:scale-[0.98] transition-transform"
          >
            {t('onboarding.continue')}
          </button>
        </div>
      </div>
    );
  }

  const slide = slides[slideIndex];

  return (
    <div className="min-h-screen bg-background flex flex-col" onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
      <div className="flex items-center justify-between px-6 pt-10">
        {slideIndex > 0 ? (
          <button onClick={handlePrev} className="text-muted-foreground active:scale-95 transition-transform">
            <ChevronLeft className="w-6 h-6" />
          </button>
        ) : (
          <div className="w-6" />
        )}
        <button onClick={handleFinish} className="text-muted-foreground text-sm font-semibold">
          {t('onboarding.skip')}
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-8 text-center overflow-hidden">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={slideIndex}
            custom={direction}
            initial={(dir) => ({ x: dir >= 0 ? '100%' : '-100%', opacity: 0 })}
            animate={{ x: 0, opacity: 1 }}
            exit={(dir) => ({ x: dir >= 0 ? '-100%' : '100%', opacity: 0 })}
            transition={{ duration: 0.3, ease: [0.32, 0.72, 0, 1] }}
            className="flex flex-col items-center w-full"
          >
            <div className="mb-6">{slide.visual}</div>
            <h1 className="text-2xl font-black text-foreground leading-tight mb-3 max-w-xs">{slide.title}</h1>
            <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">{slide.desc}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="px-8 pb-12 flex flex-col items-center gap-6">
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <div
              key={i}
              className={`h-2 rounded-full transition-all ${
                i === slideIndex ? 'w-6 bg-primary' : 'w-2 bg-muted'
              }`}
            />
          ))}
        </div>
        <button
          onClick={handleNext}
          className="w-full max-w-sm h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/85 text-primary-foreground font-black text-base shadow-xl shadow-primary/30 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
        >
          {slideIndex < slides.length - 1 ? (
            <>{t('onboarding.next')} <ChevronRight className="w-5 h-5" /></>
          ) : (
            t('onboarding.start')
          )}
        </button>
      </div>
    </div>
  );
}