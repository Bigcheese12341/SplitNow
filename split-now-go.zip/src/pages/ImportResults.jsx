import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, ImagePlus, AlertTriangle, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ImageUploadStep from '@/components/import/ImageUploadStep';
import TimePointMappingStep from '@/components/import/TimePointMappingStep';
import ResultsReviewStep from '@/components/import/ResultsReviewStep';
import ImportSummaryStep from '@/components/import/ImportSummaryStep';
import { useUserRole } from '@/lib/permissions';
import {
  calculateFinalStructure,
  matchImportedCompetitor,
  getExistingManualSplits,
  calculateStartTime,
  parseResultTimeToSeconds,
  buildCheckpoints
} from '@/lib/resultImportAnalysis';
import {
  readSession,
  writeSession,
  clearSession,
  subscribeSession,
  isAnalyzing,
  runBackgroundAnalysis
} from '@/lib/importSession';

export default function ImportResults() {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const context = searchParams.get('context') || 'settings';
  const queryClient = useQueryClient();
  const { permissions, isLoading: roleLoading } = useUserRole(id);

  // The whole import process is restored from the stored session, so returning to
  // the page never starts over.
  const [saved] = useState(() => readSession(id));
  const [session, setSession] = useState(saved);
  const [step, setStep] = useState(saved?.step || 1);
  const [maxStepReached, setMaxStepReached] = useState(saved?.maxStepReached || 1);
  const [images, setImages] = useState(saved?.images || []);
  const [analyzing, setAnalyzing] = useState(() => isAnalyzing(id));
  const [analysisError, setAnalysisError] = useState(null);
  const [emptyAnalysis, setEmptyAnalysis] = useState(saved?.analysisStatus === 'empty');
  const [analysisResult, setAnalysisResult] = useState(saved?.analysisResult || null);
  const [checkpoints, setCheckpoints] = useState(saved?.checkpoints || null);
  const [editedCompetitors, setEditedCompetitors] = useState(saved?.competitors || []);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [estimatedSeconds, setEstimatedSeconds] = useState(45);
  const adoptedRef = useRef(null);

  const { data: competition } = useQuery({
    queryKey: ['competition', id],
    queryFn: () => base44.entities.Competition.filter({ id }),
    select: data => data[0]
  });

  const { data: competitors = [], isLoading: competitorsLoading } = useQuery({
    queryKey: ['competitors', id],
    queryFn: () => base44.entities.Competitor.filter({ competition_id: id }, 'bib_number'),
  });

  const splitCount = competition?.split_count || 1;
  const addFinish = competition?.add_finish || false;

  const manualSplits = useMemo(
    () => getExistingManualSplits(competitors, splitCount, addFinish),
    [competitors, splitCount, addFinish]
  );

  const manualCheckpointRows = useMemo(
    () => (checkpoints || []).filter(row => row.source === 'manual'),
    [checkpoints]
  );

  const importedTargets = useMemo(() => {
    const targets = {};
    (checkpoints || []).forEach(row => {
      if (row.source === 'imported') targets[row.original_index] = row.target;
    });
    return targets;
  }, [checkpoints]);

  const finalStructure = useMemo(
    () => calculateFinalStructure(checkpoints || [], splitCount, addFinish),
    [checkpoints, splitCount, addFinish]
  );

  useEffect(() => {
    if (!roleLoading && !permissions.canEditCompetitors) {
      navigate(`/competition/${id}/results`, { replace: true });
    }
  }, [roleLoading, permissions.canEditCompetitors]);

  // A background analysis reports its progress here.
  useEffect(() => subscribeSession(id, () => setSession(readSession(id))), [id]);

  useEffect(() => {
    const status = session?.analysisStatus;
    if (status === 'running') setAnalyzing(isAnalyzing(id));
    if (status === 'done' || status === 'error') setAnalyzing(false);
    if (status === 'empty') {
      setAnalyzing(false);
      setEmptyAnalysis(true);
    }
  }, [session?.analysisStatus, id]);

  // Recognised time points become the shared timing point list as soon as the
  // analysis finishes, whether the user is on the page or just came back.
  useEffect(() => {
    if (!session || session.analysisStatus !== 'done' || !session.analysisResult) return;
    if (adoptedRef.current === session.analysisAt) return;
    if (competitorsLoading) return;

    adoptedRef.current = session.analysisAt;
    setAnalysisResult(session.analysisResult);
    setEditedCompetitors(session.competitors || session.analysisResult.competitors || []);
    if (!session.checkpoints) {
      setCheckpoints(buildCheckpoints(manualSplits, session.analysisResult.time_points, splitCount, addFinish));
    }
    setStep(prev => Math.max(prev, 2));
    setMaxStepReached(prev => Math.max(prev, 2));
  }, [session, competitorsLoading, manualSplits, splitCount, addFinish]);

  // Persist the process on every change, keeping the analysis fields the
  // background run writes.
  useEffect(() => {
    if (importResult) return;
    if (!images.length && !analysisResult) return;
    const current = readSession(id) || {};
    writeSession(id, {
      step,
      images,
      maxStepReached,
      competitors: editedCompetitors,
      checkpoints,
      analysisResult: analysisResult ?? current.analysisResult ?? null
    });
  }, [id, step, images, maxStepReached, editedCompetitors, checkpoints, analysisResult, importResult]);

  // Estimated time countdown
  useEffect(() => {
    if (!analyzing) return;
    setEstimatedSeconds(45);
    const interval = setInterval(() => {
      setEstimatedSeconds(prev => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [analyzing]);

  const handleAnalyze = async () => {
    setAnalysisError(null);
    setEmptyAnalysis(false);
    setAnalyzing(true);
    try {
      await runBackgroundAnalysis(id, {
        imageUrls: images.map(img => img.url),
        context: { splitCount, addFinish, manualSplits, competitorCount: competitors.length }
      });
    } catch (err) {
      console.error('Analysis failed', err);
      setAnalysisError(err.message || t('importResults.analysisError'));
    }
    setAnalyzing(false);
  };

  const goToStep = (newStep) => {
    if (newStep <= maxStepReached) setStep(newStep);
  };

  const handleImport = async () => {
    setImporting(true);
    try {
      const { finalSplitCount, finalAddFinish, importedMapping, manualMoves } = finalStructure;

      if (finalSplitCount !== splitCount || finalAddFinish !== addFinish) {
        await base44.entities.Competition.update(id, {
          split_count: finalSplitCount,
          add_finish: finalAddFinish
        });
      }

      // Recorded times follow the competition structure: the finish always keeps its
      // own point even when the number of split points changes, split points that no
      // longer exist are dropped and the user's own moves are applied.
      const oldFinishIndex = addFinish ? splitCount : null;
      const newFinishIndex = finalAddFinish ? finalSplitCount : null;

      const relocate = (splits) => {
        const result = [];
        for (const split of splits || []) {
          let index = split.split_index;
          if (oldFinishIndex !== null && index === oldFinishIndex) {
            if (newFinishIndex === null) continue;
            index = newFinishIndex;
          } else if (index >= finalSplitCount) {
            continue;
          } else if (split.source !== 'ai_imported') {
            const move = manualMoves.find(m => m.from === index);
            if (move) index = move.to;
          }
          result.push(index === split.split_index ? split : { ...split, split_index: index });
        }
        return result;
      };

      let added = 0;
      let uncertain = 0;
      const toCreate = [];
      const updates = [];
      const updatedIds = new Set();

      for (const imported of editedCompetitors) {
        uncertain += (imported.times || []).filter(time => time.uncertain).length;
        const existing = matchImportedCompetitor(imported, competitors);
        const newSplitTimes = [];

        Object.entries(importedMapping).forEach(([detectedIdx, splitIdx]) => {
          if (splitIdx === null || splitIdx === undefined) return;
          const timeEntry = (imported.times || []).find(time => time.time_point_index === Number(detectedIdx));
          if (!timeEntry || !timeEntry.time) return;
          const elapsed = parseResultTimeToSeconds(timeEntry.time);
          if (elapsed === null) return;
          newSplitTimes.push({
            split_index: splitIdx,
            timestamp: new Date().toISOString(),
            elapsed,
            source: 'ai_imported'
          });
        });

        if (existing) {
          const existingSplits = [...relocate(existing.split_times || [])];
          for (const newSplit of newSplitTimes) {
            const idx = existingSplits.findIndex(s => s.split_index === newSplit.split_index);
            if (idx < 0) {
              existingSplits.push(newSplit);
              continue;
            }
            // A time recorded by hand is never replaced by an imported one.
            const current = existingSplits[idx];
            const recordedByHand = current.source !== 'ai_imported'
              && current.elapsed !== null
              && current.elapsed !== undefined;
            if (!recordedByHand) {
              existingSplits[idx] = {
                ...current,
                elapsed: newSplit.elapsed,
                timestamp: newSplit.timestamp,
                source: 'ai_imported'
              };
            }
          }
          updatedIds.add(existing.id);
          updates.push({
            id: existing.id,
            split_times: existingSplits,
            ...(imported.name && !existing.name ? { name: imported.name } : {}),
            status: imported.status || existing.status
          });
        } else {
          const startTime = calculateStartTime(competition, imported.bib_number);
          toCreate.push({
            competition_id: id,
            bib_number: imported.bib_number,
            name: imported.name || '',
            start_time: startTime,
            status: imported.status || 'active',
            split_times: newSplitTimes
          });
          added++;
        }
      }

      // Every competitor's recorded times follow the new structure, also when only
      // the finish point moved.
      for (const competitor of competitors) {
        if (updatedIds.has(competitor.id)) continue;
        const before = competitor.split_times || [];
        const after = relocate(before);
        if (JSON.stringify(after) !== JSON.stringify(before)) {
          updates.push({ id: competitor.id, split_times: after });
        }
      }

      for (let i = 0; i < toCreate.length; i += 50) {
        await base44.entities.Competitor.bulkCreate(toCreate.slice(i, i + 50));
      }
      for (let i = 0; i < updates.length; i += 50) {
        await base44.entities.Competitor.bulkUpdate(updates.slice(i, i + 50));
      }

      queryClient.invalidateQueries({ queryKey: ['competitors', id] });
      queryClient.invalidateQueries({ queryKey: ['competition', id] });
      queryClient.invalidateQueries({ queryKey: ['competitions'] });

      clearSession(id);

      setImportResult({
        added,
        newSplits: Math.max(0, finalSplitCount - splitCount),
        finishAdded: finalAddFinish && !addFinish ? 1 : 0,
        duplicates: 0,
        uncertain
      });
    } catch (err) {
      console.error('Import failed', err);
    }
    setImporting(false);
  };

  const steps = [
    { num: 1, label: t('importResults.step1') },
    { num: 2, label: t('importResults.step3') },
    { num: 3, label: t('importResults.step4') },
    { num: 4, label: t('importResults.step5') },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-lg mx-auto px-3 h-14 flex items-center gap-2">
          <button
            onClick={() => step === 1 ? navigate(`/competition/${id}/edit`) : setStep(step - 1)}
            className="flex items-center justify-center w-9 h-9 rounded-full hover:bg-muted transition-colors flex-shrink-0"
          >
            <ArrowLeft className="w-5 h-5 text-muted-foreground" />
          </button>
          <p className="font-black text-base text-foreground truncate flex-1">{t('importResults.title')}</p>
          {step > 1 && images.length > 0 && (
            <span className="text-[10px] text-muted-foreground font-medium flex items-center gap-1 flex-shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
              {t('importResults.progressSaved')}
            </span>
          )}
        </div>
        {/* Step indicator - clickable */}
        <div className="max-w-lg mx-auto px-4 pb-2 flex items-center gap-1">
          {steps.map((s, i) => (
            <div key={s.num} className="flex items-center gap-1">
              <button
                onClick={() => goToStep(s.num)}
                disabled={s.num > maxStepReached}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                  step === s.num
                    ? 'bg-primary text-primary-foreground'
                    : s.num <= maxStepReached
                    ? 'bg-primary/10 text-primary active:scale-95'
                    : 'bg-muted text-muted-foreground opacity-50 cursor-not-allowed'
                }`}
              >
                {step > s.num && (
                  <span className="w-4 h-4 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-[10px]">✓</span>
                )}
                <span>{s.label}</span>
              </button>
              {i < steps.length - 1 && <div className="w-2 h-px bg-border" />}
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-4">
        {analysisError && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-sm text-red-600 dark:text-red-400 font-medium">
            {t('importResults.analysisError')}
          </div>
        )}

        {emptyAnalysis && (
          <div className="mb-4 p-3 rounded-xl bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-amber-700 dark:text-amber-300">{t('importResults.noCompetitorsTitle')}</p>
                <p className="text-xs text-amber-700/80 dark:text-amber-300/80 leading-relaxed mt-0.5">{t('importResults.noCompetitorsDesc')}</p>
              </div>
              <button
                onClick={() => setEmptyAnalysis(false)}
                aria-label={t('common.close')}
                className="w-6 h-6 rounded-full flex items-center justify-center text-amber-700/70 dark:text-amber-300/70 flex-shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {step === 1 && (
          <ImageUploadStep
            images={images}
            setImages={setImages}
            onAnalyze={handleAnalyze}
            analyzing={analyzing}
            estimatedSeconds={estimatedSeconds}
          />
        )}

        {step > 1 && !analysisResult && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <ImagePlus className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="font-bold text-sm text-foreground mb-1">{t('importResults.emptyNoData')}</p>
            <p className="text-xs text-muted-foreground mb-4">{t('importResults.emptyNoDataDesc')}</p>
            <button
              onClick={() => setStep(1)}
              className="px-4 h-10 rounded-xl bg-primary text-primary-foreground font-bold text-sm active:scale-95 transition-transform"
            >
              {t('importResults.goToUpload')}
            </button>
          </div>
        )}

        {step === 2 && analysisResult && (
          <TimePointMappingStep
            checkpoints={checkpoints || []}
            setCheckpoints={setCheckpoints}
            splitCount={splitCount}
            competition={competition}
            onBack={() => setStep(1)}
            onNext={() => { setStep(3); setMaxStepReached(Math.max(maxStepReached, 3)); }}
          />
        )}

        {step === 3 && analysisResult && (
          <ResultsReviewStep
            competitors={editedCompetitors}
            setCompetitors={setEditedCompetitors}
            detectedPoints={analysisResult.time_points}
            mappings={importedTargets}
            competition={competition}
            onBack={() => setStep(2)}
            onNext={() => { setStep(4); setMaxStepReached(Math.max(maxStepReached, 4)); }}
          />
        )}

        {step === 4 && analysisResult && (
          <ImportSummaryStep
            competitors={editedCompetitors}
            detectedPoints={analysisResult.time_points}
            mappings={importedTargets}
            manualSplits={manualCheckpointRows}
            splitCount={splitCount}
            addFinish={addFinish}
            finalStructure={finalStructure}
            importing={importing}
            importResult={importResult}
            onBack={() => setStep(3)}
            onImport={handleImport}
            onShowResults={() => navigate(`/competition/${id}/results`)}
          />
        )}
      </div>
    </div>
  );
}