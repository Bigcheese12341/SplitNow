import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import CompetitionNav from '@/components/competition/CompetitionNav';
import CompetitorSearch, { matchCompetitor } from '@/components/competition/CompetitorSearch';
import { Button } from '@/components/ui/button';
import { Lock, Download } from 'lucide-react';
import { formatElapsed, formatGap } from '@/lib/timeUtils';
import { getTimingPoints } from '@/lib/splitLabels';
import { generateResultsImage } from '@/lib/generateResultsImage';
import { useUserRole } from '@/lib/permissions';
import { execOrQueue, cacheData, getCachedData } from '@/lib/syncQueue';
import ResultsFilterBar from '@/components/competition/ResultsFilterBar';
import { SERIES_ALL, buildSeriesOptions } from '@/lib/seriesUtils';
import { useSeriesPalette } from '@/lib/seriesPalette';
import { buildResultList } from '@/lib/comparisonUtils';
import { RESULT_TIME_CLASS, RESULT_GAP_CLASS } from '@/lib/resultStyles';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export default function Results() {
  const { t } = useTranslation();
  const { id } = useParams();
  const queryClient = useQueryClient();
  const [activeSplitIndex, setActiveSplitIndex] = useState(null);
  const [search, setSearch] = useState('');
  const [seriesValue, setSeriesValue] = useState(SERIES_ALL);
  const { permissions } = useUserRole(id);

  const { data: competition } = useQuery({
    queryKey: ['competition', id],
    queryFn: async () => {
      try {
        const data = await base44.entities.Competition.filter({ id });
        cacheData(`competition_${id}`, data[0]);
        return data[0];
      } catch (err) {
        if (!navigator.onLine) return getCachedData(`competition_${id}`);
        throw err;
      }
    },
  });

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors', id],
    queryFn: async () => {
      try {
        const data = await base44.entities.Competitor.filter({ competition_id: id }, 'bib_number');
        cacheData(`competitors_${id}`, data);
        return data;
      } catch (err) {
        if (!navigator.onLine) return getCachedData(`competitors_${id}`) || [];
        throw err;
      }
    },
  });

  useSeriesPalette(competitors, competition);

  const splitCount = competition?.split_count || 1;
  const addFinish = competition?.add_finish;
  const selectedSplit = activeSplitIndex !== null ? activeSplitIndex : (addFinish ? splitCount : splitCount - 1);

  const timingPoints = getTimingPoints(competition, t);

  const handleFinish = async () => {
    await execOrQueue('Competition', 'update', id, { status: 'finished' });
    queryClient.invalidateQueries({ queryKey: ['competition', id] });
  };

  const seriesOptions = React.useMemo(
    () => buildSeriesOptions(competitors, competition, t),
    [competitors, competition, t]
  );

  // The viewed result list: only the chosen series, ordered by the chosen split
  // time, ranked inside that list. Viewing never touches the own-series standing.
  const resultList = React.useMemo(
    () => buildResultList(competitors, competition, selectedSplit, seriesValue),
    [competitors, competition, selectedSplit, seriesValue]
  );

  // If the selected series no longer has any competitor, fall back to "all".
  React.useEffect(() => {
    if (seriesValue === SERIES_ALL) return;
    const exists = seriesOptions.items.some(option => option.value === seriesValue);
    if (!exists) setSeriesValue(SERIES_ALL);
  }, [seriesOptions, seriesValue]);

  const filtered = resultList.filter(c => matchCompetitor(c, search));

  const isFinished = competition?.status === 'finished';

  const finalIndex = addFinish ? splitCount : splitCount - 1;
  const accountedCount = competitors.filter(c => {
    if (c.status === 'DNS' || c.status === 'DNF' || c.status === 'DSQ') return true;
    const split = (c.split_times || []).find(s => s.split_index === finalIndex);
    return split && split.elapsed !== null && split.status !== 'DNF';
  }).length;
  const canFinish = competitors.length > 0 && accountedCount === competitors.length;

  const rowStyles = [
    'bg-amber-50 border-amber-200 dark:bg-amber-500/10 dark:border-amber-500/20',
    'bg-slate-50 border-slate-200 dark:bg-slate-500/10 dark:border-slate-500/20',
    'bg-orange-50 border-orange-200 dark:bg-orange-500/10 dark:border-orange-500/20',
    'bg-card border-border',
  ];

  return (
    <div className="min-h-screen bg-background">
      <CompetitionNav competition={competition} />

      <div className="max-w-lg mx-auto px-4 py-4 space-y-4">
        <ResultsFilterBar
          timingPoints={timingPoints}
          selectedSplit={selectedSplit}
          onSplitChange={setActiveSplitIndex}
          seriesOptions={seriesOptions}
          seriesValue={seriesValue}
          onSeriesChange={setSeriesValue}
        />

        {isFinished && (
          <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-muted text-sm font-semibold text-muted-foreground border border-border">
            <Lock className="w-4 h-4" />
            {t('results.locked')}
          </div>
        )}

        {resultList.length > 0 ? (
          <div className="space-y-0.5">
            <CompetitorSearch value={search} onChange={setSearch} />
            {filtered.length === 0 && (
              <p className="text-center py-8 text-sm text-muted-foreground">{t('common.noResults')}</p>
            )}
            <div className="grid grid-cols-[1.75rem_2.25rem_1fr_4.25rem_3.25rem] gap-1 px-2.5 py-1 text-[11px] font-bold text-muted-foreground uppercase tracking-widest">
              <span>{t('results.rank')}</span>
              <span>{t('results.bibNumber')}</span>
              <span>{t('results.name')}</span>
              <span className="text-right">{t('results.time')}</span>
              <span className="text-right">{t('results.gap')}</span>
            </div>

            {filtered.map(c => {
              const hasStatus = c.isDNS || c.isDNF || c.isDSQ;
              const rank = hasStatus ? null : c.rank;
              const place = rank ? Math.min(rank - 1, 3) : 3;
              return (
                <div
                  key={c.id}
                  className={`grid grid-cols-[1.75rem_2.25rem_1fr_4.25rem_3.25rem] gap-1 items-center pl-2.5 pr-[9px] py-1.5 rounded-lg border transition-all ${
                    hasStatus
                      ? c.isDNS
                        ? 'bg-slate-50 border-slate-200 dark:bg-slate-500/10 dark:border-slate-500/20'
                        : c.isDSQ
                        ? 'bg-blue-50 border-blue-200 dark:bg-blue-500/10 dark:border-blue-500/20'
                        : 'bg-red-50 border-red-200 dark:bg-red-500/10 dark:border-red-500/20'
                      : rowStyles[place]
                  }`}
                >
                  <span className={`font-black tabular-nums leading-none ${
                    hasStatus ? 'text-base text-muted-foreground' : rank && rank < 4 ? 'text-lg' : 'text-base text-foreground'
                  }`}>
                    {hasStatus ? '—' : (rank || '—')}
                  </span>
                  <span className="font-semibold text-muted-foreground/50 tabular-nums text-xs">{c.bib_number}</span>
                  <span className="text-sm font-medium truncate">{c.name || ''}</span>
                  <span className={`text-right font-mono text-sm tabular-nums ${
                    hasStatus
                      ? c.isDNS ? 'text-slate-600 dark:text-slate-400 font-bold' :
                        c.isDSQ ? 'text-blue-600 dark:text-blue-400 font-bold' :
                        'text-red-600 dark:text-red-400 font-bold'
                      : RESULT_TIME_CLASS
                  }`}>
                    {hasStatus ? (c.isDNS ? t('splitTime.statusDNS') : c.isDSQ ? t('splitTime.statusDSQ') : t('splitTime.statusDNF')) : formatElapsed(c.elapsed)}
                  </span>
                  <span className={`text-right text-sm tabular-nums ${RESULT_GAP_CLASS}`}>
                    {hasStatus || c.gap === null || c.gap === undefined ? '' : (rank === 1 ? '' : formatGap(c.gap))}
                  </span>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 text-muted-foreground">
            <div className="text-4xl mb-3">⏱️</div>
            <p className="font-semibold">{t('results.noResults')}</p>
            <p className="text-sm mt-1">{t('results.noResultsDesc')}</p>
          </div>
        )}

        {resultList.length > 0 && (
          <Button
            variant="outline"
            className="w-full h-12 rounded-xl font-bold"
            onClick={() => generateResultsImage(competition, competitors, t)}
          >
            <Download className="w-4 h-4" />
            {t('results.downloadResults')}
          </Button>
        )}

        {!isFinished && permissions.canDeleteCompetition && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                className="w-full h-12 rounded-xl font-bold border-destructive/40 text-destructive hover:bg-destructive/5"
              >
                {t('results.finalize')}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t('results.finalizeConfirm')}</AlertDialogTitle>
                <AlertDialogDescription>
                  {canFinish ? t('results.finalizeDesc') : t('results.finalizeIncompleteDesc')}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
                <AlertDialogAction onClick={handleFinish} className="bg-destructive text-destructive-foreground">
                  {canFinish ? t('results.finalizeAction') : t('results.finalizeAnyway')}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>
    </div>
  );
}