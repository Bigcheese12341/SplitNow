import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import {
  Settings, ChevronRight, Trophy, Clock, MessageSquare, Camera,
  Check, Loader2, X
} from 'lucide-react';
import { format } from 'date-fns';
import { updateGuestProfile } from '@/lib/guestMode';
import { syncPublicProfile } from '@/lib/syncPublicProfile';

export default function Profile() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [editMode, setEditMode] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [saving, setSaving] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [sendingFeedback, setSendingFeedback] = useState(false);
  const [feedbackError, setFeedbackError] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  const { data: user, isLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me()
  });

  const isGuest = user?.is_guest;

  useEffect(() => {
    if (user) {
      setDisplayName(user.display_name || user.full_name || '');
      setBio(user.bio || '');
      setAvatarUrl(user.avatar_url || '');
    }
  }, [user]);

  const { data: memberships = [] } = useQuery({
    queryKey: ['my-memberships', user?.id],
    queryFn: () => base44.entities.CompetitionMember.filter({ user_id: user.id }),
    enabled: !!user?.id && !isGuest
  });

  const { data: createdComps = [] } = useQuery({
    queryKey: ['my-created-competitions', user?.id],
    queryFn: () => base44.entities.Competition.filter({ created_by_id: user.id }, '-created_date'),
    enabled: !!user?.id && !isGuest
  });

  const memberCompIds = memberships.map(m => m.competition_id);
  const { data: memberComps = [] } = useQuery({
    queryKey: ['my-member-competitions', memberCompIds],
    queryFn: () => base44.entities.Competition.filter({ id: { $in: memberCompIds } }, '-created_date'),
    enabled: memberCompIds.length > 0
  });

  const compMap = new Map();
  [...createdComps, ...memberComps].forEach(c => compMap.set(c.id, c));
  const allComps = Array.from(compMap.values()).sort((a, b) =>
    (b.date || '').localeCompare(a.date || '')
  );

  const handleSave = async () => {
    setSaving(true);
    if (isGuest) {
      updateGuestProfile({ display_name: displayName, bio, avatar_url: avatarUrl });
      queryClient.setQueryData(['me'], (old) => old ? { ...old, display_name: displayName, bio, avatar_url: avatarUrl } : old);
    } else {
      await base44.auth.updateMe({
        display_name: displayName,
        bio: bio,
        avatar_url: avatarUrl
      });
      const myMemberships = await base44.entities.CompetitionMember.filter({ user_id: user.id });
      if (myMemberships.length > 0) {
        await base44.entities.CompetitionMember.bulkUpdate(
          myMemberships.map(m => ({ id: m.id, user_name: displayName }))
        );
      }
      const updatedUser = { ...user, display_name: displayName, bio, avatar_url: avatarUrl };
      queryClient.setQueryData(['me'], updatedUser);
      queryClient.invalidateQueries({ queryKey: ['members'] });
      queryClient.invalidateQueries({ queryKey: ['public-profile'] });
      queryClient.invalidateQueries({ queryKey: ['public-profiles'] });
      await syncPublicProfile(updatedUser);
    }
    setSaving(false);
    setEditMode(false);
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingAvatar(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      setAvatarUrl(result.file_url);
    } catch (err) {
      console.error('Avatar upload failed', err);
    }
    setUploadingAvatar(false);
    e.target.value = '';
  };

  const handleSendFeedback = async () => {
    if (!feedbackText.trim() || sendingFeedback) return;
    setSendingFeedback(true);
    setFeedbackError(false);
    try {
      const senderName = isGuest ? t('guest.guestName') : (displayName || user?.full_name || user?.email || 'Unknown');
      const senderEmail = isGuest ? '(vierailija)' : (user?.email || '(ei sähköpostia)');
      await base44.integrations.Core.SendEmail({
        to: 'support.splitnow@gmail.com',
        subject: t('profile.feedbackSubject'),
        body: `${t('profile.feedbackSender')}: ${senderName} (${senderEmail})\n\n${feedbackText}`
      });
      setFeedbackSent(true);
      setFeedbackText('');
      setTimeout(() => setFeedbackSent(false), 3000);
    } catch (err) {
      console.error('Feedback send failed', err);
      setFeedbackError(true);
      setTimeout(() => setFeedbackError(false), 5000);
    }
    setSendingFeedback(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const guestName = t('guest.guestName');
  const initials = isGuest ? guestName[0].toUpperCase() : (displayName || user?.full_name || user?.email || '?')[0].toUpperCase();

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none" />

      <div className="relative px-4 pt-14 pb-4">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-black text-foreground">{t('profile.title')}</h1>
            <button
              onClick={() => navigate('/settings')}
              className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center active:scale-95 transition-transform"
            >
              <Settings className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>

          <div className="bg-card rounded-3xl border border-border shadow-sm p-5 mb-4">
            {editMode ? (
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <label className="relative w-20 h-20 rounded-full bg-primary/15 flex items-center justify-center cursor-pointer overflow-hidden">
                    {avatarUrl ? (
                      <img src={avatarUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-primary font-black text-2xl">{initials}</span>
                    )}
                    {uploadingAvatar && (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <Loader2 className="w-6 h-6 text-white animate-spin" />
                      </div>
                    )}
                    <div className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-primary flex items-center justify-center border-2 border-card">
                      <Camera className="w-3.5 h-3.5 text-primary-foreground" />
                    </div>
                    <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploadingAvatar} />
                  </label>
                  <div className="flex-1">
                    <input
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder={t('settings.fullNamePlaceholder')}
                      className="w-full h-11 px-4 rounded-xl bg-muted text-foreground border border-border text-base font-bold focus:outline-none focus:border-primary"
                    />
                    {!isGuest && <p className="text-xs text-muted-foreground mt-1">{user?.email}</p>}
                  </div>
                </div>
                <div>
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide block mb-1.5">
                    {t('profile.bio')}
                  </label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder={t('profile.bioPlaceholder')}
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl bg-muted text-foreground border border-border text-sm focus:outline-none focus:border-primary resize-none"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setEditMode(false)}
                    className="flex-1 h-11 rounded-xl bg-muted text-foreground font-bold text-sm flex items-center justify-center gap-1.5 active:scale-95 transition-transform"
                  >
                    <X className="w-4 h-4" /> {t('common.cancel')}
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="flex-1 h-11 rounded-xl bg-primary text-primary-foreground font-bold text-sm flex items-center justify-center gap-1.5 active:scale-95 transition-transform"
                  >
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                    {t('common.save')}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-20 h-20 rounded-full bg-primary/15 flex items-center justify-center overflow-hidden">
                    {avatarUrl ? (
                      <img src={avatarUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-primary font-black text-2xl">{initials}</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-black text-lg text-foreground truncate">{isGuest ? guestName : (displayName || user?.full_name || t('settings.noName'))}</p>
                    {!isGuest && <p className="text-sm text-muted-foreground truncate">{user?.email}</p>}
                    <button
                      onClick={() => setEditMode(true)}
                      className="mt-2 text-xs font-bold text-primary active:scale-95 transition-transform"
                    >
                      {t('profile.editProfile')}
                    </button>
                  </div>
                </div>

                {bio && (
                  <p className="text-sm text-muted-foreground mb-3">{bio}</p>
                )}

                {!isGuest && (
                  <div className="flex gap-4 py-3 border-t border-border">
                    <div>
                      <p className="font-black text-lg text-foreground">{allComps.length}</p>
                      <p className="text-xs text-muted-foreground">{t('profile.competitionHistory')}</p>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {allComps.length > 0 && (
            <div className="mb-4">
              <p className="text-xs font-black uppercase tracking-widest text-muted-foreground mb-2 px-1">
                {t('profile.competitionHistory')}
              </p>
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                {allComps.slice(0, 5).map((comp, i) => (
                  <Link
                    key={comp.id}
                    to={`/competition/${comp.id}/startlist`}
                    className={`flex items-center gap-3 px-4 py-3 active:bg-muted transition-colors ${
                      i < Math.min(allComps.length, 5) - 1 ? 'border-b border-border' : ''
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center flex-shrink-0">
                      <Trophy className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-foreground truncate">{comp.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {comp.date ? format(new Date(comp.date), 'd.M.yyyy') : ''}
                        {comp.location ? ` · ${comp.location}` : ''}
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </Link>
                ))}
              </div>
            </div>
          )}

          <div className="bg-card rounded-2xl border border-border p-4 mb-4">
            <div className="flex items-center gap-2 mb-3">
              <MessageSquare className="w-4 h-4 text-primary" />
              <p className="font-bold text-sm text-foreground">{t('profile.feedback')}</p>
            </div>
            <textarea
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              placeholder={t('profile.feedbackPlaceholder')}
              rows={3}
              className="w-full px-3 py-2.5 rounded-xl bg-muted text-foreground border border-border text-sm focus:outline-none focus:border-primary resize-none"
            />
            <button
              onClick={handleSendFeedback}
              disabled={!feedbackText.trim() || feedbackSent || sendingFeedback}
              className="w-full h-10 mt-2 rounded-xl bg-primary/10 text-primary font-bold text-sm active:scale-95 transition-transform flex items-center justify-center gap-1.5"
            >
              {feedbackSent ? (
                `✓ ${t('profile.feedbackSent')}`
              ) : feedbackError ? (
                t('profile.feedbackError')
              ) : sendingFeedback ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> {t('profile.feedbackSending')}</>
              ) : (
                t('profile.feedbackSend')
              )}
            </button>
            {feedbackError && (
              <p className="text-xs text-destructive mt-2 text-center">{t('profile.feedbackErrorDesc')}</p>
            )}
          </div>

        </div>
      </div>

    </div>
  );
}