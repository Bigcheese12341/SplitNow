import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Trophy, ChevronRight, Flag, Lock } from 'lucide-react';
import { format } from 'date-fns';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import ReportNotification from '@/components/ReportNotification';

export default function UserProfile() {
  const { t } = useTranslation();
  const { userId } = useParams();
  const navigate = useNavigate();
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const closeNotification = useCallback(() => setShowNotification(false), []);

  const { data: currentUser } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me()
  });

  useEffect(() => {
    if (currentUser?.id && userId === currentUser.id) {
      navigate('/profile', { replace: true });
    }
  }, [currentUser?.id, userId, navigate]);

  const { data: targetUser, isLoading } = useQuery({
    queryKey: ['public-profile', userId],
    queryFn: async () => {
      const profiles = await base44.entities.PublicProfile.filter({ user_id: userId });
      return profiles[0];
    },
    enabled: !!userId
  });

  const isPrivate = !targetUser || targetUser.is_profile_public === false;

  const { data: publicComps = [] } = useQuery({
    queryKey: ['user-public-competitions', userId],
    queryFn: () => base44.entities.Competition.filter({ created_by_id: userId, is_public: true }, '-created_date'),
    enabled: !!userId && !isPrivate
  });

  const handleReport = async () => {
    setShowReportDialog(false);
    setShowNotification(true);

    const reporterName = currentUser?.full_name || currentUser?.email || 'Tuntematon';
    const reportedName = targetUser?.display_name || targetUser?.full_name || 'Tuntematon';
    try {
      await base44.integrations.Core.SendEmail({
        to: 'support.splitnow@gmail.com',
        subject: `Käyttäjäilmoitus: ${reportedName}`,
        body: `Käyttäjä on ilmiannettu.\n\nIlmoittaja: ${reporterName} (${currentUser?.email || 'N/A'})\nIlmiannettu: ${reportedName} (ID: ${userId})\nAika: ${new Date().toLocaleString('fi-FI')}`,
      });
    } catch (e) {
      // Email sending failed silently — notification still shows
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (isPrivate) {
    return (
      <div className="min-h-screen bg-background">
        <div className="px-4 pt-14 pb-4">
          <div className="max-w-lg mx-auto">
            <div className="flex items-center justify-between mb-6">
              <button onClick={() => navigate(-1)} className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center active:scale-95 transition-transform">
                <ArrowLeft className="w-5 h-5 text-muted-foreground" />
              </button>
              <button
                onClick={() => setShowReportDialog(true)}
                className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center active:scale-95 transition-transform"
              >
                <Flag className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Lock className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="font-black text-lg text-foreground mb-1">{t('profile.privateProfile')}</p>
              <p className="text-sm text-muted-foreground">{t('profile.privateProfileDesc')}</p>
            </div>
          </div>
        </div>

        <AlertDialog open={showReportDialog} onOpenChange={setShowReportDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>{t('profile.reportUser')}</AlertDialogTitle>
              <AlertDialogDescription>
                {t('profile.reportUserConfirm')}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
              <AlertDialogAction onClick={handleReport} className="bg-destructive text-destructive-foreground">
                {t('profile.reportUser')}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <ReportNotification
          visible={showNotification}
          onClose={closeNotification}
          message={t('profile.reportSentDesc')}
        />
      </div>
    );
  }

  const displayName = targetUser.display_name || targetUser.full_name || t('settings.noName');
  const initials = displayName[0].toUpperCase();
  const avatarUrl = targetUser.avatar_url;

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none" />

      <div className="relative px-4 pt-14 pb-4">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between mb-6">
            <button onClick={() => navigate(-1)} className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center active:scale-95 transition-transform">
              <ArrowLeft className="w-5 h-5 text-muted-foreground" />
            </button>
            <button
              onClick={() => setShowReportDialog(true)}
              className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center active:scale-95 transition-transform"
            >
              <Flag className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>

          <div className="bg-card rounded-3xl border border-border shadow-sm p-5 mb-4">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-20 h-20 rounded-full bg-primary/15 flex items-center justify-center overflow-hidden">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-primary font-black text-2xl">{initials}</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-black text-lg text-foreground truncate">{displayName}</p>
                {targetUser.email && (
                  <p className="text-sm text-muted-foreground mt-1 truncate">{targetUser.email}</p>
                )}
                {targetUser.bio && (
                  <p className="text-sm text-muted-foreground mt-1">{targetUser.bio}</p>
                )}
              </div>
            </div>

            <div className="flex gap-4 py-3 border-t border-border">
              <div>
                <p className="font-black text-lg text-foreground">{publicComps.length}</p>
                <p className="text-xs text-muted-foreground">{t('profile.publicCompetitions')}</p>
              </div>
            </div>
          </div>

          {publicComps.length > 0 ? (
            <div className="mb-4">
              <p className="text-xs font-black uppercase tracking-widest text-muted-foreground mb-2 px-1">
                {t('profile.publicCompetitions')}
              </p>
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                {publicComps.map((comp, i) => (
                  <Link
                    key={comp.id}
                    to={`/competition/${comp.id}/public`}
                    className={`flex items-center gap-3 px-4 py-3 active:bg-muted transition-colors ${
                      i < publicComps.length - 1 ? 'border-b border-border' : ''
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center flex-shrink-0">
                      <Trophy className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-foreground truncate">{comp.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {comp.date ? format(new Date(comp.date), 'd.M.yyyy') : ''}
                        {comp.location ? ` · ${comp.location}` : ''}
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground text-sm">
              {t('profile.noPublicCompetitions')}
            </div>
          )}
        </div>
      </div>

      <AlertDialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('profile.reportUser')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('profile.reportUserConfirm')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleReport} className="bg-destructive text-destructive-foreground">
              {t('profile.reportUser')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <ReportNotification
        visible={showNotification}
        onClose={closeNotification}
        message={t('profile.reportSentDesc')}
      />
    </div>
  );
}