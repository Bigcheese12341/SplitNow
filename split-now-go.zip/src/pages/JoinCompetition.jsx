import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { Hash, QrCode, Link2, Loader2, Search, Trophy, ChevronRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import GuestLoginOverlay from '@/components/GuestLoginOverlay';
import { isGuestMode } from '@/lib/guestMode';
import { sportLabel } from '@/lib/sportLabels';
import jsQR from 'jsqr';

export default function JoinCompetition() {
  const { t } = useTranslation();
  const guest = isGuestMode();

  return (
    <div className="relative min-h-screen bg-background">
      <div className={guest ? 'opacity-50 pointer-events-none select-none' : ''}>
        <JoinCompetitionContent />
      </div>
      {guest && <GuestLoginOverlay message={t('guest.joinCompetitionRequiresLogin')} />}
    </div>
  );
}

function JoinCompetitionContent() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [tab, setTab] = useState('code');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [cameraError, setCameraError] = useState('');
  const [showCameraPrompt, setShowCameraPrompt] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const { data: publicComps = [] } = useQuery({
    queryKey: ['public-competitions-search'],
    queryFn: () => base44.entities.Competition.filter({ is_public: true }, '-created_date', 50)
  });

  const filteredComps = searchQuery.trim()
    ? publicComps.filter(c => {
        const q = searchQuery.toLowerCase();
        return c.name?.toLowerCase().includes(q) || c.sport?.toLowerCase().includes(q) || c.location?.toLowerCase().includes(q);
      })
    : publicComps;
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const canvasRef = useRef(null);
  const scanLoopRef = useRef(null);

  useEffect(() => {
    const joinCode = searchParams.get('join');
    if (joinCode) {
      setCode(joinCode);
      handleJoin(joinCode);
    }
  }, []);

  useEffect(() => {
    return () => stopCamera();
  }, []);

  useEffect(() => {
    if (tab === 'qr') {
      if (localStorage.getItem('qr_camera_allowed') === 'true') {
        startCamera();
      } else {
        setShowCameraPrompt(true);
      }
    } else {
      stopCamera();
      setShowCameraPrompt(false);
    }
  }, [tab]);

  const allowCamera = () => {
    localStorage.setItem('qr_camera_allowed', 'true');
    setShowCameraPrompt(false);
    startCamera();
  };

  const cancelCameraPrompt = () => {
    setShowCameraPrompt(false);
    setCameraError(t('join.cameraDenied'));
  };

  const startCamera = async () => {
    setCameraError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
      }
      startScanning();
    } catch {
      setCameraError(t('join.cameraDenied'));
    }
  };

  const startScanning = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) {
      scanLoopRef.current = requestAnimationFrame(startScanning);
      return;
    }
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    const tick = () => {
      if (video.readyState === video.HAVE_ENOUGH_DATA && video.videoWidth > 0) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: 'dontInvert' });
        if (code && code.data) {
          const match = code.data.match(/[?&]join=([A-Za-z0-9]+)/);
          const joinCode = match ? match[1] : (code.data.trim().length === 6 ? code.data.trim() : null);
          if (joinCode) {
            stopScanning();
            stopStream();
            handleJoin(joinCode);
            return;
          }
        }
      }
      scanLoopRef.current = requestAnimationFrame(tick);
    };
    scanLoopRef.current = requestAnimationFrame(tick);
  };

  const stopScanning = () => {
    if (scanLoopRef.current) {
      cancelAnimationFrame(scanLoopRef.current);
      scanLoopRef.current = null;
    }
  };

  const stopStream = () => {
    stopScanning();
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const stopCamera = () => {
    stopStream();
  };

  const handleJoin = async (joinCode) => {
    const trimmed = (joinCode || code).trim().toUpperCase();
    if (trimmed.length !== 6) {
      setError(t('join.invalidCode'));
      return;
    }
    setLoading(true);
    setError('');
    const results = await base44.entities.Competition.filter({ join_code: trimmed });
    if (!results || results.length === 0) {
      setError(t('join.notFound'));
      setLoading(false);
      return;
    }
    const comp = results[0];
    const user = await base44.auth.me();

    const existing = await base44.entities.CompetitionMember.filter({ competition_id: comp.id, user_id: user.id });
    if (!existing || existing.length === 0) {
      await base44.entities.CompetitionMember.create({
        competition_id: comp.id,
        user_id: user.id,
        user_email: user.email,
        user_name: user.display_name || user.full_name || user.email,
        role: comp.default_join_role || 'viewer',
      });
    }

    setLoading(false);
    navigate(`/competition/${comp.id}/startlist`);
  };

  const handleJoinById = async (comp) => {
    setLoading(true);
    const user = await base44.auth.me();
    const existing = await base44.entities.CompetitionMember.filter({ competition_id: comp.id, user_id: user.id });
    if (!existing || existing.length === 0) {
      await base44.entities.CompetitionMember.create({
        competition_id: comp.id,
        user_id: user.id,
        user_email: user.email,
        user_name: user.display_name || user.full_name || user.email,
        role: comp.default_join_role || 'viewer',
      });
    }
    setLoading(false);
    navigate(`/competition/${comp.id}/startlist`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 pt-14 pb-24">
        <h1 className="text-2xl font-black text-foreground mb-1">{t('join.title')}</h1>
        <p className="text-muted-foreground text-sm mb-8">{t('join.subtitle')}</p>

        <div className="flex gap-2 mb-6">
          {[
            { id: 'code', icon: Hash, label: t('join.codeTab') },
            { id: 'qr', icon: QrCode, label: t('join.qrTab') },
            { id: 'search', icon: Search, label: t('join.searchTab') },
          ].map(tabItem => (
            <button
              key={tabItem.id}
              onClick={() => setTab(tabItem.id)}
              className={`flex-1 flex items-center justify-center gap-2 h-11 rounded-xl font-bold text-sm transition-all ${
                tab === tabItem.id ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/30' : 'bg-card text-muted-foreground'
              }`}
            >
              <tabItem.icon className="w-4 h-4" />
              {tabItem.label}
            </button>
          ))}
        </div>

        {tab === 'code' && (
          <div className="space-y-4">
            <div className="bg-card rounded-2xl p-5">
              <p className="text-muted-foreground text-xs font-semibold uppercase tracking-wider mb-3">{t('join.codeLabel')}</p>
              <Input
                value={code}
                onChange={e => {
                  const val = e.target.value.replace(/[^0-9A-Za-z]/g, '').toUpperCase().slice(0, 6);
                  setCode(val);
                  setError('');
                }}
                placeholder="XXXXXX"
                className="h-16 text-center text-3xl font-black tracking-widest bg-muted border-border text-foreground rounded-xl"
                maxLength={6}
              />
              {error && <p className="text-destructive text-sm mt-2 text-center">{error}</p>}
            </div>

            <Button
              onClick={() => handleJoin()}
              disabled={loading || code.length < 6}
              className="w-full h-14 text-lg font-bold rounded-2xl"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('join.join')}
            </Button>
          </div>
        )}

        {tab === 'qr' && (
          <div className="bg-card rounded-2xl overflow-hidden">
            {showCameraPrompt ? (
              <div className="p-8 text-center">
                <div className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center mx-auto mb-4">
                  <QrCode className="w-8 h-8 text-primary" />
                </div>
                <p className="font-bold text-foreground text-lg mb-2">{t('join.cameraPermissionTitle')}</p>
                <p className="text-muted-foreground text-sm mb-6">{t('join.cameraPermissionDesc')}</p>
                <div className="flex gap-2">
                  <button
                    onClick={cancelCameraPrompt}
                    className="flex-1 h-12 rounded-xl bg-muted text-foreground font-bold text-sm active:scale-95 transition-transform"
                  >
                    {t('common.cancel')}
                  </button>
                  <button
                    onClick={allowCamera}
                    className="flex-1 h-12 rounded-xl bg-primary text-primary-foreground font-bold text-sm active:scale-95 transition-transform"
                  >
                    {t('join.allowCamera')}
                  </button>
                </div>
              </div>
            ) : cameraError ? (
              <div className="p-8 text-center">
                <QrCode className="w-12 h-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">{cameraError}</p>
                <button onClick={() => setTab('code')} className="mt-4 text-primary font-bold text-sm">
                  {t('join.useCode')}
                </button>
              </div>
            ) : (
              <div className="relative">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full aspect-square object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-48 h-48 border-2 border-primary rounded-2xl opacity-70" />
                </div>
                <p className="text-center text-muted-foreground text-sm py-4 px-4">
                  {t('join.scanHint')}
                </p>
                <canvas ref={canvasRef} className="hidden" />
              </div>
            )}
          </div>
        )}

        {tab === 'search' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="w-5 h-5 text-muted-foreground absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('join.searchPlaceholder')}
                className="w-full h-12 pl-12 pr-4 rounded-2xl bg-card border border-border text-base font-medium text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary shadow-sm"
              />
            </div>
            <div className="space-y-2">
              {filteredComps.length === 0 ? (
                <p className="text-center text-muted-foreground text-sm py-8">{t('join.noSearchResults')}</p>
              ) : (
                filteredComps.map(comp => (
                  <button
                    key={comp.id}
                    onClick={() => navigate(`/competition/${comp.id}/public`)}
                    className="w-full bg-card rounded-2xl border border-border p-4 flex items-center gap-3 active:scale-[0.98] transition-transform text-left"
                  >
                    <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center flex-shrink-0">
                      <Trophy className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-foreground truncate">{comp.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {comp.sport ? `${comp.sport} · ` : ''}
                        {comp.location || ''}
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </button>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}