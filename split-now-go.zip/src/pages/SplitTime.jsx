import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import CompetitionNav from '@/components/competition/CompetitionNav';
import RecordedList from '@/components/competition/RecordedList';
import WaitingList from '@/components/competition/WaitingList';
import SplitTimeSheet from '@/components/competition/SplitTimeSheet';
import { useUserRole } from '@/lib/permissions';
import { parseTimeToSeconds, nowInSeconds, formatElapsed } from '@/lib/timeUtils';
import { groupKey } from '@/lib/seriesUtils';
import { useSeriesPalette } from '@/lib/seriesPalette';
import { computeStandings, bestTimeInGroup } from '@/lib/comparisonUtils';
import { hapticPress } from '@/lib/haptics';
import { execOrQueue, cacheData, getCachedData, updateCachedCompetitor, removeCachedCompetitor, subscribe, isOnline } from '@/lib/syncQueue';

export default function SplitTime() {
  const { t } = useTranslation();
  const { id, splitNum } = useParams();
  const navigate = useNavigate();
  const { permissions, isLoading: roleLoading } = useUserRole(id);
  const splitIndex = Number(splitNum) - 1;
  const queryClient = useQueryClient();
  const [currentTime, setCurrentTime] = useState(nowInSeconds());
  const [flashResults, setFlashResults] = useState({});
  const [lastEntry, setLastEntry] = useState(null);
  const [selectedComp, setSelectedComp] = useState(null);
  const [sheetOpen, setSheetOpen] = useState(false);
  const undoTimer = useRef(null);
  const [online, setOnline] = useState(isOnline());

  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(nowInSeconds()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    return subscribe((status) => setOnline(status !== 'offline'));
  }, []);

  useEffect(() => {
    if (!roleLoading && !permissions.canViewSplits) {
      navigate(`/competition/${id}/results`, { replace: true });
    }
  }, [roleLoading, permissions.canViewSplits]);

  const { data: competition } = useQuery({
    queryKey: ['competition', id],
    queryFn: async () => {
      try {
        const data = await base44.entities.Competition.filter({ id });
        cacheData(`competition_${id}`, data[0]);
        return data[0];
      } catch (err) {
        if (!navigator.onLine) return getCachedData(`competition_${id}`);
        throw err;
      }
    },
  });

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors', id],
    queryFn: async () => {
      try {
        const data = await base44.entities.Competitor.filter({ competition_id: id }, 'bib_number');
        cacheData(`competitors_${id}`, data);
        return data;
      } catch (err) {
        if (!navigator.onLine) return getCachedData(`competitors_${id}`) || [];
        throw err;
      }
    },
    refetchInterval: online ? 5000 : false,
  });

  useSeriesPalette(competitors, competition);

  const handleNow = useCallback(async (competitor, manualElapsed = null) => {
    const now = nowInSeconds();
    const startSec = parseTimeToSeconds(competitor.start_time);
    const elapsed = manualElapsed !== null ? manualElapsed : Math.round((now - startSec) * 100) / 100;

    const prevSplitTimes = [...(competitor.split_times || [])];
    const splitTimes = prevSplitTimes.filter(s => s.split_index !== splitIndex);
    splitTimes.push({ split_index: splitIndex, timestamp: new Date().toISOString(), elapsed });

    // The competitor is compared only with its own comparison group, which
    // follows the competition's active classification settings.
    const group = groupKey(competitor, competition);
    const prevLeaderTime = bestTimeInGroup(competitors, competition, splitIndex, group, competitor.id);
    const isNewLeader = prevLeaderTime === null || elapsed < prevLeaderTime;

    const projected = competitors.map(c => (
      c.id === competitor.id ? { ...c, split_times: splitTimes } : c
    ));
    const standing = computeStandings(projected, competition, splitIndex).byId[competitor.id] || {};

    hapticPress();

    setFlashResults(prev => ({
      ...prev,
      [competitor.id]: {
        elapsed,
        rank: standing.rank,
        gap: standing.gap,
        isNewLeader: isNewLeader && standing.rank === 1,
        prevLeaderTime,
      },
    }));

    setTimeout(() => {
      setFlashResults(prev => {
        const next = { ...prev };
        delete next[competitor.id];
        return next;
      });
    }, 5000);

    if (undoTimer.current) clearTimeout(undoTimer.current);
    setLastEntry({ competitorId: competitor.id, prevSplitTimes });
    undoTimer.current = setTimeout(() => setLastEntry(null), 15000);

    updateCachedCompetitor(id, competitor.id, { split_times: splitTimes });
    await execOrQueue('Competitor', 'update', competitor.id, { split_times: splitTimes });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [splitIndex, id, queryClient, competitors, competition]);

  const handleUndo = useCallback(async (competitor) => {
    if (competitor) {
      const prevSplitTimes = (competitor.split_times || []).filter(s => s.split_index !== splitIndex);
      queryClient.setQueryData(['competitors', id], (old) =>
        old?.map(c => c.id === competitor.id ? { ...c, split_times: prevSplitTimes } : c)
      );
      updateCachedCompetitor(id, competitor.id, { split_times: prevSplitTimes });
      await execOrQueue('Competitor', 'update', competitor.id, { split_times: prevSplitTimes });
    } else {
      if (!lastEntry) return;
      const entryToUndo = lastEntry;
      queryClient.setQueryData(['competitors', id], (old) =>
        old?.map(c => c.id === entryToUndo.competitorId ? { ...c, split_times: entryToUndo.prevSplitTimes } : c)
      );
      updateCachedCompetitor(id, entryToUndo.competitorId, { split_times: entryToUndo.prevSplitTimes });
      if (undoTimer.current) clearTimeout(undoTimer.current);
      await execOrQueue('Competitor', 'update', entryToUndo.competitorId, { split_times: entryToUndo.prevSplitTimes });
      setLastEntry(null);
    }
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [lastEntry, splitIndex, id, queryClient]);

  const handleSetStatus = useCallback(async (competitor, status) => {
    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, status } : c)
    );
    updateCachedCompetitor(id, competitor.id, { status });
    await execOrQueue('Competitor', 'update', competitor.id, { status });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [queryClient, id]);

  const handleDelete = useCallback(async (competitor) => {
    queryClient.setQueryData(['competitors', id], (old) =>
      old?.filter(c => c.id !== competitor.id)
    );
    removeCachedCompetitor(id, competitor.id);
    await execOrQueue('Competitor', 'delete', competitor.id);
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [queryClient, id]);

  const handleSaveName = useCallback(async (competitor, name) => {
    queryClient.setQueryData(['competitors', id], (old) =>
      old?.map(c => c.id === competitor.id ? { ...c, name } : c)
    );
    updateCachedCompetitor(id, competitor.id, { name });
    await execOrQueue('Competitor', 'update', competitor.id, { name });
    queryClient.invalidateQueries({ queryKey: ['competitors', id] });
  }, [queryClient, id]);

  const openSheet = (competitor) => {
    setSelectedComp(competitor);
    setSheetOpen(true);
  };

  // Build lists
  const recorded = [];
  const unrecorded = [];

  competitors.forEach(c => {
    const compStatus = c.status || 'active';
    const flash = flashResults[c.id];

    if (compStatus === 'DNS' || compStatus === 'DSQ') {
      recorded.push({ ...c, elapsed: null, isDNS: compStatus === 'DNS', isDSQ: compStatus === 'DSQ' });
      return;
    }

    if (flash) {
      recorded.push({ ...c, elapsed: flash.elapsed, isFlash: true, flashData: flash });
      unrecorded.push({ ...c, flashData: flash });
    } else {
      const split = (c.split_times || []).find(s => s.split_index === splitIndex);
      if (compStatus === 'DNF') {
        recorded.push({ ...c, elapsed: null, isDNF: true });
      } else if (split) {
        if (split.status === 'DNF') {
          recorded.push({ ...c, elapsed: null, isDNF: true });
        } else {
          recorded.push({ ...c, elapsed: split.elapsed });
        }
      } else {
        unrecorded.push(c);
      }
    }
  });

  recorded.sort((a, b) => {
    if (a.elapsed === null) return 1;
    if (b.elapsed === null) return -1;
    return a.elapsed - b.elapsed;
  });

  const leaderTime = recorded.find(c => c.elapsed !== null)?.elapsed || 0;

  // Rank and gap inside each competitor's own comparison group.
  const standings = computeStandings(
    recorded.map(c => ({
      id: c.id,
      gender: c.gender,
      age: c.age,
      status: c.isDNS ? 'DNS' : c.isDNF ? 'DNF' : c.isDSQ ? 'DSQ' : 'active',
      split_times: c.elapsed !== null ? [{ split_index: splitIndex, elapsed: c.elapsed }] : [],
    })),
    competition,
    splitIndex
  ).byId;

  const validRecorded = recorded.filter(c => c.elapsed !== null && !c.isFlash);
  const avgElapsed = validRecorded.length > 0
    ? validRecorded.reduce((sum, c) => sum + c.elapsed, 0) / validRecorded.length
    : null;

  let nextExpectedId = null;
  if (unrecorded.length > 0 && !Object.keys(flashResults).length) {
    let bestDiff = Infinity;
    unrecorded.forEach(c => {
      const startSec = parseTimeToSeconds(c.start_time);
      const predictedArrival = avgElapsed ? startSec + avgElapsed : startSec;
      const diff = Math.abs(currentTime - predictedArrival);
      if (diff < bestDiff) {
        bestDiff = diff;
        nextExpectedId = c.id;
      }
    });
  }

  const totalCount = competitors.length;
  const recordedCount = recorded.length;
  const progressPct = totalCount > 0 ? Math.round((recordedCount / totalCount) * 100) : 0;

  const now = new Date();
  const liveTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

  return (
    <div className="min-h-screen bg-background">
      <CompetitionNav competition={competition} />

      {/* Stats bar */}
      <div className="bg-card border-b border-border">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
          <div className="text-center">
            <div className="text-xs text-muted-foreground font-medium">{t('splitTime.clock')}</div>
            <div className="font-mono font-bold text-base tabular-nums">{liveTime}</div>
          </div>
          <div className="text-center">
            <div className="text-xs text-muted-foreground font-medium">{t('splitTime.recordedCount')}</div>
            <div className="font-bold text-base">{recordedCount} / {totalCount}</div>
          </div>
          <div className="text-center">
            <div className="text-xs text-muted-foreground font-medium">{t('splitTime.leader')}</div>
            <div className="font-mono font-bold text-base tabular-nums text-primary">
              {leaderTime > 0 ? formatElapsed(leaderTime) : '—'}
            </div>
          </div>
        </div>
        <div className="h-1 bg-muted mx-4 mb-3 rounded-full overflow-hidden">
          <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${progressPct}%` }} />
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-4 space-y-5">
        {recorded.length > 0 && (
          <RecordedList
            recorded={recorded}
            standings={standings}
            competition={competition}
            lastEntry={lastEntry}
            onUndo={handleUndo}
            onCompetitorTap={openSheet}
          />
        )}

        {unrecorded.length > 0 && (
          <WaitingList
            unrecorded={unrecorded}
            nextExpectedId={nextExpectedId}
            flashResults={flashResults}
            competition={competition}
            onNow={handleNow}
            onCompetitorTap={openSheet}
          />
        )}

        {competitors.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">{t('splitTime.noCompetitors')}</div>
        )}
      </div>

      <SplitTimeSheet
        competitor={selectedComp}
        competition={competition}
        splitIndex={splitIndex}
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        onUndo={handleUndo}
        onManualTime={handleNow}
        onSetStatus={handleSetStatus}
        onDelete={handleDelete}
        onSaveName={handleSaveName}
        permissions={permissions}
      />
    </div>
  );
}