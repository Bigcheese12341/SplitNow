import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTheme } from '@/lib/ThemeContext';
import { changeLanguage } from '@/i18n';
import {
  User, Globe, Moon, Bell, Shield, Info, LogOut, Trash2, ChevronRight, ArrowLeft, Check, Lock, Volume2, Vibrate, LogIn
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { isSoundEnabled, isVibrationEnabled, setSoundEnabled as saveSoundEnabled, setVibrationEnabled as saveVibrationEnabled } from '@/lib/haptics';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useAuth } from '@/lib/AuthContext';
import { goBack } from '@/lib/navHistory';
import { syncPublicProfile } from '@/lib/syncPublicProfile';
import AboutAppScreen from '@/components/settings/AboutAppScreen';
import PrivacyTermsScreen from '@/components/settings/PrivacyTermsScreen';

const languages = [
  { code: 'fi', label: 'Suomi', flag: '🇫🇮' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'sv', label: 'Svenska', flag: '🇸🇪' },
];

export default function Settings() {
  const { t, i18n } = useTranslation();
  const { navigateToLogin } = useAuth();
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [section, setSection] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);
  const [profileForm, setProfileForm] = useState({ name: '', email: '' });
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showPrivacyDialog, setShowPrivacyDialog] = useState(false);
  const [pendingPrivacy, setPendingPrivacy] = useState(null);
  const [soundEnabled, setSoundEnabledState] = useState(isSoundEnabled());
  const [vibrationEnabled, setVibrationEnabledState] = useState(isVibrationEnabled());

  const themes = [
    { id: 'light', label: t('settings.themeLight') },
    { id: 'dark', label: t('settings.themeDark') },
    { id: 'system', label: t('settings.themeSystem') },
  ];

  const { data: user } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me(),
  });

  useEffect(() => {
    if (user) setProfileForm({ name: user.display_name || user.full_name || '', email: user.email || '' });
  }, [user]);

  const handleSaveProfile = async () => {
    setSaving(true);
    const me = await base44.auth.me();
    await base44.auth.updateMe({ display_name: profileForm.name });
    const myMemberships = await base44.entities.CompetitionMember.filter({ user_id: me.id });
    if (myMemberships.length > 0) {
      await base44.entities.CompetitionMember.bulkUpdate(
        myMemberships.map(m => ({ id: m.id, user_name: profileForm.name }))
      );
    }
    const updatedUser = { ...user, display_name: profileForm.name };
    queryClient.setQueryData(['me'], updatedUser);
    queryClient.invalidateQueries({ queryKey: ['members'] });
    queryClient.invalidateQueries({ queryKey: ['public-profile'] });
    queryClient.invalidateQueries({ queryKey: ['public-profiles'] });
    await syncPublicProfile(updatedUser);
    setSaving(false);
    setSection(null);
  };

  const handlePrivacyToggle = (checked) => {
    setPendingPrivacy(checked);
    setShowPrivacyDialog(true);
  };

  const handleSoundToggle = (checked) => {
    setSoundEnabledState(checked);
    saveSoundEnabled(checked);
  };

  const handleVibrationToggle = (checked) => {
    setVibrationEnabledState(checked);
    saveVibrationEnabled(checked);
  };

  const handlePrivacyConfirm = async () => {
    const value = pendingPrivacy;
    setShowPrivacyDialog(false);
    await base44.auth.updateMe({ is_profile_public: value });
    const updatedUser = { ...user, is_profile_public: value };
    queryClient.setQueryData(['me'], updatedUser);
    queryClient.invalidateQueries({ queryKey: ['public-profile'] });
    queryClient.invalidateQueries({ queryKey: ['public-profiles'] });
    await syncPublicProfile(updatedUser);
  };

  const handleLangSelect = async (code) => {
    changeLanguage(code);
    try { await base44.auth.updateMe({ language: code }); } catch {}
  };

  const handleLogout = () => base44.auth.logout('/');
  const handleDeleteAccount = async () => {
    setDeleting(true);
    try {
      const me = await base44.auth.me();

      const myComps = await base44.entities.Competition.filter({ created_by_id: me.id });
      for (const comp of myComps) {
        await base44.entities.Competitor.deleteMany({ competition_id: comp.id });
        await base44.functions.invoke('manageCompetitionMember', { action: 'purgeMembers', competitionId: comp.id });
      }
      if (myComps.length > 0) {
        await base44.entities.Competition.deleteMany({ created_by_id: me.id });
      }

      await base44.entities.CompetitionMember.deleteMany({ user_id: me.id });

      try { await base44.entities.User.delete(me.id); } catch {}

      base44.auth.logout('/');
    } catch (err) {
      console.error('Account deletion failed', err);
      setDeleting(false);
    }
  };

  const isGuest = user?.is_guest;

  const menuItems = [
    ...(!isGuest ? [{ id: 'profile', icon: User, label: t('settings.profile'), sub: user?.display_name || user?.full_name || user?.email || '' }] : []),
    { id: 'language', icon: Globe, label: t('settings.language'), sub: languages.find(l => l.code === i18n.language)?.label },
    { id: 'theme', icon: Moon, label: t('settings.theme'), sub: themes.find(th => th.id === theme)?.label },
    { id: 'notifications', icon: Bell, label: t('settings.notifications'), sub: t('settings.on') },
  ];

  const infoItems = [
    { id: 'privacyTerms', label: t('settings.privacyTerms'), icon: Shield },
    { id: 'about', label: t('settings.aboutApp'), icon: Info },
  ];

  if (section === 'profile') {
    return (
      <SubScreen title={t('settings.profile')} onBack={() => setSection(null)}>
        <div className="space-y-4 px-4">
          <Field label={t('settings.nameLabel')}>
            <input
              className="w-full h-12 px-4 rounded-xl bg-muted text-foreground border border-border text-base focus:outline-none focus:border-primary"
              value={profileForm.name}
              onChange={e => setProfileForm(f => ({ ...f, name: e.target.value }))}
              placeholder={t('settings.fullNamePlaceholder')}
            />
          </Field>
          <Field label={t('settings.emailLabel')}>
            <input
              className="w-full h-12 px-4 rounded-xl bg-muted text-muted-foreground border border-border text-base opacity-60 cursor-not-allowed"
              value={profileForm.email}
              disabled
            />
          </Field>
          <button
            onClick={handleSaveProfile}
            disabled={saving}
            className="w-full h-12 rounded-xl bg-primary text-primary-foreground font-bold mt-2 active:scale-[0.98] transition-transform"
          >
            {saving ? t('settings.saving') : t('common.save')}
          </button>
        </div>
      </SubScreen>
    );
  }

  if (section === 'language') {
    return (
      <SubScreen title={t('settings.language')} onBack={() => setSection(null)}>
        <div className="space-y-3 px-4">
          {languages.map(lang => (
            <button
              key={lang.code}
              onClick={() => handleLangSelect(lang.code)}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl border-2 transition-all font-bold text-base ${
                i18n.language === lang.code
                  ? 'border-primary bg-primary/10 text-foreground'
                  : 'border-border bg-card text-muted-foreground'
              }`}
            >
              <span className="text-2xl">{lang.flag}</span>
              {lang.label}
              {i18n.language === lang.code && <Check className="ml-auto w-5 h-5 text-primary" />}
            </button>
          ))}
        </div>
      </SubScreen>
    );
  }

  if (section === 'theme') {
    return (
      <SubScreen title={t('settings.theme')} onBack={() => setSection(null)}>
        <div className="space-y-3 px-4">
          {themes.map(th => (
            <button
              key={th.id}
              onClick={() => setTheme(th.id)}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl border-2 transition-all font-bold text-base ${
                theme === th.id
                  ? 'border-primary bg-primary/10 text-foreground'
                  : 'border-border bg-card text-muted-foreground'
              }`}
            >
              {th.label}
              {theme === th.id && <Check className="ml-auto w-5 h-5 text-primary" />}
            </button>
          ))}
        </div>
      </SubScreen>
    );
  }

  if (section === 'notifications') {
    return (
      <SubScreen title={t('settings.notifications')} onBack={() => setSection(null)}>
        <div className="px-4 text-muted-foreground text-sm">
          <p>{t('settings.notificationsComingSoon')}</p>
        </div>
      </SubScreen>
    );
  }

  if (section === 'about') {
    return <AboutAppScreen onBack={() => setSection(null)} />;
  }

  if (section === 'privacyTerms') {
    return <PrivacyTermsScreen onBack={() => setSection(null)} />;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 pt-12 pb-6">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <button onClick={() => goBack(navigate)} className="w-10 h-10 rounded-full bg-card flex items-center justify-center">
            <ArrowLeft className="w-5 h-5 text-muted-foreground" />
          </button>
          <h1 className="text-xl font-black text-foreground">{t('settings.title')}</h1>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 space-y-4 pb-12">
        {user && (
          <div className="bg-card rounded-2xl p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden">
              {user.avatar_url ? (
                <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-primary font-black text-lg">
                  {(user.display_name || user.full_name || user.email || '?')[0].toUpperCase()}
                </span>
              )}
            </div>
            <div>
              <p className="font-bold text-foreground">{user?.is_guest ? t('guest.guestName') : (user.display_name || user.full_name || t('settings.noName'))}</p>
              {!user?.is_guest && <p className="text-muted-foreground text-sm">{user.email}</p>}
            </div>
          </div>
        )}

        <div className="bg-card rounded-2xl overflow-hidden">
          {menuItems.map((item, i) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setSection(item.id)}
                className={`w-full flex items-center gap-4 px-4 py-4 text-left active:bg-muted transition-colors ${
                  i < menuItems.length - 1 ? 'border-b border-border' : ''
                }`}
              >
                <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
                  <Icon className="w-4 h-4 text-muted-foreground" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-foreground text-sm">{item.label}</p>
                  {item.sub && <p className="text-xs text-muted-foreground">{item.sub}</p>}
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            );
          })}
        </div>

        <div className="bg-card rounded-2xl overflow-hidden">
          {!isGuest && (
            <div className="flex items-center gap-4 px-4 py-4">
              <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
                {(user?.is_profile_public ?? true) ? <Globe className="w-4 h-4 text-primary" /> : <Lock className="w-4 h-4 text-muted-foreground" />}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-foreground text-sm">{t('settings.privacy')}</p>
                <p className="text-xs text-muted-foreground">{t('settings.privacySub')}</p>
              </div>
              <Switch
                checked={user?.is_profile_public ?? true}
                onCheckedChange={handlePrivacyToggle}
              />
            </div>
          )}
          <div className={`flex items-center gap-4 px-4 py-4 ${!isGuest ? 'border-t border-border' : ''}`}>
            <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
              <Volume2 className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-foreground text-sm">{t('settings.sound')}</p>
              <p className="text-xs text-muted-foreground">{t('settings.soundSub')}</p>
            </div>
            <Switch
              checked={soundEnabled}
              onCheckedChange={handleSoundToggle}
            />
          </div>
          <div className="flex items-center gap-4 px-4 py-4 border-t border-border">
            <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
              <Vibrate className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-foreground text-sm">{t('settings.vibration')}</p>
              <p className="text-xs text-muted-foreground">{t('settings.vibrationSub')}</p>
            </div>
            <Switch
              checked={vibrationEnabled}
              onCheckedChange={handleVibrationToggle}
            />
          </div>
        </div>

        <div className="bg-card rounded-2xl overflow-hidden">
          {infoItems.map((item, i) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setSection(item.id)}
                className={`w-full flex items-center gap-4 px-4 py-4 text-left active:bg-muted transition-colors ${
                  i < infoItems.length - 1 ? 'border-b border-border' : ''
                }`}
              >
                <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center">
                  <Icon className="w-4 h-4 text-muted-foreground" />
                </div>
                <span className="flex-1 font-semibold text-foreground text-sm">{item.label}</span>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            );
          })}
        </div>

        {user?.is_guest ? (
          <div className="bg-card rounded-2xl overflow-hidden">
            <button
              onClick={navigateToLogin}
              className="w-full flex items-center gap-4 px-4 py-4 active:bg-muted transition-colors"
            >
              <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
                <LogIn className="w-4 h-4 text-primary" />
              </div>
              <span className="font-semibold text-primary text-sm">{t('guest.login')}</span>
            </button>
          </div>
        ) : (
          <div className="bg-card rounded-2xl overflow-hidden">
            <button
              onClick={() => setShowLogoutDialog(true)}
              className="w-full flex items-center gap-4 px-4 py-4 border-b border-border active:bg-muted transition-colors"
            >
              <div className="w-9 h-9 rounded-xl bg-orange-500/10 flex items-center justify-center">
                <LogOut className="w-4 h-4 text-orange-400" />
              </div>
              <span className="font-semibold text-orange-400 text-sm">{t('settings.logout')}</span>
            </button>
            <button
              onClick={() => setShowDeleteDialog(true)}
              className="w-full flex items-center gap-4 px-4 py-4 active:bg-muted transition-colors"
            >
              <div className="w-9 h-9 rounded-xl bg-red-500/10 flex items-center justify-center">
                <Trash2 className="w-4 h-4 text-red-400" />
              </div>
              <span className="font-semibold text-red-400 text-sm">{t('settings.deleteAccount')}</span>
            </button>
          </div>
        )}
      </div>

      <AlertDialog open={showLogoutDialog} onOpenChange={setShowLogoutDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('settings.logoutConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('settings.logoutDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleLogout} className="bg-orange-500 text-white">
              {t('settings.logout')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('settings.deleteAccountConfirm')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('settings.deleteAccountDesc')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteAccount} disabled={deleting} className="bg-destructive text-destructive-foreground">
              {deleting ? t('settings.deleting') : t('settings.deleteAccount')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showPrivacyDialog} onOpenChange={setShowPrivacyDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('settings.privacyConfirmTitle')}</AlertDialogTitle>
            <AlertDialogDescription>
              {pendingPrivacy ? t('settings.privacyConfirmPublic') : t('settings.privacyConfirmPrivate')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handlePrivacyConfirm}>
              {t('common.confirm')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function SubScreen({ title, onBack, children }) {
  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 pt-12 pb-6">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-card flex items-center justify-center">
            <ArrowLeft className="w-5 h-5 text-muted-foreground" />
          </button>
          <h1 className="text-xl font-black text-foreground">{title}</h1>
        </div>
      </div>
      <div className="max-w-lg mx-auto">{children}</div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">{label}</label>
      {children}
    </div>
  );
}