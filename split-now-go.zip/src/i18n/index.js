import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import fi from './fi.json';
import en from './en.json';
import sv from './sv.json';

const savedLang = localStorage.getItem('lang') || 'fi';

i18n.use(initReactI18next).init({
  resources: {
    fi: { translation: fi },
    en: { translation: en },
    sv: { translation: sv },
  },
  lng: savedLang,
  fallbackLng: 'fi',
  interpolation: { escapeValue: false },
});

export function changeLanguage(lang) {
  localStorage.setItem('lang', lang);
  i18n.changeLanguage(lang);
}

export default i18n;