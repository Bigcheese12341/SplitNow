import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const ALLOWED_ROLES = ['viewer', 'timer', 'editor', 'owner'];

// Owner-only member management. The UI hides these actions from timers and
// editors, and this function is the enforced gate: every role change or removal
// is checked here before anything is written.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { action, memberId, competitionId, role } = body;
    const admin = base44.asServiceRole;

    const getCompetition = (id) =>
      admin.entities.Competition.get(id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));

    const isOwnerOf = async (comp) => {
      if (!comp) return false;
      if (comp.created_by_id === user.id) return true;
      const memberships = await admin.entities.CompetitionMember.filter({
        competition_id: comp.id,
        user_id: user.id,
      });
      return memberships.some((m) => m.role === 'owner');
    };

    if (action === 'purgeMembers') {
      if (!competitionId) return Response.json({ error: 'competitionId is required' }, { status: 400 });
      const comp = await getCompetition(competitionId);
      if (!comp) return Response.json({ error: 'Not found' }, { status: 404 });
      if (!(await isOwnerOf(comp))) return Response.json({ error: 'Forbidden' }, { status: 403 });
      await admin.entities.CompetitionMember.deleteMany({ competition_id: competitionId });
      return Response.json({ ok: true });
    }

    if (action !== 'remove' && action !== 'setRole') {
      return Response.json({ error: 'Unknown action' }, { status: 400 });
    }

    if (!memberId) return Response.json({ error: 'memberId is required' }, { status: 400 });
    if (action === 'setRole' && !ALLOWED_ROLES.includes(role)) {
      return Response.json({ error: 'Invalid role' }, { status: 400 });
    }

    const member = await admin.entities.CompetitionMember
      .get(memberId)
      .catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!member) return Response.json({ error: 'Not found' }, { status: 404 });

    const competition = await getCompetition(member.competition_id);
    if (!competition) return Response.json({ error: 'Not found' }, { status: 404 });
    if (!(await isOwnerOf(competition))) return Response.json({ error: 'Forbidden' }, { status: 403 });

    // The competition creator keeps the owner role; nobody can demote or remove it here.
    if (member.user_id === competition.created_by_id) {
      return Response.json({ error: 'Owner membership is locked' }, { status: 403 });
    }

    if (action === 'setRole') {
      await admin.entities.CompetitionMember.update(memberId, { role });
    } else {
      await admin.entities.CompetitionMember.delete(memberId);
    }

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}