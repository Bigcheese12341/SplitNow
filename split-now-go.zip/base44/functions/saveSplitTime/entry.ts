import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

// Split time changes made in the quick touch view.
// The caller must be a member of the competition with a role that may time it:
// timer, editor or owner.
//  - elapsed given: the entry is replaced in place, so a correction never creates
//    a duplicate split for the same timing point.
//  - remove: true: the stored time of that timing point is removed (undo).
const EDITING_ROLES = ['timer', 'editor', 'owner'];

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { competitorId, splitIndex, elapsed, remove } = await req.json().catch(() => ({}));
    const removing = remove === true;
    if (!competitorId || splitIndex === undefined || splitIndex === null || splitIndex < 0) {
      return Response.json({ error: 'competitorId and splitIndex are required' }, { status: 400 });
    }
    if (!removing && (typeof elapsed !== 'number' || !isFinite(elapsed) || elapsed <= 0)) {
      return Response.json({ error: 'elapsed must be a positive number of seconds' }, { status: 400 });
    }

    const competitor = await base44.asServiceRole.entities.Competitor
      .get(competitorId)
      .catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!competitor) return Response.json({ error: 'Not found' }, { status: 404 });

    // The right is checked against the competitor's own competition.
    const members = await base44.asServiceRole.entities.CompetitionMember.filter({
      competition_id: competitor.competition_id,
      user_id: user.id,
    });
    const role = members[0]?.role;
    if (!EDITING_ROLES.includes(role)) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const splitTimes = Array.isArray(competitor.split_times) ? [...competitor.split_times] : [];
    const index = splitTimes.findIndex((s) => s.split_index === splitIndex);

    if (removing) {
      if (index < 0) return Response.json({ split_times: splitTimes, removed: false });
      splitTimes.splice(index, 1);
      await base44.asServiceRole.entities.Competitor.update(competitorId, { split_times: splitTimes });
      return Response.json({ split_times: splitTimes, removed: true });
    }

    const timestamp = new Date().toISOString();

    if (index >= 0) {
      splitTimes[index] = { ...splitTimes[index], split_index: splitIndex, elapsed, timestamp };
    } else {
      splitTimes.push({ split_index: splitIndex, elapsed, timestamp, source: 'manual' });
    }

    await base44.asServiceRole.entities.Competitor.update(competitorId, { split_times: splitTimes });

    return Response.json({ split_times: splitTimes });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}